var mongoose = require('mongoose');
var Booking = mongoose.model('Booking');
var Car = mongoose.model('Cars');
const validatorModule = require("../validations/validators");
const mailer = require("../mailer/mailservice");
const crypto = require("../controllers/crypto");


module.exports.bookingRead = function (req, res) { 
    Booking.find(function (err, booking) {
        if (err)
            res.send(err);
        res.json(booking);
    });

};

module.exports.bookingsReadByEmail = function (req, res) {
    Booking.find({ email: req.params.email }, function (err, bookings) {
        if (err)
            res.send(err);
        res.json(bookings);
    });
};

// Update Booking - Admin Panel
module.exports.updateBooking = async function (req, res) {
    const filter = {booking_code :req.body.booking_code};
    var bookingToUpdate = {};
    bookingToUpdate = Object.assign(bookingToUpdate, req.body);
    delete bookingToUpdate._id; 
    Booking.findOneAndUpdate(filter,bookingToUpdate, { new: true}, (err, doc) => {
        if (err) {
            console.log("Something wrong when updating data!",err);
            return res.status(401).send('Booking not updated');
        }
        if(doc == null ){
            return res.status(404).json({
                error: 'NOT_AVAILABLE',
                description: 'Sorry but booking was not found. Please contact Autoland.!',
            }) 
        }
        return res.status(200).send(doc);
    });
};

// Update booking from payment gateway
module.exports.bookingPayUpdate = async function (req, res) { 
    Booking.findOneAndUpdate({booking_code :{ $regex : new RegExp(req.body.orderid, "i") }, "driverinfo.email": req.body.email}, {$set:{status:req.body.status}}, {new: true}, (err, doc) => {
        if (err) {
            console.log("Something wrong when updating data!");
            return res.status(401).send('Booking not updated');
        }
        if(doc == null ){
            return res.status(404).json({
                error: 'NOT_AVAILABLE',
                description: 'Sorry but booking was not found. Please contact Autoland.!',
            }) 
        }
        return res.status(200).send(doc);
    });
};

module.exports.createBooking = async function (req, res) {
    // Begin Validation
    const { error } = validatorModule("createBooking", req.body);
    if (error) {
        const errors = {};
        error.details.forEach(err => (errors[err.context.key] = err.message));
        console.log(errors);
        return res.status(401).send(errors);
    }
    // Check Car Availabilty 
    let isAvail = await isVehicleAvailable(req); 
    if (!isAvail) {
       return res.status(404).json({
            error: 'NOT_AVAILABLE',
            description: 'Oops..!! Vehicle is not available. Please Try Different Dates.',
        }) 
    } 
    // Generate Booking model Object
    var booking = new Booking(req.body);
    // Generate Booking Code !
    const documentCount = await Booking.count({});
    let booking_code = 'ATLK' + documentCount + creatBookingCodeID();
    booking.booking_code = booking_code.toUpperCase();
    req.body.bookingCode = booking_code;
    let bdigest;
    if(req.body.payment_method === 'creditCard'){
         bdigest = await crypto.bdigest(req.body); 
        // booking.jwtPay = bdigest;
       } 
    try { 
       // await booking.save();
       //        await Promise.all([booking.save(), mailer.bookingRequestForm(req, res)]);  
       //  await Promise.all([ booking.save(), mailer.bookingAdminRequestForm(req, res),mailer.bookingRequestForm(req, res)]);  
       await Promise.all([ booking.save(), mailer.bookingRequestForm(req, res)]);  
        return res.status(200).json({
            data: booking, 
            dbseed:bdigest,
            message: 'SAVED',
            description: 'Vehicle was Reserved.'})
      
    } catch (err) {
        return res.status(404).send({
            error: 'NOT_SAVED',
            description: 'Booking Not Saved. Please Try again or Contact Autoland'
        })
    }
};

//@Tmilios
checkInventory = function (foundList){
 
    let fiat_panda_9 = 'atlk_CARB_FIAT_P01';
    let ford_fiesta_2 = 'atlk_CARC_FF_01';
    let hyundai_i10_2 = 'atlk_CARA_HY_I01';
    let atv_quad_2 = 'atlk_ATV_250_MXU_01';
  
    // Check Fiat Panda
    if (foundList.filter(i => i === fiat_panda_9).length < 9){
      // More Fiat Pandas in Inventory  - 
      //Remove item from found bookings to display on search
      foundList = foundList.filter(function(element) {
        return element !== fiat_panda_9;
    })
    }
    // Check hyundai i10
    if (foundList.filter(i => i === hyundai_i10_2).length < 2){
      // More Fiat Pandas in Inventory  - 
      //Remove item from found bookings to display on search
      foundList = foundList.filter(function(element) {
        return element !== hyundai_i10_2;
    })
    }
      // Check Fiat Fond Fiesta
      if (foundList.filter(i => i === ford_fiesta_2).length < 2){
        // More Fiat Pandas in Inventory  - 
        //Remove item from found bookings to display on search
        foundList = foundList.filter(function(element) {
          return element !== ford_fiesta_2;
      })
      }
  
        // Check atv quad
    if (foundList.filter(i => i === atv_quad_2).length < 2){
      // More Fiat Pandas in Inventory  - 
      //Remove item from found bookings to display on search
      foundList = foundList.filter(function(element) {
        return element !== atv_quad_2;
    })
    }
     return foundList;
  
  }

// @Tmilios Get Available car ID's
isVehicleAvailable = async function (req, res) {
    try {
        var pickDate = Number(req.body.pickDateTimeStamp);
        var returnDate = Number(req.body.returnDateTimeStamp);
        var carIDs = await Booking.find({ "pickDateTimeStamp": { "$lt": returnDate }, "returnDateTimeStamp": { "$gt": pickDate } })
            .distinct("car_id").exec(); 
           //Check inventory of carId's
           carIDs = checkInventory(carIDs);    
        if (carIDs.indexOf(req.body.car_id) > -1) {
            return false;
        }
        return true;
    } catch (err) {
        console.log(err);
    }
}

// @Tmilios 
creatBankStreem = function (req) {
    var result = '';
    return result;
}

// @Tmilios 5 Letter Reseration Code
creatBookingCodeID = function () {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < 5; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}

////// DEMO SECTION \\\\\\

//Tmilios - Working - Create Test Bookings
module.exports.demo = function (req, res) {
    // var carInfor = new Car(req.body);
    console.log("in  Demo Bookings");
    var bookingInfo;
    BOOKINGS.forEach(function (item) {
        console.log('inere');
        bookingInfo = new Booking(item);
        bookingInfo.save().then(item => {
            console.log("item saved to database");
            if (res.length === BOOKINGS.length) {
                res.status(200).send("Items save to database");
            }
        })
            .catch(err => {
                res.status(400).send("unable to save to database");
            });
    });
    // return bookingRead();
};

BOOKINGS = [
    {
        "car_id": "atlk_CARD_VW_P01",
        "booking_code": "R5AMAZAP",
        "booking_timestamp": 1564997188,
        "pickDateTimeStamp": 1581228300000,
        "returnDateTimeStamp": 1581858000000
    },
    {
        "car_id": "atlk_SCTR_125_LK_01",
        "booking_code": "R5AMAZAP",
        "booking_timestamp": 1566887784,
        "pickDateTimeStamp": 1581364189000,
        "returnDateTimeStamp": 1581623389000
    }

]

