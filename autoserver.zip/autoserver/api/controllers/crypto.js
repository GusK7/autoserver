var crypto = require('crypto');


// Call me Form Send Email
module.exports.bdigest = async function (req) {
try {
let bankSeed ={
    'mid': '0023547441',
    'orderid': req.bookingCode,
    'orderDesc': 'Autoland Karpathos - Reservation: '+req.bookingCode,
    'orderAmount': req.ammountPaid,
    'currency':'EUR',
    'payerEmail':req.driverinfo.email,
    'billCountry':req.driverinfo.country,
    'billState': 'test',
    'billZip': '32904',
    'billCity': req.driverinfo.town,
    'billAddress': req.driverinfo.address,
    'payMethod':'',
    'confirmUrl': 'https://autolandkarpathos.gr/order/succeed',
    'cancelUrl': 'https://autolandkarpathos.gr/order/failure',
    'digest':''
} 
const skey = 'SAYvLauO2xIivvK2AjSFEF';
// Concatenate object property values
let joinedString = Object.values(bankSeed ).join("");   
let finalString = joinedString.concat(skey); 
var sha = crypto.createHash('sha1');
sha.update(finalString);
var ret = sha.digest('base64'); 
bankSeed.digest = ret;
console.log('ret',ret)
return bankSeed;
} catch (err) {
    console.log(err);
}
}