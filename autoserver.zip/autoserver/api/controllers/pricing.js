var mongoose = require('mongoose');
var PriceGroups = mongoose.model('PriceGroups');
var PricePlans = mongoose.model('PricePlans');
var Discounts = mongoose.model('Discounts');
var Car = mongoose.model('Cars');
var async = require('async');
const func = require('joi/lib/types/func');


//Tmilios  - Create Init Groups
module.exports.createPriceGroups = function (req, res) {
    // var carInfor = new Car(req.body);
    console.log("-- Price Groups Creation");
    var carInfor;
    var priceGroups;

    PRICEGROUPS.forEach(function (item) {
        console.log('inere');
        priceGroups = new PriceGroups(item);
        priceGroups.save().then(item => {
            console.log("item saved to database");
            if (res.length === PRICEGROUPS.length) {
                res.status(200).send("Items save to database");
            }
        })
            .catch(err => {
                res.status(400).send("unable to save to database");
            });
    });
    return readAllGroupsInfo();
};


//Tmilios - Create Init Prince Plans
module.exports.createPricePlans = function (req, res) {
    console.log("-- Price Plans Creation");
    var pricePlan;

    PRICEPLANS.forEach(function (item) {
        pricePlan = new PricePlans();

        if (item.start_timestamp === '1569888000') {
            pricePlan.start_timestamp = item.start_timestamp;
            console.log('xxxxxx');
            console.log(pricePlan.start_timestamp);
        } else {
            console.log('yyyyyyy');
            fromDate = new Date(item.start_timestamp * 1000);
            fromDate = fromDate.setFullYear(2020);
            pricePlan.start_timestamp = fromDate.valueOf();

        }



        toDate = new Date(item.end_timestamp * 1000);
        toDate = toDate.setFullYear(2020);
        pricePlan.end_timestamp = toDate.valueOf();
        pricePlan.plan_id = item.price_plan_id;
        var x = item.price_group_id;
        pricePlan.planName = GROUPNAMES[0][x];
        pricePlan.daily_rate_mon = item.daily_rate_mon;
        pricePlan.daily_rate_tue = item.daily_rate_tue;
        pricePlan.daily_rate_wed = Number(item.daily_rate_wed);
        pricePlan.daily_rate_thu = Number(item.daily_rate_thu);
        pricePlan.daily_rate_fri = Number(item.daily_rate_fri);
        pricePlan.daily_rate_sat = Number(item.daily_rate_sat);
        pricePlan.daily_rate_sun = Number(item.daily_rate_sun);
        pricePlan.price_group_id = item.price_group_id;
        pricePlan.save().then(item => {
            if (res.length === PRICEPLANS.length) {
                res.status(200).send("Items save to database");
            }
        })
            .catch(err => {
                res.status(400).send("unable to save to database");
            });
    });
    res.status(200).send("Items Loaded to database");
};

//Tmilios  - Create Init Discounts
module.exports.createDisctounts = function (req, res) {
    console.log("-- Price Discounts Creation");
    var carInfor;
    var priceGroups;

    DISCOUNTS.forEach(function (item) {
        console.log('inere');
        discounts = new Discounts();
        discounts.discount_id = item.discount_id;
        discounts.discount_type = item.discount_type;
        discounts.price_plan_id = item.price_plan_id;
        discounts.coupon_discount = item.coupon_discount;
        discounts.extra_id = item.extra_id;
        discounts.period_from = item.period_from
        discounts.period_till = item.period_till
        discounts.discount_percentage = item.discount_percentage;
        discounts.save().then(item => {
            console.log("item saved to database");
            if (res.length === PRICEGROUPS.length) {
                res.status(200).send("Items save to database");
            }
        })
            .catch(err => {
                res.status(400).send("unable to save to database");
            });
    });
};


// @Tmilios - Read Info
module.exports.getPlanDiscounts = function (req, res) {
    Discounts.find(function (err, groupList) {
        if (err)
            res.send(err);
        res.json(groupList);
    });
};


//Control Panel Price Update - Return Price Group ID Of car
getPriceGroup = async function (carID) {
    try {
        let pricegroup = Car.findOne({ ["car_id"]: carID }).lean().exec();
        return pricegroup;
    } catch (err) {
        console.log(err);
    }
}
//Control Panel Price Update - Return Price Groups Of car
getPricePlans = async function (priceroups) {
    try {
        let priceplans = await PricePlans.find({ price_group_id: priceroups }).lean().exec();
        return priceplans;

    } catch (err) {
        console.log(err);
    }
}

//Control Panel Price Update - Return Group Disctounts Of car
getPlansDictounts = async function (plan_id, dailyrate) {
    try {
        let discounts = await Discounts.find({ price_plan_id: plan_id }).exec()
        let discountsArray = [];
        for (var i = 0; i < discounts.length; i++) {
            let dailyPrice = (dailyrate - (dailyrate * (discounts[i].discount_percentage / 100)))
            dailyPrice = Math.round(dailyPrice + (dailyPrice * .23));

            console.log("dailyPrice: ", dailyPrice);
            let daillyPriceRounder = Math.round(dailyPrice);
            let discount = {
                discount_id: discounts[i].discount_id,
                discount_type: discounts[i].discount_type,
                price_plan_id: discounts[i].price_plan_id,
                coupon_discount: discounts[i].coupon_discount,
                extra_id: discounts[i].extra_id,
                period_from: discounts[i].period_from,
                period_till: discounts[i].period_till,
                discount_percentage: discounts[i].discount_percentage,
                period_from_num: Math.ceil(discounts[i].period_from / (3600 * 24)),
                period_till_num: Math.ceil(discounts[i].period_till / (3600 * 24)),
                dailyCalculate: daillyPriceRounder,
                editItem: false,
                discountUpdated: false,
                calculator: function () {
                    return Math.round((this.dailyCalculate - (this.dailyCalculate * (this.discount_percentage / 100)) + (this.dailyCalculate * .23)))
                }
            }
            discountsArray.push(discount);
        }
        return discountsArray;

    } catch (err) {
        console.log(err);
    }
}

//Control Panel Price Update - Return Car Group Price Data
module.exports.getVehiclePricing = async function (req, res) {
    console.log("req.body", req.body.carid);
    //Change Car Id with value passed from UI
    const priceGroups = await getPriceGroup(req.body.carid);
    const plans = await getPricePlans(priceGroups.priceroups);
    let planGroups = [];
    for (var i = 0; i < plans.length; i++) {
        const discounts = await getPlansDictounts(plans[i].plan_id, plans[i].daily_rate_mon);
        let startDate = new Date(plans[i].start_timestamp);
        let endDate = new Date(plans[i].end_timestamp)
        let plan = {
            planName: plans[i].planName,
            plan_id: plans[i].plan_id,
            price_group_id: plans[i].price_group_id,
            startDate_timestamp: plans[i].start_timestamp,
            startDate: format(startDate),
            endDate: format(endDate),
            endDate_timestamp: plans[i].end_timestamp,
            rate: plans[i].daily_rate_mon,
            discounts: discounts
        }
        planGroups.push(plan);
    }
    return res.status(200).json(planGroups);
}

function format(date) {
    var d = date.getDate();
    var m = date.getMonth() + 1;
    var y = date.getFullYear();
    return '' + y + '-' + (m <= 9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d);
}

//Control Panel Price Update - Return Car Group Price Data
module.exports.setVehiclePricing = async function (req, res) {
    console.log('xxxx')
    if (req.body != null && req.body.discoutObj.discountUpdated == true) {
        // var query = {'discount_id': req.body.discoutObj.discount_id};
        // let updatedDiscount = req.body.discoutObj.discount_percentage;
        let discounts = await Discounts.findOneAndUpdate({ discount_id: req.body.discoutObj.discount_id }, { discount_percentage: req.body.discoutObj.discount_percentage }, function (err, doc) {
            if (err) return res.send(500, { error: err });
            return true;
        });
        if (discounts) {

            let plans = await getVehiclePricingbyID(req.body.vehicle_id);
            console.log('xxx', plans)
            if (plans) {
                return res.status(200).json(plans);
            }

        }

    }
}

//Control Panel Price Update - Return Car Group Price Data
getVehiclePricingbyID = async function (carid) {

    //Change Car Id with value passed from UI
    const priceGroups = await getPriceGroup(carid);
    const plans = await getPricePlans(priceGroups.priceroups);
    let planGroups = [];
    for (var i = 0; i < plans.length; i++) {
        const discounts = await getPlansDictounts(plans[i].plan_id, plans[i].daily_rate_mon);
        let startDate = new Date(plans[i].start_timestamp);
        let endDate = new Date(plans[i].end_timestamp)
        let plan = {
            planName: plans[i].planName,
            plan_id: plans[i].plan_id,
            price_group_id: plans[i].price_group_id,
            startDate_timestamp: plans[i].start_timestamp,
            startDate: format(startDate),
            endDate: format(endDate),
            endDate_timestamp: plans[i].end_timestamp,
            rate: plans[i].daily_rate_mon,
            discounts: discounts
        }
        planGroups.push(plan);
    }
    return planGroups;
}


// @Tmilios - Read Info
getvehicleplan = async function (req, res) {
    try {
        // var vehicleid = req.body.carid; 
        async.waterfall([
            function getPriceGroup(done) {
                Car.findOne({ ["car_id"]: "atlk_SCTR_125_LK_01" }).lean().exec(done);
            },
            function getPricePlan(car, done) {
                PricePlans.find({ price_group_id: car.priceroups }).lean().exec(done);
            },
        ], function (err, plans) {
            // if an error occurs during the above tasks ^, it will come down here
            if (err) {
                console.log(err);
                return res.status(400).send(e);
            }
            // otherwise if all tasks finish, it will come down here
            //  console.log('plans',plans)
            return plans;
        });
    } catch (err) {
        console.log(err);
    }
}



// @Tmilios - Read Info
module.exports.getPricePlans = function (req, res) {
    console.log('in Price Groups');
    PricePlans.find(function (err, groupList) {
        if (err)
            res.send(err);
        res.json(groupList);
    });
};






// Initial Commit Content
PRICEGROUPS = [
    {
        group_id: 'sc_125',
        groupName: 'SCOOTER 125'
    },
    {
        group_id: 'sc_200',
        groupName: 'SCOOTER 200'
    },
    {
        group_id: 'atv_1',
        groupName: 'ATV'
    },
    {
        group_id: 'cls_a',
        groupName: 'CLASS A'
    },
    {
        group_id: 'cls_b',
        groupName: 'CLASS B'
    },
    {
        group_id: 'cls_c',
        groupName: 'CLASS C'
    },
    {
        group_id: 'cls_d',
        groupName: 'CLASS D'
    },
    {
        group_id: 'cls_ba',
        groupName: 'CLASS BA'
    }
];

// DISCOUNTS = 
// [
//     {"discount_id":"6","discount_type":"1","coupon_discount":"0","price_plan_id":"9","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"3.500","blog_id":"1"},
//     {"discount_id":"22","discount_type":"1","coupon_discount":"0","price_plan_id":"9","extra_id":"0","period_from":"86400","period_till":"262799","discount_percentage":"2.222","blog_id":"1"},
//     {"discount_id":"23","discount_type":"1","coupon_discount":"0","price_plan_id":"9","extra_id":"0","period_from":"345600","period_till":"349199","discount_percentage":"2.500","blog_id":"1"},
//     {"discount_id":"24","discount_type":"1","coupon_discount":"0","price_plan_id":"9","extra_id":"0","period_from":"432000","period_till":"435599","discount_percentage":"2.667","blog_id":"1"},
//     {"discount_id":"25","discount_type":"1","coupon_discount":"0","price_plan_id":"9","extra_id":"0","period_from":"518400","period_till":"521999","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"26","discount_type":"1","coupon_discount":"0","price_plan_id":"9","extra_id":"0","period_from":"604800","period_till":"608399","discount_percentage":"2.381","blog_id":"1"},
//     {"discount_id":"27","discount_type":"1","coupon_discount":"0","price_plan_id":"10","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.500","blog_id":"1"},
//     {"discount_id":"28","discount_type":"1","coupon_discount":"0","price_plan_id":"10","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"3.125","blog_id":"1"},
//     {"discount_id":"29","discount_type":"1","coupon_discount":"0","price_plan_id":"10","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"3.000","blog_id":"1"},
//     {"discount_id":"30","discount_type":"1","coupon_discount":"0","price_plan_id":"10","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"3.750","blog_id":"1"},
//     {"discount_id":"31","discount_type":"1","coupon_discount":"0","price_plan_id":"10","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"3.571","blog_id":"1"},
//     {"discount_id":"32","discount_type":"1","coupon_discount":"0","price_plan_id":"11","extra_id":"0","period_from":"86400","period_till":"262799","discount_percentage":"2.500","blog_id":"1"},
//     {"discount_id":"33","discount_type":"1","coupon_discount":"0","price_plan_id":"11","extra_id":"0","period_from":"345600","period_till":"349199","discount_percentage":"3.125","blog_id":"1"},
//     {"discount_id":"34","discount_type":"1","coupon_discount":"0","price_plan_id":"11","extra_id":"0","period_from":"432000","period_till":"435599","discount_percentage":"3.000","blog_id":"1"},
//     {"discount_id":"35","discount_type":"1","coupon_discount":"0","price_plan_id":"11","extra_id":"0","period_from":"518400","period_till":"521999","discount_percentage":"3.750","blog_id":"1"},
//     {"discount_id":"36","discount_type":"1","coupon_discount":"0","price_plan_id":"11","extra_id":"0","period_from":"604800","period_till":"608399","discount_percentage":"3.571","blog_id":"1"},
//     {"discount_id":"37","discount_type":"1","coupon_discount":"0","price_plan_id":"12","extra_id":"0","period_from":"86400","period_till":"262799","discount_percentage":"2.222","blog_id":"1"},
//     {"discount_id":"38","discount_type":"1","coupon_discount":"0","price_plan_id":"12","extra_id":"0","period_from":"345600","period_till":"349199","discount_percentage":"2.778","blog_id":"1"},
//     {"discount_id":"39","discount_type":"1","coupon_discount":"0","price_plan_id":"12","extra_id":"0","period_from":"432000","period_till":"435599","discount_percentage":"2.667","blog_id":"1"},
//     {"discount_id":"40","discount_type":"1","coupon_discount":"0","price_plan_id":"12","extra_id":"0","period_from":"518400","period_till":"521999","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"41","discount_type":"1","coupon_discount":"0","price_plan_id":"12","extra_id":"0","period_from":"604800","period_till":"608399","discount_percentage":"4.444","blog_id":"1"},
//     {"discount_id":"42","discount_type":"1","coupon_discount":"0","price_plan_id":"13","extra_id":"0","period_from":"86400","period_till":"262799","discount_percentage":"1.905","blog_id":"1"},
//     {"discount_id":"43","discount_type":"1","coupon_discount":"0","price_plan_id":"13","extra_id":"0","period_from":"345600","period_till":"349199","discount_percentage":"2.857","blog_id":"1"},
//     {"discount_id":"44","discount_type":"1","coupon_discount":"0","price_plan_id":"13","extra_id":"0","period_from":"432000","period_till":"435599","discount_percentage":"2.857","blog_id":"1"},
//     {"discount_id":"45","discount_type":"1","coupon_discount":"0","price_plan_id":"13","extra_id":"0","period_from":"518400","period_till":"521999","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"46","discount_type":"1","coupon_discount":"0","price_plan_id":"13","extra_id":"0","period_from":"604800","period_till":"608399","discount_percentage":"2.041","blog_id":"1"},
//     {"discount_id":"47","discount_type":"1","coupon_discount":"0","price_plan_id":"14","extra_id":"0","period_from":"86400","period_till":"262799","discount_percentage":"2.500","blog_id":"1"},
//     {"discount_id":"48","discount_type":"1","coupon_discount":"0","price_plan_id":"14","extra_id":"0","period_from":"345600","period_till":"349199","discount_percentage":"3.125","blog_id":"1"},
//     {"discount_id":"49","discount_type":"1","coupon_discount":"0","price_plan_id":"14","extra_id":"0","period_from":"432000","period_till":"435599","discount_percentage":"3.000","blog_id":"1"},
//     {"discount_id":"50","discount_type":"1","coupon_discount":"0","price_plan_id":"14","extra_id":"0","period_from":"518400","period_till":"521999","discount_percentage":"3.750","blog_id":"1"},
//     {"discount_id":"51","discount_type":"1","coupon_discount":"0","price_plan_id":"14","extra_id":"0","period_from":"604800","period_till":"608399","discount_percentage":"3.571","blog_id":"1"},
//     {"discount_id":"52","discount_type":"1","coupon_discount":"0","price_plan_id":"15","extra_id":"0","period_from":"86400","period_till":"262799","discount_percentage":"2.222","blog_id":"1"},
//     {"discount_id":"53","discount_type":"1","coupon_discount":"0","price_plan_id":"15","extra_id":"0","period_from":"345600","period_till":"349199","discount_percentage":"2.778","blog_id":"1"},
//     {"discount_id":"54","discount_type":"1","coupon_discount":"0","price_plan_id":"15","extra_id":"0","period_from":"432000","period_till":"435599","discount_percentage":"2.667","blog_id":"1"},
//     {"discount_id":"55","discount_type":"1","coupon_discount":"0","price_plan_id":"15","extra_id":"0","period_from":"518400","period_till":"521999","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"56","discount_type":"1","coupon_discount":"0","price_plan_id":"15","extra_id":"0","period_from":"604800","period_till":"608399","discount_percentage":"4.444","blog_id":"1"},
//     {"discount_id":"57","discount_type":"1","coupon_discount":"0","price_plan_id":"16","extra_id":"0","period_from":"86400","period_till":"262799","discount_percentage":"2.000","blog_id":"1"},
//     {"discount_id":"58","discount_type":"1","coupon_discount":"0","price_plan_id":"16","extra_id":"0","period_from":"345600","period_till":"349199","discount_percentage":"3.000","blog_id":"1"},
//     {"discount_id":"59","discount_type":"1","coupon_discount":"0","price_plan_id":"16","extra_id":"0","period_from":"432000","period_till":"435599","discount_percentage":"3.200","blog_id":"1"},
//     {"discount_id":"60","discount_type":"1","coupon_discount":"0","price_plan_id":"16","extra_id":"0","period_from":"518400","period_till":"521999","discount_percentage":"4.000","blog_id":"1"},
//     {"discount_id":"61","discount_type":"1","coupon_discount":"0","price_plan_id":"16","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"4.857","blog_id":"1"},
//     {"discount_id":"62","discount_type":"1","coupon_discount":"0","price_plan_id":"61","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.222","blog_id":"1"},
//     {"discount_id":"63","discount_type":"1","coupon_discount":"0","price_plan_id":"61","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"2.778","blog_id":"1"},
//     {"discount_id":"64","discount_type":"1","coupon_discount":"0","price_plan_id":"61","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"2.667","blog_id":"1"},
//     {"discount_id":"65","discount_type":"1","coupon_discount":"0","price_plan_id":"61","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"66","discount_type":"1","coupon_discount":"0","price_plan_id":"61","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"4.444","blog_id":"1"},
//     {"discount_id":"111","discount_type":"1","coupon_discount":"0","price_plan_id":"28","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"3.000","blog_id":"1"},
//     {"discount_id":"115","discount_type":"1","coupon_discount":"0","price_plan_id":"28","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.000","blog_id":"1"},
//     {"discount_id":"116","discount_type":"1","coupon_discount":"0","price_plan_id":"28","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"3.200","blog_id":"1"},
//     {"discount_id":"117","discount_type":"1","coupon_discount":"0","price_plan_id":"28","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"4.000","blog_id":"1"},
//     {"discount_id":"124","discount_type":"1","coupon_discount":"0","price_plan_id":"30","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.000","blog_id":"1"},
//     {"discount_id":"125","discount_type":"1","coupon_discount":"0","price_plan_id":"30","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"3.000","blog_id":"1"},
//     {"discount_id":"126","discount_type":"1","coupon_discount":"0","price_plan_id":"30","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"3.200","blog_id":"1"},
//     {"discount_id":"127","discount_type":"1","coupon_discount":"0","price_plan_id":"30","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"4.000","blog_id":"1"},
//     {"discount_id":"128","discount_type":"1","coupon_discount":"0","price_plan_id":"30","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"4.857","blog_id":"1"},
//     {"discount_id":"138","discount_type":"1","coupon_discount":"0","price_plan_id":"33","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.667","blog_id":"1"},
//     {"discount_id":"139","discount_type":"1","coupon_discount":"0","price_plan_id":"33","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"3.000","blog_id":"1"},
//     {"discount_id":"140","discount_type":"1","coupon_discount":"0","price_plan_id":"33","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"3.200","blog_id":"1"},
//     {"discount_id":"141","discount_type":"1","coupon_discount":"0","price_plan_id":"33","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"4.000","blog_id":"1"},
//     {"discount_id":"142","discount_type":"1","coupon_discount":"0","price_plan_id":"33","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"2.857","blog_id":"1"},
//     {"discount_id":"143","discount_type":"1","coupon_discount":"0","price_plan_id":"34","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.222","blog_id":"1"},
//     {"discount_id":"144","discount_type":"1","coupon_discount":"0","price_plan_id":"34","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"2.500","blog_id":"1"},
//     {"discount_id":"145","discount_type":"1","coupon_discount":"0","price_plan_id":"34","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"2.666","blog_id":"1"},
//     {"discount_id":"146","discount_type":"1","coupon_discount":"0","price_plan_id":"34","extra_id":"0","period_from":"518400","period_till":"521999","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"147","discount_type":"1","coupon_discount":"0","price_plan_id":"34","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"2.381","blog_id":"1"},
//     {"discount_id":"153","discount_type":"1","coupon_discount":"0","price_plan_id":"36","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.500","blog_id":"1"},
//     {"discount_id":"154","discount_type":"1","coupon_discount":"0","price_plan_id":"36","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"3.125","blog_id":"1"},
//     {"discount_id":"155","discount_type":"1","coupon_discount":"0","price_plan_id":"36","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"3.000","blog_id":"1"},
//     {"discount_id":"156","discount_type":"1","coupon_discount":"0","price_plan_id":"36","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"3.750","blog_id":"1"},
//     {"discount_id":"157","discount_type":"1","coupon_discount":"0","price_plan_id":"36","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"3.571","blog_id":"1"},
//     {"discount_id":"158","discount_type":"1","coupon_discount":"0","price_plan_id":"2","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"159","discount_type":"1","coupon_discount":"0","price_plan_id":"2","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"160","discount_type":"1","coupon_discount":"0","price_plan_id":"2","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"6.667","blog_id":"1"},
//     {"discount_id":"161","discount_type":"1","coupon_discount":"0","price_plan_id":"2","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"6.667","blog_id":"1"},
//     {"discount_id":"162","discount_type":"1","coupon_discount":"0","price_plan_id":"2","extra_id":"0","period_from":"604800","period_till":"1382399","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"163","discount_type":"1","coupon_discount":"0","price_plan_id":"38","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"12.500","blog_id":"1"},
//     {"discount_id":"164","discount_type":"1","coupon_discount":"0","price_plan_id":"38","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"12.500","blog_id":"1"},
//     {"discount_id":"165","discount_type":"1","coupon_discount":"0","price_plan_id":"38","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"20.000","blog_id":"1"},
//     {"discount_id":"166","discount_type":"1","coupon_discount":"0","price_plan_id":"38","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"20.000","blog_id":"1"},
//     {"discount_id":"167","discount_type":"1","coupon_discount":"0","price_plan_id":"38","extra_id":"0","period_from":"604800","period_till":"1382399","discount_percentage":"25.000","blog_id":"1"},
//     {"discount_id":"168","discount_type":"1","coupon_discount":"0","price_plan_id":"39","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"4.444","blog_id":"1"},
//     {"discount_id":"169","discount_type":"1","coupon_discount":"0","price_plan_id":"39","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"4.444","blog_id":"1"},
//     {"discount_id":"170","discount_type":"1","coupon_discount":"0","price_plan_id":"39","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"6.667","blog_id":"1"},
//     {"discount_id":"171","discount_type":"1","coupon_discount":"0","price_plan_id":"39","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"6.667","blog_id":"1"},
//     {"discount_id":"172","discount_type":"1","coupon_discount":"0","price_plan_id":"39","extra_id":"0","period_from":"604800","period_till":"1382399","discount_percentage":"11.111","blog_id":"1"},
//     {"discount_id":"173","discount_type":"1","coupon_discount":"0","price_plan_id":"40","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.424","blog_id":"1"},
//     {"discount_id":"174","discount_type":"1","coupon_discount":"0","price_plan_id":"40","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"3.636","blog_id":"1"},
//     {"discount_id":"175","discount_type":"1","coupon_discount":"0","price_plan_id":"40","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"4.727","blog_id":"1"},
//     {"discount_id":"176","discount_type":"1","coupon_discount":"0","price_plan_id":"40","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"5.455","blog_id":"1"},
//     {"discount_id":"177","discount_type":"1","coupon_discount":"0","price_plan_id":"40","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"5.974","blog_id":"1"},
//     {"discount_id":"178","discount_type":"1","coupon_discount":"0","price_plan_id":"40","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"9.091","blog_id":"1"},
//     {"discount_id":"184","discount_type":"1","coupon_discount":"0","price_plan_id":"47","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"185","discount_type":"1","coupon_discount":"0","price_plan_id":"47","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"186","discount_type":"1","coupon_discount":"0","price_plan_id":"47","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"187","discount_type":"1","coupon_discount":"0","price_plan_id":"13","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"3.500","blog_id":"1"},
//     {"discount_id":"188","discount_type":"1","coupon_discount":"0","price_plan_id":"61","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"4.444","blog_id":"1"},
//     {"discount_id":"192","discount_type":"1","coupon_discount":"0","price_plan_id":"33","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"3.500","blog_id":"1"},
//     {"discount_id":"194","discount_type":"1","coupon_discount":"0","price_plan_id":"10","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"3.750","blog_id":"1"},
//     {"discount_id":"195","discount_type":"1","coupon_discount":"0","price_plan_id":"14","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"3.500","blog_id":"1"},
//     {"discount_id":"198","discount_type":"1","coupon_discount":"0","price_plan_id":"30","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"199","discount_type":"1","coupon_discount":"0","price_plan_id":"34","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"2.917","blog_id":"1"},
//     {"discount_id":"202","discount_type":"1","coupon_discount":"0","price_plan_id":"11","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"3.500","blog_id":"1"},
//     {"discount_id":"203","discount_type":"1","coupon_discount":"0","price_plan_id":"15","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"3.500","blog_id":"1"},
//     {"discount_id":"210","discount_type":"1","coupon_discount":"0","price_plan_id":"12","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"3.500","blog_id":"1"},
//     {"discount_id":"211","discount_type":"1","coupon_discount":"0","price_plan_id":"16","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"214","discount_type":"1","coupon_discount":"0","price_plan_id":"28","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"216","discount_type":"1","coupon_discount":"0","price_plan_id":"36","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"3.750","blog_id":"1"},
//     {"discount_id":"218","discount_type":"1","coupon_discount":"0","price_plan_id":"47","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"219","discount_type":"1","coupon_discount":"0","price_plan_id":"47","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"15.000","blog_id":"1"},
//     {"discount_id":"220","discount_type":"1","coupon_discount":"0","price_plan_id":"47","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"15.000","blog_id":"1"},
//     {"discount_id":"221","discount_type":"1","coupon_discount":"0","price_plan_id":"48","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"4.545","blog_id":"1"},
//     {"discount_id":"222","discount_type":"1","coupon_discount":"0","price_plan_id":"48","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"4.545","blog_id":"1"},
//     {"discount_id":"223","discount_type":"1","coupon_discount":"0","price_plan_id":"48","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"9.091","blog_id":"1"},
//     {"discount_id":"224","discount_type":"1","coupon_discount":"0","price_plan_id":"48","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"9.091","blog_id":"1"},
//     {"discount_id":"225","discount_type":"1","coupon_discount":"0","price_plan_id":"48","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"13.636","blog_id":"1"},
//     {"discount_id":"226","discount_type":"1","coupon_discount":"0","price_plan_id":"48","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"13.636","blog_id":"1"},
//     {"discount_id":"227","discount_type":"1","coupon_discount":"0","price_plan_id":"49","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"4.000","blog_id":"1"},
//     {"discount_id":"228","discount_type":"1","coupon_discount":"0","price_plan_id":"49","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"4.000","blog_id":"1"},
//     {"discount_id":"229","discount_type":"1","coupon_discount":"0","price_plan_id":"49","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"8.000","blog_id":"1"},
//     {"discount_id":"230","discount_type":"1","coupon_discount":"0","price_plan_id":"49","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"8.000","blog_id":"1"},
//     {"discount_id":"231","discount_type":"1","coupon_discount":"0","price_plan_id":"49","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"12.000","blog_id":"1"},
//     {"discount_id":"232","discount_type":"1","coupon_discount":"0","price_plan_id":"49","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"12.000","blog_id":"1"},
//     {"discount_id":"233","discount_type":"1","coupon_discount":"0","price_plan_id":"50","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"234","discount_type":"1","coupon_discount":"0","price_plan_id":"50","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"235","discount_type":"1","coupon_discount":"0","price_plan_id":"50","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"236","discount_type":"1","coupon_discount":"0","price_plan_id":"50","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"237","discount_type":"1","coupon_discount":"0","price_plan_id":"50","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"15.000","blog_id":"1"},
//     {"discount_id":"238","discount_type":"1","coupon_discount":"0","price_plan_id":"50","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"15.000","blog_id":"1"},
//     {"discount_id":"239","discount_type":"1","coupon_discount":"0","price_plan_id":"46","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"16.667","blog_id":"1"},
//     {"discount_id":"240","discount_type":"1","coupon_discount":"0","price_plan_id":"46","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"19.444","blog_id":"1"},
//     {"discount_id":"241","discount_type":"1","coupon_discount":"0","price_plan_id":"46","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"20.000","blog_id":"1"},
//     {"discount_id":"242","discount_type":"1","coupon_discount":"0","price_plan_id":"46","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"22.222","blog_id":"1"},
//     {"discount_id":"243","discount_type":"1","coupon_discount":"0","price_plan_id":"46","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"22.222","blog_id":"1"},
//     {"discount_id":"244","discount_type":"1","coupon_discount":"0","price_plan_id":"46","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"22.222","blog_id":"1"},
//     {"discount_id":"245","discount_type":"1","coupon_discount":"0","price_plan_id":"42","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"4.167","blog_id":"1"},
//     {"discount_id":"246","discount_type":"1","coupon_discount":"0","price_plan_id":"42","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"4.167","blog_id":"1"},
//     {"discount_id":"247","discount_type":"1","coupon_discount":"0","price_plan_id":"42","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"8.333","blog_id":"1"},
//     {"discount_id":"248","discount_type":"1","coupon_discount":"0","price_plan_id":"42","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"8.333","blog_id":"1"},
//     {"discount_id":"249","discount_type":"1","coupon_discount":"0","price_plan_id":"42","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"16.667","blog_id":"1"},
//     {"discount_id":"250","discount_type":"1","coupon_discount":"0","price_plan_id":"42","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"16.667","blog_id":"1"},
//     {"discount_id":"251","discount_type":"1","coupon_discount":"0","price_plan_id":"43","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"3.846","blog_id":"1"},
//     {"discount_id":"253","discount_type":"1","coupon_discount":"0","price_plan_id":"43","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"3.846","blog_id":"1"},
//     {"discount_id":"254","discount_type":"1","coupon_discount":"0","price_plan_id":"43","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"7.692","blog_id":"1"},
//     {"discount_id":"255","discount_type":"1","coupon_discount":"0","price_plan_id":"43","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"7.692","blog_id":"1"},
//     {"discount_id":"256","discount_type":"1","coupon_discount":"0","price_plan_id":"43","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"11.538","blog_id":"1"},
//     {"discount_id":"257","discount_type":"1","coupon_discount":"0","price_plan_id":"43","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"11.538","blog_id":"1"},
//     {"discount_id":"258","discount_type":"1","coupon_discount":"0","price_plan_id":"44","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"3.448","blog_id":"1"},
//     {"discount_id":"259","discount_type":"1","coupon_discount":"0","price_plan_id":"44","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"3.448","blog_id":"1"},
//     {"discount_id":"260","discount_type":"1","coupon_discount":"0","price_plan_id":"44","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"6.897","blog_id":"1"},
//     {"discount_id":"262","discount_type":"1","coupon_discount":"0","price_plan_id":"44","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"10.345","blog_id":"1"},
//     {"discount_id":"263","discount_type":"1","coupon_discount":"0","price_plan_id":"44","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"10.345","blog_id":"1"},
//     {"discount_id":"270","discount_type":"1","coupon_discount":"0","price_plan_id":"37","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"18.182","blog_id":"1"},
//     {"discount_id":"271","discount_type":"1","coupon_discount":"0","price_plan_id":"37","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"22.727","blog_id":"1"},
//     {"discount_id":"272","discount_type":"1","coupon_discount":"0","price_plan_id":"37","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"22.727","blog_id":"1"},
//     {"discount_id":"273","discount_type":"1","coupon_discount":"0","price_plan_id":"37","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"27.273","blog_id":"1"},
//     {"discount_id":"274","discount_type":"1","coupon_discount":"0","price_plan_id":"37","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"27.273","blog_id":"1"},
//     {"discount_id":"275","discount_type":"1","coupon_discount":"0","price_plan_id":"37","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"27.273","blog_id":"1"},
//     {"discount_id":"284","discount_type":"1","coupon_discount":"0","price_plan_id":"54","extra_id":"0","period_from":"86400","period_till":"518399","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"289","discount_type":"1","coupon_discount":"0","price_plan_id":"54","extra_id":"0","period_from":"518400","period_till":"1382399","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"290","discount_type":"1","coupon_discount":"0","price_plan_id":"55","extra_id":"0","period_from":"86400","period_till":"518399","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"294","discount_type":"1","coupon_discount":"0","price_plan_id":"55","extra_id":"0","period_from":"518400","period_till":"1382399","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"304","discount_type":"1","coupon_discount":"0","price_plan_id":"57","extra_id":"0","period_from":"86400","period_till":"518399","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"309","discount_type":"1","coupon_discount":"0","price_plan_id":"57","extra_id":"0","period_from":"518400","period_till":"1382399","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"310","discount_type":"1","coupon_discount":"0","price_plan_id":"56","extra_id":"0","period_from":"86400","period_till":"518399","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"314","discount_type":"1","coupon_discount":"0","price_plan_id":"56","extra_id":"0","period_from":"518400","period_till":"1382399","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"317","discount_type":"1","coupon_discount":"0","price_plan_id":"60","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"321","discount_type":"1","coupon_discount":"0","price_plan_id":"60","extra_id":"0","period_from":"86400","period_till":"431999","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"322","discount_type":"1","coupon_discount":"0","price_plan_id":"60","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"323","discount_type":"1","coupon_discount":"0","price_plan_id":"60","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"324","discount_type":"1","coupon_discount":"0","price_plan_id":"60","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"325","discount_type":"1","coupon_discount":"0","price_plan_id":"53","extra_id":"0","period_from":"86400","period_till":"518399","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"326","discount_type":"1","coupon_discount":"0","price_plan_id":"53","extra_id":"0","period_from":"518400","period_till":"1382399","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"327","discount_type":"1","coupon_discount":"0","price_plan_id":"67","extra_id":"0","period_from":"86400","period_till":"518399","discount_percentage":"5.000","blog_id":"1"},
//     {"discount_id":"328","discount_type":"1","coupon_discount":"0","price_plan_id":"67","extra_id":"0","period_from":"518400","period_till":"1382399","discount_percentage":"10.000","blog_id":"1"},
//     {"discount_id":"329","discount_type":"1","coupon_discount":"0","price_plan_id":"18","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"1.905","blog_id":"1"},
//     {"discount_id":"330","discount_type":"1","coupon_discount":"0","price_plan_id":"18","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"2.857","blog_id":"1"},
//     {"discount_id":"331","discount_type":"1","coupon_discount":"0","price_plan_id":"18","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"2.857","blog_id":"1"},
//     {"discount_id":"332","discount_type":"1","coupon_discount":"0","price_plan_id":"18","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"333","discount_type":"1","coupon_discount":"0","price_plan_id":"18","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"2.041","blog_id":"1"},
//     {"discount_id":"334","discount_type":"1","coupon_discount":"0","price_plan_id":"18","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"2.500","blog_id":"1"},
//     {"discount_id":"335","discount_type":"1","coupon_discount":"0","price_plan_id":"79","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"1.905","blog_id":"1"},
//     {"discount_id":"336","discount_type":"1","coupon_discount":"0","price_plan_id":"79","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"2.857","blog_id":"1"},
//     {"discount_id":"337","discount_type":"1","coupon_discount":"0","price_plan_id":"79","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"338","discount_type":"1","coupon_discount":"0","price_plan_id":"79","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"2.041","blog_id":"1"},
//     {"discount_id":"339","discount_type":"1","coupon_discount":"0","price_plan_id":"79","extra_id":"0","period_from":"691200","period_till":"2678399","discount_percentage":"2.500","blog_id":"1"},
//     {"discount_id":"340","discount_type":"1","coupon_discount":"0","price_plan_id":"69","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.222","blog_id":"1"},
//     {"discount_id":"341","discount_type":"1","coupon_discount":"0","price_plan_id":"69","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"2.778","blog_id":"1"},
//     {"discount_id":"342","discount_type":"1","coupon_discount":"0","price_plan_id":"69","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"2.667","blog_id":"1"},
//     {"discount_id":"343","discount_type":"1","coupon_discount":"0","price_plan_id":"69","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"344","discount_type":"1","coupon_discount":"0","price_plan_id":"69","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"345","discount_type":"1","coupon_discount":"0","price_plan_id":"78","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"5.938","blog_id":"1"},
//     {"discount_id":"346","discount_type":"1","coupon_discount":"0","price_plan_id":"69","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"5.938","blog_id":"1"},
//     {"discount_id":"347","discount_type":"1","coupon_discount":"0","price_plan_id":"70","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.778","blog_id":"1"},
//     {"discount_id":"348","discount_type":"1","coupon_discount":"0","price_plan_id":"70","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"349","discount_type":"1","coupon_discount":"0","price_plan_id":"70","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"350","discount_type":"1","coupon_discount":"0","price_plan_id":"70","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"4.167","blog_id":"1"},
//     {"discount_id":"351","discount_type":"1","coupon_discount":"0","price_plan_id":"70","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"5.952","blog_id":"1"},
//     {"discount_id":"352","discount_type":"1","coupon_discount":"0","price_plan_id":"70","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"5.833","blog_id":"1"},
//     {"discount_id":"353","discount_type":"1","coupon_discount":"0","price_plan_id":"78","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"1.905","blog_id":"1"},
//     {"discount_id":"354","discount_type":"1","coupon_discount":"0","price_plan_id":"78","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"2.857","blog_id":"1"},
//     {"discount_id":"355","discount_type":"1","coupon_discount":"0","price_plan_id":"78","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"2.857","blog_id":"1"},
//     {"discount_id":"356","discount_type":"1","coupon_discount":"0","price_plan_id":"78","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"3.333","blog_id":"1"},
//     {"discount_id":"357","discount_type":"1","coupon_discount":"0","price_plan_id":"78","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"2.041","blog_id":"1"},
//     {"discount_id":"358","discount_type":"1","coupon_discount":"0","price_plan_id":"79","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"2.857","blog_id":"1"},
//     {"discount_id":"359","discount_type":"1","coupon_discount":"0","price_plan_id":"28","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"4.857","blog_id":"1"},
//     {"discount_id":"360","discount_type":"1","coupon_discount":"0","price_plan_id":"75","extra_id":"0","period_from":"86400","period_till":"431999","discount_percentage":"1.923","blog_id":"1"},
//     {"discount_id":"361","discount_type":"1","coupon_discount":"0","price_plan_id":"75","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"3.077","blog_id":"1"},
//     {"discount_id":"362","discount_type":"1","coupon_discount":"0","price_plan_id":"75","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"3.846","blog_id":"1"},
//     {"discount_id":"363","discount_type":"1","coupon_discount":"0","price_plan_id":"75","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"3.297","blog_id":"1"},
//     {"discount_id":"364","discount_type":"1","coupon_discount":"0","price_plan_id":"75","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"3.846","blog_id":"1"},
//     {"discount_id":"366","discount_type":"1","coupon_discount":"0","price_plan_id":"82","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"1.905","blog_id":"1"},
//     {"discount_id":"367","discount_type":"1","coupon_discount":"0","price_plan_id":"81","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.000","blog_id":"1"},
//     {"discount_id":"368","discount_type":"1","coupon_discount":"0","price_plan_id":"84","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.500","blog_id":"1"},
//     {"discount_id":"369","discount_type":"1","coupon_discount":"0","price_plan_id":"85","extra_id":"0","period_from":"86400","period_till":"259199","discount_percentage":"2.500","blog_id":"1"},
//     {"discount_id":"370","discount_type":"1","coupon_discount":"0","price_plan_id":"83","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.000","blog_id":"1"},
//     {"discount_id":"371","discount_type":"1","coupon_discount":"0","price_plan_id":"84","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"3.125","blog_id":"1"},
//     {"discount_id":"372","discount_type":"1","coupon_discount":"0","price_plan_id":"84","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"3.000","blog_id":"1"},
//     {"discount_id":"373","discount_type":"1","coupon_discount":"0","price_plan_id":"84","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"3.750","blog_id":"1"},
//     {"discount_id":"374","discount_type":"1","coupon_discount":"0","price_plan_id":"84","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"3.571","blog_id":"1"},
//     {"discount_id":"375","discount_type":"1","coupon_discount":"0","price_plan_id":"84","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"3.750","blog_id":"1"},
//     {"discount_id":"376","discount_type":"1","coupon_discount":"0","price_plan_id":"86","extra_id":"0","period_from":"86400","period_till":"259199","discount_percentage":"19.400","blog_id":"1"},
//     {"discount_id":"378","discount_type":"1","coupon_discount":"0","price_plan_id":"80","extra_id":"0","period_from":"86400","period_till":"345599","discount_percentage":"2.600","blog_id":"1"},
//     {"discount_id":"379","discount_type":"1","coupon_discount":"0","price_plan_id":"80","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"2.990","blog_id":"1"},
//     {"discount_id":"380","discount_type":"1","coupon_discount":"0","price_plan_id":"80","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"3.150","blog_id":"1"},
//     {"discount_id":"381","discount_type":"1","coupon_discount":"0","price_plan_id":"80","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"3.900","blog_id":"1"},
//     {"discount_id":"382","discount_type":"1","coupon_discount":"0","price_plan_id":"80","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"2.500","blog_id":"1"},
//     {"discount_id":"383","discount_type":"1","coupon_discount":"0","price_plan_id":"80","extra_id":"0","period_from":"691200","period_till":"1382399","discount_percentage":"3.500","blog_id":"1"},
//     {"discount_id":"384","discount_type":"1","coupon_discount":"0","price_plan_id":"86","extra_id":"0","period_from":"259200","period_till":"345599","discount_percentage":"21.400","blog_id":"1"},
//     {"discount_id":"385","discount_type":"1","coupon_discount":"0","price_plan_id":"86","extra_id":"0","period_from":"345600","period_till":"431999","discount_percentage":"21.700","blog_id":"1"},
//     {"discount_id":"386","discount_type":"1","coupon_discount":"0","price_plan_id":"86","extra_id":"0","period_from":"432000","period_till":"518399","discount_percentage":"21.900","blog_id":"1"},
//     {"discount_id":"387","discount_type":"1","coupon_discount":"0","price_plan_id":"86","extra_id":"0","period_from":"518400","period_till":"604799","discount_percentage":"22.550","blog_id":"1"},
//     {"discount_id":"388","discount_type":"1","coupon_discount":"0","price_plan_id":"86","extra_id":"0","period_from":"604800","period_till":"691199","discount_percentage":"21.650","blog_id":"1"},
//     {"discount_id":"389","discount_type":"1","coupon_discount":"0","price_plan_id":"86","extra_id":"0","period_from":"691200","period_till":"2678399","discount_percentage":"22.150","blog_id":"1"}
//     ] 



// GROUPNAMES = [{'atv_1':'ATV','sc_125':'SCOOTER 125','sc_200':'SCOOTER 200','cls_a':'CLASS A',
// 'cls_b':'CLASS B','cls_c':'CLASS C','cls_d':'CLASS D','cls_ba':'CLASS BA'}]
// // Initial Commit Content
// PRICEPLANS = 
// [
//     {"price_plan_id":"2","price_group_id":"atv_1","coupon_code":"","start_timestamp":"1569888000","end_timestamp":"1590969599","daily_rate_mon":"24.19","daily_rate_tue":"24.19","daily_rate_wed":"24.19","daily_rate_thu":"24.19","daily_rate_fri":"24.19","daily_rate_sat":"24.19","daily_rate_sun":"24.19","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"9","price_group_id":"cls_a","coupon_code":"","start_timestamp":"1561075200","end_timestamp":"1563580799","daily_rate_mon":"24.19","daily_rate_tue":"24.19","daily_rate_wed":"24.19","daily_rate_thu":"24.19","daily_rate_fri":"24.19","daily_rate_sat":"24.19","daily_rate_sun":"24.19","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"10","price_group_id":"cls_b","coupon_code":"","start_timestamp":"1566345600","end_timestamp":"1569887999","daily_rate_mon":"24.19","daily_rate_tue":"24.19","daily_rate_wed":"24.19","daily_rate_thu":"24.19","daily_rate_fri":"24.19","daily_rate_sat":"24.19","daily_rate_sun":"24.19","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"11","price_group_id":"cls_c","coupon_code":"","start_timestamp":"1561075200","end_timestamp":"1563580799","daily_rate_mon":"32.26","daily_rate_tue":"32.26","daily_rate_wed":"32.26","daily_rate_thu":"32.26","daily_rate_fri":"32.26","daily_rate_sat":"32.26","daily_rate_sun":"32.26","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"12","price_group_id":"cls_d","coupon_code":"","start_timestamp":"1561075200","end_timestamp":"1563580799","daily_rate_mon":"36.29","daily_rate_tue":"36.29","daily_rate_wed":"36.29","daily_rate_thu":"36.29","daily_rate_fri":"36.29","daily_rate_sat":"36.29","daily_rate_sun":"36.29","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"13","price_group_id":"cls_a","coupon_code":"","start_timestamp":"1563580800","end_timestamp":"1565049599","daily_rate_mon":"28.23","daily_rate_tue":"28.23","daily_rate_wed":"28.23","daily_rate_thu":"28.23","daily_rate_fri":"28.23","daily_rate_sat":"28.23","daily_rate_sun":"28.23","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"14","price_group_id":"cls_b","coupon_code":"","start_timestamp":"1563580800","end_timestamp":"1565049599","daily_rate_mon":"32.26","daily_rate_tue":"32.26","daily_rate_wed":"32.26","daily_rate_thu":"32.26","daily_rate_fri":"32.26","daily_rate_sat":"32.26","daily_rate_sun":"32.26","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"15","price_group_id":"cls_c","coupon_code":"","start_timestamp":"1566345600","end_timestamp":"1569887999","daily_rate_mon":"28.23","daily_rate_tue":"28.23","daily_rate_wed":"28.23","daily_rate_thu":"28.23","daily_rate_fri":"28.23","daily_rate_sat":"28.23","daily_rate_sun":"28.23","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"16","price_group_id":"cls_d","coupon_code":"","start_timestamp":"1566345600","end_timestamp":"1569887999","daily_rate_mon":"32.26","daily_rate_tue":"32.26","daily_rate_wed":"32.26","daily_rate_thu":"32.26","daily_rate_fri":"32.26","daily_rate_sat":"32.26","daily_rate_sun":"32.26","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"18","price_group_id":"cls_b","coupon_code":"","start_timestamp":"1561075200","end_timestamp":"1563580799","daily_rate_mon":"28.23","daily_rate_tue":"28.23","daily_rate_wed":"28.23","daily_rate_thu":"28.23","daily_rate_fri":"28.23","daily_rate_sat":"28.23","daily_rate_sun":"28.23","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"28","price_group_id":"cls_d","coupon_code":"","start_timestamp":"1563580800","end_timestamp":"1565049599","daily_rate_mon":"40.32","daily_rate_tue":"40.32","daily_rate_wed":"40.32","daily_rate_thu":"40.32","daily_rate_fri":"40.32","daily_rate_sat":"40.32","daily_rate_sun":"40.32","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"30","price_group_id":"cls_b","coupon_code":"","start_timestamp":"1565049600","end_timestamp":"1566345599","daily_rate_mon":"40.32","daily_rate_tue":"40.32","daily_rate_wed":"40.32","daily_rate_thu":"40.32","daily_rate_fri":"40.32","daily_rate_sat":"40.32","daily_rate_sun":"40.32","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"33","price_group_id":"cls_a","coupon_code":"","start_timestamp":"1558310400","end_timestamp":"1561075199","daily_rate_mon":"20.16","daily_rate_tue":"20.16","daily_rate_wed":"20.16","daily_rate_thu":"20.16","daily_rate_fri":"20.16","daily_rate_sat":"20.16","daily_rate_sun":"20.16","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"34","price_group_id":"cls_b","coupon_code":"","start_timestamp":"1558310400","end_timestamp":"1561075199","daily_rate_mon":"24.19","daily_rate_tue":"24.19","daily_rate_wed":"24.19","daily_rate_thu":"24.19","daily_rate_fri":"24.19","daily_rate_sat":"24.19","daily_rate_sun":"24.19","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"36","price_group_id":"cls_d","coupon_code":"","start_timestamp":"1558310400","end_timestamp":"1561075199","daily_rate_mon":"32.26","daily_rate_tue":"32.26","daily_rate_wed":"32.26","daily_rate_thu":"32.26","daily_rate_fri":"32.26","daily_rate_sat":"32.26","daily_rate_sun":"32.26","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"37","price_group_id":"sc_200","coupon_code":"","start_timestamp":"1569888000","end_timestamp":"1590969599","daily_rate_mon":"17.74","daily_rate_tue":"17.74","daily_rate_wed":"17.74","daily_rate_thu":"17.74","daily_rate_fri":"17.74","daily_rate_sat":"17.74","daily_rate_sun":"17.74","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"38","price_group_id":"atv_1","coupon_code":"","start_timestamp":"1590969600","end_timestamp":"1593561599","daily_rate_mon":"32.26","daily_rate_tue":"32.26","daily_rate_wed":"32.26","daily_rate_thu":"32.26","daily_rate_fri":"32.26","daily_rate_sat":"32.26","daily_rate_sun":"32.26","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"39","price_group_id":"atv_1","coupon_code":"","start_timestamp":"1561939200","end_timestamp":"1564617599","daily_rate_mon":"36.29","daily_rate_tue":"36.29","daily_rate_wed":"36.29","daily_rate_thu":"36.29","daily_rate_fri":"36.29","daily_rate_sat":"36.29","daily_rate_sun":"36.29","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"40","price_group_id":"atv_1","coupon_code":"","start_timestamp":"1564617600","end_timestamp":"1567295999","daily_rate_mon":"44.35","daily_rate_tue":"44.35","daily_rate_wed":"44.35","daily_rate_thu":"44.35","daily_rate_fri":"44.35","daily_rate_sat":"44.35","daily_rate_sun":"44.35","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"42","price_group_id":"sc_200","coupon_code":"","start_timestamp":"1590969600","end_timestamp":"1593561599","daily_rate_mon":"19.35","daily_rate_tue":"19.35","daily_rate_wed":"19.35","daily_rate_thu":"19.35","daily_rate_fri":"19.35","daily_rate_sat":"19.35","daily_rate_sun":"19.35","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"43","price_group_id":"sc_200","coupon_code":"","start_timestamp":"1561939200","end_timestamp":"1564617599","daily_rate_mon":"20.97","daily_rate_tue":"20.97","daily_rate_wed":"20.97","daily_rate_thu":"20.97","daily_rate_fri":"20.97","daily_rate_sat":"20.97","daily_rate_sun":"20.97","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"44","price_group_id":"sc_200","coupon_code":"","start_timestamp":"1564617600","end_timestamp":"1567295999","daily_rate_mon":"23.39","daily_rate_tue":"23.39","daily_rate_wed":"23.39","daily_rate_thu":"23.39","daily_rate_fri":"23.39","daily_rate_sat":"23.39","daily_rate_sun":"23.39","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"46","price_group_id":"sc_125","coupon_code":"","start_timestamp":"1569888000","end_timestamp":"1590969599","daily_rate_mon":"14.52","daily_rate_tue":"14.52","daily_rate_wed":"14.52","daily_rate_thu":"14.52","daily_rate_fri":"14.52","daily_rate_sat":"14.52","daily_rate_sun":"14.52","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"47","price_group_id":"sc_125","coupon_code":"","start_timestamp":"1590969600","end_timestamp":"1593561599","daily_rate_mon":"16.13","daily_rate_tue":"16.13","daily_rate_wed":"16.13","daily_rate_thu":"16.13","daily_rate_fri":"16.13","daily_rate_sat":"16.13","daily_rate_sun":"16.13","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"48","price_group_id":"sc_125","coupon_code":"","start_timestamp":"1561939200","end_timestamp":"1564617599","daily_rate_mon":"17.74","daily_rate_tue":"17.74","daily_rate_wed":"17.74","daily_rate_thu":"17.74","daily_rate_fri":"17.74","daily_rate_sat":"17.74","daily_rate_sun":"17.74","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"49","price_group_id":"sc_125","coupon_code":"","start_timestamp":"1564617600","end_timestamp":"1567295999","daily_rate_mon":"20.16","daily_rate_tue":"20.16","daily_rate_wed":"20.16","daily_rate_thu":"20.16","daily_rate_fri":"20.16","daily_rate_sat":"20.16","daily_rate_sun":"20.16","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"50","price_group_id":"sc_125","coupon_code":"","start_timestamp":"1567296000","end_timestamp":"1569887999","daily_rate_mon":"16.13","daily_rate_tue":"16.13","daily_rate_wed":"16.13","daily_rate_thu":"16.13","daily_rate_fri":"16.13","daily_rate_sat":"16.13","daily_rate_sun":"16.13","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"52","price_group_id":"cls_a","coupon_code":"","start_timestamp":"1569888000","end_timestamp":"1588291199","daily_rate_mon":"15.00","daily_rate_tue":"15.00","daily_rate_wed":"15.00","daily_rate_thu":"15.00","daily_rate_fri":"15.00","daily_rate_sat":"15.00","daily_rate_sun":"15.00","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"53","price_group_id":"cls_b","coupon_code":"","start_timestamp":"1556668800","end_timestamp":"1558310399","daily_rate_mon":"20.16","daily_rate_tue":"20.16","daily_rate_wed":"20.16","daily_rate_thu":"20.16","daily_rate_fri":"20.16","daily_rate_sat":"20.16","daily_rate_sun":"20.16","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"54","price_group_id":"cls_c","coupon_code":"","start_timestamp":"1569888000","end_timestamp":"1589932799","daily_rate_mon":"24.19","daily_rate_tue":"24.19","daily_rate_wed":"24.19","daily_rate_thu":"24.19","daily_rate_fri":"24.19","daily_rate_sat":"24.19","daily_rate_sun":"24.19","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"55","price_group_id":"cls_d","coupon_code":"","start_timestamp":"1569888000","end_timestamp":"1589932799","daily_rate_mon":"28.23","daily_rate_tue":"28.23","daily_rate_wed":"28.23","daily_rate_thu":"28.23","daily_rate_fri":"28.23","daily_rate_sat":"28.23","daily_rate_sun":"28.23","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"56","price_group_id":"cls_d","coupon_code":"","start_timestamp":"1556668800","end_timestamp":"1558310399","daily_rate_mon":"28.23","daily_rate_tue":"28.23","daily_rate_wed":"28.23","daily_rate_thu":"28.23","daily_rate_fri":"28.23","daily_rate_sat":"28.23","daily_rate_sun":"28.23","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"57","price_group_id":"cls_c","coupon_code":"","start_timestamp":"1556668800","end_timestamp":"1558310399","daily_rate_mon":"24.19","daily_rate_tue":"24.19","daily_rate_wed":"24.19","daily_rate_thu":"24.19","daily_rate_fri":"24.19","daily_rate_sat":"24.19","daily_rate_sun":"24.19","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"60","price_group_id":"cls_a","coupon_code":"","start_timestamp":"1556668800","end_timestamp":"1558310399","daily_rate_mon":"16.13","daily_rate_tue":"16.13","daily_rate_wed":"16.13","daily_rate_thu":"16.13","daily_rate_fri":"16.13","daily_rate_sat":"16.13","daily_rate_sun":"16.13","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"61","price_group_id":"cls_a","coupon_code":"","start_timestamp":"1565049600","end_timestamp":"1566345599","daily_rate_mon":"36.29","daily_rate_tue":"36.29","daily_rate_wed":"36.29","daily_rate_thu":"36.29","daily_rate_fri":"36.29","daily_rate_sat":"36.29","daily_rate_sun":"36.29","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"67","price_group_id":"cls_b","coupon_code":"","start_timestamp":"1569888000","end_timestamp":"1589932799","daily_rate_mon":"20.16","daily_rate_tue":"20.16","daily_rate_wed":"20.16","daily_rate_thu":"20.16","daily_rate_fri":"20.16","daily_rate_sat":"20.16","daily_rate_sun":"20.16","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"69","price_group_id":"cls_c","coupon_code":"","start_timestamp":"1563580800","end_timestamp":"1565049599","daily_rate_mon":"36.29","daily_rate_tue":"36.29","daily_rate_wed":"36.29","daily_rate_thu":"36.29","daily_rate_fri":"36.29","daily_rate_sat":"36.29","daily_rate_sun":"36.29","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"70","price_group_id":"cls_c","coupon_code":"","start_timestamp":"1565049600","end_timestamp":"1566345599","daily_rate_mon":"48.39","daily_rate_tue":"48.39","daily_rate_wed":"48.39","daily_rate_thu":"48.39","daily_rate_fri":"48.39","daily_rate_sat":"48.39","daily_rate_sun":"48.39","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"75","price_group_id":"cls_d","coupon_code":"","start_timestamp":"1565049600","end_timestamp":"1566345599","daily_rate_mon":"52.42","daily_rate_tue":"52.42","daily_rate_wed":"52.42","daily_rate_thu":"52.42","daily_rate_fri":"52.42","daily_rate_sat":"52.42","daily_rate_sun":"52.42","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"78","price_group_id":"cls_a","coupon_code":"","start_timestamp":"1566345600","end_timestamp":"1567295999","daily_rate_mon":"28.23","daily_rate_tue":"28.23","daily_rate_wed":"28.23","daily_rate_thu":"28.23","daily_rate_fri":"28.23","daily_rate_sat":"28.23","daily_rate_sun":"28.23","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"79","price_group_id":"cls_c","coupon_code":"","start_timestamp":"1558310400","end_timestamp":"1561075199","daily_rate_mon":"28.23","daily_rate_tue":"28.23","daily_rate_wed":"28.23","daily_rate_thu":"28.23","daily_rate_fri":"28.23","daily_rate_sat":"28.23","daily_rate_sun":"28.23","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"80","price_group_id":"cls_a","coupon_code":"","start_timestamp":"1567296000","end_timestamp":"1569887999","daily_rate_mon":"20.16","daily_rate_tue":"20.16","daily_rate_wed":"20.16","daily_rate_thu":"20.16","daily_rate_fri":"20.16","daily_rate_sat":"20.16","daily_rate_sun":"20.16","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"81","price_group_id":"cls_ba","coupon_code":"","start_timestamp":"1563580800","end_timestamp":"1565049599","daily_rate_mon":"32.26","daily_rate_tue":"32.26","daily_rate_wed":"32.26","daily_rate_thu":"32.26","daily_rate_fri":"32.26","daily_rate_sat":"32.26","daily_rate_sun":"32.26","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"82","price_group_id":"cls_ba","coupon_code":"","start_timestamp":"1561075200","end_timestamp":"1563580799","daily_rate_mon":"28.23","daily_rate_tue":"28.23","daily_rate_wed":"28.23","daily_rate_thu":"28.23","daily_rate_fri":"28.23","daily_rate_sat":"28.23","daily_rate_sun":"28.23","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"83","price_group_id":"cls_ba","coupon_code":"","start_timestamp":"1565049600","end_timestamp":"1566345599","daily_rate_mon":"40.32","daily_rate_tue":"40.32","daily_rate_wed":"40.32","daily_rate_thu":"40.32","daily_rate_fri":"40.32","daily_rate_sat":"40.32","daily_rate_sun":"40.32","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"84","price_group_id":"cls_ba","coupon_code":"","start_timestamp":"1566345600","end_timestamp":"1567295999","daily_rate_mon":"32.26","daily_rate_tue":"32.26","daily_rate_wed":"32.26","daily_rate_thu":"32.26","daily_rate_fri":"32.26","daily_rate_sat":"32.26","daily_rate_sun":"32.26","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"85","price_group_id":"cls_ba","coupon_code":"","start_timestamp":"1569888000","end_timestamp":"1588377599","daily_rate_mon":"15.00","daily_rate_tue":"15.00","daily_rate_wed":"15.00","daily_rate_thu":"15.00","daily_rate_fri":"15.00","daily_rate_sat":"15.00","daily_rate_sun":"15.00","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"86","price_group_id":"cls_ba","coupon_code":"","start_timestamp":"1567296000","end_timestamp":"1569887999","daily_rate_mon":"25.00","daily_rate_tue":"25.00","daily_rate_wed":"25.00","daily_rate_thu":"25.00","daily_rate_fri":"25.00","daily_rate_sat":"25.00","daily_rate_sun":"25.00","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"87","price_group_id":"sc_200","coupon_code":"","start_timestamp":"1567296000","end_timestamp":"1569887999","daily_rate_mon":"20.00","daily_rate_tue":"20.00","daily_rate_wed":"20.00","daily_rate_thu":"20.00","daily_rate_fri":"20.00","daily_rate_sat":"20.00","daily_rate_sun":"20.00","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"},
//     {"price_plan_id":"88","price_group_id":"atv_1","coupon_code":"","start_timestamp":"1567296000","end_timestamp":"1569887999","daily_rate_mon":"36.20","daily_rate_tue":"36.20","daily_rate_wed":"36.20","daily_rate_thu":"36.20","daily_rate_fri":"36.20","daily_rate_sat":"36.20","daily_rate_sun":"36.20","hourly_rate_mon":"0.00","hourly_rate_tue":"0.00","hourly_rate_wed":"0.00","hourly_rate_thu":"0.00","hourly_rate_fri":"0.00","hourly_rate_sat":"0.00","hourly_rate_sun":"0.00","seasonal_price":"1","blog_id":"1"}
//     ];

