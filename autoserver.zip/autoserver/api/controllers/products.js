var express = require("express");
var mongoose = require("mongoose");
//mongoose.set('debug', true);
var Car = mongoose.model("Cars");
var Booking = mongoose.model("Booking");
var PricePlans = mongoose.model("PricePlans");
const validatorModule = require("../validations/validators");
var Discount = mongoose.model('Discounts');


module.exports.readAllCarInfo = function (req, res) {
  Car.find(function (err, carList) {
    if (err) res.send(err);
    res.json(carList);
  });
};
// module.exports.postCarInfor = function (req, res) { 
//   res.status(200).send("Items save to database");
// };

module.exports.carsReadByName = function (req, res) {
  Cars.findOne({ name: "Nissan Altima" }, function (err, cars) {
    if (err) res.send(err);
    res.json(cars);
  });
};

//search car info by id or custom id
module.exports.searchCarbyID = function (req, res) {
  var idType = "_id";
  var idString = req.params.id;
  if (idString != null && idString.includes("atlk_")) {
    idType = "car_id";
  }
  Car.findOne({ [idType]: idString }, function (err, car) {
    if (err) res.send(err);
    res.json(car);
  });
};

//search car info by pick up locations
module.exports.searchCarProduct = function (req, res) {
  var key = req.params.pickupLoc;
  Car.find({ pickupLoc: { $regex: key, $options: "i" } }, function (err, cars) {
    if (err) res.send(err);
    //console.log(cars);
    res.json(cars);
  });
};

// Tmilios - Function to get Price Plan Discount
getPlanDiscount = async function (req, res) {
  // Percentage applied on plan se to 1 in case of no discount
  let percenatage = 50;
  // Days of car request
  let daysNum = Number(req.body.planDaysReq);
 const daysNumConv =  Math.floor(daysNum / (3600*24));
  // Car Plan Price Id in request
  let price_plan_id = req.body.price_plan_id;
  try {
    // Retrieve all Discounts per ID.
    const discounts = await Discount.find({ price_plan_id: price_plan_id }).exec();
    // Loop if many discounts @TODO for Future Use
    for (const discount of discounts) {
      // console.log('discounts',discounts)
      // Numbers of Days discount Start
      let from = Number(discount.period_from);
      // Number of days discount ends
      let until = Number(discount.period_till);
      // Filter Discounts number of days of the request.
      const fromConv =Math.floor(from / (3600*24));
      const toConv = Math.floor(until / (3600*24));
      if ((fromConv != null && fromConv <= daysNumConv) && (toConv != null && toConv >= daysNumConv)) {
        // Set Discount Percentage found for plan
        // Return discount in an object to avoid exception 
        percenatage = discount.discount_percentage ? discount.discount_percentage : percenatage;
      }
    }
    //Return the discount. 
    return percenatage;
  } catch (err) {
    console.log(err);
    throw err;
  }

}
// Tmilios Async Get Car Plans by id and dates
getCarPlans = async function (req, res, next) {
  try {
    var pricegroup = req.body.pricegroup;
    var pickDate = Number(req.body.fromTimestamp);
    var returnDate = Number(req.body.toTimestamp);
    const carplans = await PricePlans.find({
      $and: [
        { price_group_id: { $in: pricegroup } },
        {
          $or: [{ $and: [{ start_timestamp: { $lte: pickDate } }, { end_timestamp: { $gte: pickDate } }] },
          { $and: [{ start_timestamp: { $lte: returnDate } }, { end_timestamp: { $gte: returnDate } }] },
          { $and: [{ start_timestamp: { $gt: pickDate } }, { end_timestamp: { $lt: returnDate } }] }]
        }]
    }).sort({ start_timestamp: 'asc' }).exec();
    return carplans;
  } catch (err) {
    console.log(err);
  }
}

// @Tmilios Get Available car ID's
getCarIds = async function (req, res, next) {
  try {
    var pickDate = Number(req.body.fromTimestamp);
    var returnDate = Number(req.body.toTimestamp);
    const date1 = new Date(Number(pickDate));
    const date2 = new Date(Number(returnDate));
    console.log('date1',date1);
    console.log('date2',date2) 

    const carIDs = await Booking.find({ "pickDateTimeStamp": { "$lt": returnDate }, "returnDateTimeStamp": { "$gt": pickDate } })
      .distinct("car_id").exec();
      console.log('carIDs',carIDs)
    return carIDs;
  } catch (err) {
    console.log(err);
  }
}

//@Tmilios
checkInventory = function (foundList) {
  let fiat_panda_9 = 'atlk_CARB_FIAT_P01';
  let ford_fiesta_2 = 'atlk_CARC_FF_01';
  let hyundai_i10_2 = 'atlk_CARA_HY_I01';
  let atv_quad_2 = 'atlk_ATV_250_MXU_01';

  // Check Fiat Panda
  if (foundList.filter(i => i === fiat_panda_9).length < 9) {
    // More Fiat Pandas in Inventory  - 
    //Remove item from found bookings to display on search
    foundList = foundList.filter(function (element) {
      return element !== fiat_panda_9;
    })
  }
  // Check hyundai i10
  if (foundList.filter(i => i === hyundai_i10_2).length < 2) {
    // More Fiat Pandas in Inventory  - 
    //Remove item from found bookings to display on search
    foundList = foundList.filter(function (element) {
      return element !== hyundai_i10_2;
    })
  }
  // Check Fiat Fond Fiesta
  if (foundList.filter(i => i === ford_fiesta_2).length < 2) {
    // More Fiat Pandas in Inventory  - 
    //Remove item from found bookings to display on search
    foundList = foundList.filter(function (element) {
      return element !== ford_fiesta_2;
    })
  }

  // Check atv quad
  if (foundList.filter(i => i === atv_quad_2).length < 2) {
    // More Fiat Pandas in Inventory  - 
    //Remove item from found bookings to display on search
    foundList = foundList.filter(function (element) {
      return element !== atv_quad_2;
    })
  }
  return foundList;

}

// @Tmilios Get Full Car List
getAllCars = async function (carIds, isSingle) {
  try {
    let cars = [];
    if (carIds[0] === undefined) {
      cars = await Car.find().exec();
    }
    if (isSingle) {
      cars = await Car.find({ car_id: { $in: carIds } }).exec();
    }
    else {
      cars = await Car.find({ car_id: { $nin: carIds } }).exec();
    }
    return cars;
  } catch (err) {
    console.log(err);
    throw err;
  }
}

// @Tmilios Get Full Car List
calcPrices = function (numData) {
  try {
    // Dicount Percentage  
    let discount = numData.percentage ? (numData.percentage / 100) : 1;
    // Number of days of request
    let days = numData.days ? numData.days : 1;
    // Average Daily Price 
    let avgPrice = numData.avgPrice ? numData.avgPrice : 1;
    // Calculate Tax
    let taxAmmount = avgPrice * .23;

    // Add tax to ammount
    avgPrice = Math.ceil((avgPrice + taxAmmount) * 2) / 2;
    // Price Object to be sent to user
    let prices = {};
    // Calculate Daily Rate  
    let discountedDailyRate = avgPrice - (avgPrice * discount);
    // Round Up Full Price
    prices.fullPrice = Math.ceil(days * discountedDailyRate);
    // Round up Daily Price
    prices.dayPrice = Math.ceil(discountedDailyRate);
    // Calculate Insurance cost
    prices.insurance = numData.scooter ? 5 * days : 10 * days;
    // Return Price object  
    return prices;
  } catch (err) {
    console.log(err);
    throw err;
  }
}

timediff = function (timestamp1, timestamp2) {
  var difference = timestamp1 - timestamp2;
  var daysDifference = Math.ceil(difference / 1000 / 60 / 60 / 24);

  return daysDifference;
}

roundDate = function (timeStamp) {
  timeStamp -= timeStamp % (24 * 60 * 60 * 1000);//subtract amount of time since midnight
  timeStamp += new Date().getTimezoneOffset() * 60 * 1000;//add on the timezone offset
  return new Date(timeStamp);
}

//NEW PRICE CALCULATIONS..
calcPricesNew = function (numData) {
  try {
    // Dicount Percentage  
    let discount = numData.percentage ? (numData.percentage / 100) : 1;
    // Number of days of request
    let days = numData.days ? numData.days : 1;
    // Average Daily Price 
    let avgPrice = numData.avgPrice ? numData.avgPrice : 1;
    // Calculate Tax
    let taxAmmount = avgPrice * .23;

    // Add tax to ammount
    avgPrice = Math.ceil((avgPrice + taxAmmount) * 2) / 2;
    // Price Object to be sent to user
    let prices = {};
    // Calculate Daily Rate  
    let discountedDailyRate = avgPrice - (avgPrice * discount);
    // Round Up Full Price
    prices.fullPrice = Math.ceil(days * discountedDailyRate);
    // Round up Daily Price
    prices.dayPrice = Math.ceil(discountedDailyRate);
    // Calculate Insurance cost
    prices.insurance = numData.scooter ? 5 * days : 10 * days;
    // Return Price object  
    return prices;
  } catch (err) {
    console.log(err);
    throw err;
  }
}


// @Tmilios New Days in Plans
daysInPlans = async function (request, plans) {
  try {
    let totals = [];
    let deltaTimeinPLan; 
    
    let counter = 0;
    for (let plan of plans) {

      if (request.toTimestamp < plan.end_timestamp && request.fromTimestamp > plan.start_timestamp ) {
        console.log('------------------')
        console.log('plan within the limits',counter)
        //Get the days of request in the plan
        deltaTimeinPLan = request.toTimestamp - request.fromTimestamp;
        let days = Math.ceil((deltaTimeinPLan / (60 * 60 * 24 * 1000)))
        console.log('#1 days are:' ,days)
        console.log('------------------')
       
      }
     
      if (request.toTimestamp < plan.end_timestamp && request.fromTimestamp < plan.start_timestamp ) {
        console.log('------------------')
        console.log('counter <2',counter)
        //Get the days of request in the plan
        deltaTimeinPLan = request.toTimestamp - plan.start_timestamp;
        let days = Math.ceil((deltaTimeinPLan / (60 * 60 * 24 * 1000)))
        console.log('#2 less than' ,days)
        console.log('------------------')

        
       
      } if (request.toTimestamp >  plan.end_timestamp && plans.length == 2) {
        //calculate days in plan and aply discoun 
        deltaTimeinPLan =plan.end_timestamp - request.fromTimestamp;
        let days = Math.ceil((deltaTimeinPLan / (60 * 60 * 24 * 1000)))  // console.log('deltaTimeinPLan1',discount)
        console.log('------------------')

       console.log( '#3 days',days)
       console.log('------------------')
       console.log('counter =2',counter)
       console.log('------------------')


      }if (request.toTimestamp >  plan.end_timestamp && plans.length !== 2) {
        deltaTimeinPLan =plan.end_timestamp - plan.start_timestamp  ;
        let days = Math.ceil((deltaTimeinPLan / (60 * 60 * 24 * 1000)))  // console.log('deltaTimeinPLan1',discount)
        console.log('------------------')

        console.log(' #4 days' ,days)
        console.log('------------------')

        console.log('counter >2',counter)
        console.log('------------------')

      }
      // console.log('THE PLANS',plan)
     counter ++;
    }

  } catch (err) {
    console.log(err);
    throw err;
  }
}

getNumbersOfDays = function(fromTimestamp, toTimeStamp) {
  const date1 = new Date(Number(fromTimestamp));
  const date2 = new Date(Number(toTimeStamp));
  // To calculate the time difference of two dates
  const Difference_In_Time = date2.getTime() - date1.getTime();
  // To calculate the no. of days between two dates
  const Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
  return Math.ceil(Difference_In_Days);
 }

//@Tmilios Search Module
module.exports.searchCarwithOptions = async function (req, res) {
  // Begin Validation
  const { error } = validatorModule("searchCarwithOptions", req.body);
  if (error) {
    const errors = {};
    error.details.forEach(err => (errors[err.context.key] = err.message));
    return res.status(400).send(errors);
  }

  // Final Car List sent to resposne 
  let carsReponse = [];
  // Set Car Id's to Return data
  var carIds;
  // If single car Request
  var isSingle = false;

  // Search on Car Page - Check if CarID exists
  if (req.body.car_id.includes('atlk')) {
    carIds = [req.body.car_id];
    isSingle = true;
  }
  else {
    // Get Car Already Booked Car ID's
    carIds = await getCarIds(req, res);

    //Check inventory of carId's
   // carIds = checkInventory(carIds);

  }
  let carList = await getAllCars(carIds, isSingle);
  // Get Plan Price Plans For each Car 

  for (const car of carList) {
    // Price Group ID car belongs to
    req.body.pricegroup = car.priceroups;
    // Price Plans that a car has(if many days it might be more than one)
    let plans = await getCarPlans(req, res);
    // console.log('plans',plans) 

    // Data to calculate price
    let numData = {};
    // Calculate Insurance Cost
    numData.scooter = car.car_id.includes('atlk_SCTR') ? true : false;

    // Intialize Price object
    car.pricing = {
      'fullPrice': 0,
      'dayPrice': 0,
      'totalDays': 0,
      'insurance': 0
    };
    // Total Days in seconds
    let dayInSeconds = (Number(req.body.toTimestamp) - Number(req.body.fromTimestamp)) / 1000;
    // Total Days i
    let totalReqDays = (Math.ceil(dayInSeconds / (3600 * 24)));
    // Get Discount for plan and apply it on price
    // If Multiple plans applied(e.x many months)
    if (plans.length > 1) {
      // loop to get the discount to be applied on each plan
      for (const [index, plan] of plans.entries()) {
        if (index === 0) { 
          // Number of days in Seconds - For Discount Find
          req.body.planDaysReq = (Number(plan.end_timestamp) - Number(req.body.fromTimestamp)) / 1000;

          numberOfDays = Math.ceil(req.body.planDaysReq / (3600 * 24));
        } else {
         

          // define price plan end date(ending within plan or if next plan set last day of this plan)
          pricePlanEndDate = (Number(req.body.toTimestamp) - Number(plan.end_timestamp)) <= 0 ? Number(req.body.toTimestamp) : Number(plan.end_timestamp);
          // Number of days in Seconds - For Discount Find
          req.body.planDaysReq = (pricePlanEndDate - Number(plans[index - 1].end_timestamp)) / 1000;
          numberOfDays = Math.ceil(req.body.planDaysReq / (3600 * 24));
        }
        // CALCULATE PRICE - Total - Per Day Average
        // Plan id to request the Analogous Discount
        req.body.price_plan_id = plan.plan_id;
        // Discount Percentage Applied
        numData.percentage = await getPlanDiscount(req, res);

        // Seconds to Days convertion 
        //  console.log('req.body.planDaysReq', req.body.planDaysReq)
        numData.days = Math.ceil(req.body.planDaysReq / (3600 * 24));
        // Average price declared on plan(Discount will apply on it)
        numData.avgPrice = plan.daily_rate_mon;
        // console.log(plan);
        // Retrieve Car Cost per Request
        let prices = calcPrices(numData);
        // console.log(prices);
        if (prices != null || prices != '') {
          // Set Car Full Price per Request
          car.pricing.fullPrice += prices.fullPrice;
        }
        // Set Car Daily Request per Request
        car.pricing.dayPrice = (Math.ceil(car.pricing.fullPrice / totalReqDays));
        car.pricing.totalDays = totalReqDays;
        car.pricing.insurance = prices.insurance;
      }
      // Add Car To the responce  
      carsReponse.push(car);
    }//Else olny one plan per car
    else if (plans.length === 1) {
      // Get Discount for plan and days of request
      req.body.planDaysReq = (Number(req.body.toTimestamp) - Number(req.body.fromTimestamp)) / 1000;
      req.body.price_plan_id = plans[0].plan_id;
      // CALCULATE PRICE - Total - Per Day Average
      // Discount Percentage Applied
      numData.percentage = await getPlanDiscount(req, res);
    

      // Seconds to Days convertion 
      numData.days = Math.ceil(req.body.planDaysReq / (3600 * 24));
      // Average price declared on plan(Discount will apply on it)
      numData.avgPrice = plans[0].daily_rate_mon;
      // Retrieve Car Cost per Request
      let prices = calcPrices(numData);
      if (prices != null || prices != '') {
        // Set Car Full Price per Request
        car.pricing.fullPrice = prices.fullPrice;
        // Set Car Daily Request per Request
        car.pricing.dayPrice = prices.dayPrice;
        car.pricing.totalDays = totalReqDays;
        car.pricing.insurance = prices.insurance;
        carsReponse.push(car);
      }
    }
  } 
  return res.status(200).json(carsReponse);

};


//@Tmilios Search Module
// module.exports.searchCarwithOptionsx = async function (req, res) {
//   console.log("in car");
//   const { error } = validateSearchModule("searchCarwithOptions", req.body);
//   if (error) {
//     const errors = {};
//     error.details.forEach(err => (errors[err.context.key] = err.message));
//     return res.status(400).send(errors);
//   }
//   var pickDate = Number(req.body.fromTimestamp);
//   // var pickTime = req.body.pickTime;
//   var returnDate = Number(req.body.toTimestamp);
//   // var returnTime = req.body.returnTime;
//   // var gbox = req.body.gbox; 
//   // Booking.find([{ pickDateTimeStamp: { $lt: pickDate } }, { returnDateTimeStamp: { $gte: returnDate } }])

//   // Step #1 - Serach Cars with bookings in these timeframe
//   Booking.find({ "pickDateTimeStamp": { "$lt": returnDate }, "returnDateTimeStamp": { "$gt": pickDate } })
//     .distinct("car_id")
//     .exec(function (err, carIds) {
//       // Step #2 - If no bookings retrieve all cars
//       if (carIds[0] === undefined) {
//         Car.find()
//           .then(allCars => {
//             // Step #3 - Retrieve pricegroup of each car for time period in request
//             allCars.forEach(car => {
//               console.log('car', car.priceroups)
//               req.param('priceroup') === car.priceroups;
//               // var plans = await getCarPlans(req, res);
//               // console.log('plans',plans);

//             });
//           })
//           .catch(error => console.log(error));
//       } else {
//         // Step #2 - If  bookings retrieve all cars and exlude car id's found
//         Car.find({ car_id: { $nin: carIds } }).lean()
//           .then(carFound => {
//             // Step #3 - Retrieve pricegroup of each car for time period in request
//             carFound.forEach(car => {
//               console.log('carFound.priceroups', car.priceroups);
//               PricePlans.find({ price_group_id: { $in: car.priceroups }, start_timestamp: { "$lt": returnDate }, end_timestamp: { "$gt": pickDate } }, function (err, plan) {
//                 // Step #4 - If one plan get disount and calculate price.
//                 if (plan.length === 1) {
//                   //       console.log('one plan');
//                   // console.log(plan) 
//                 }
//                 // Step #4 - If many get discounts and calucate days of dicount policy.
//                 else {
//                   console.log('many plan');
//                   console.log('car', car);
//                   console.log('car.priceroups ', car.priceroups)
//                   console.log(plan)
//                 }
//                 if (err) res.send(err);
//                 // res.json(plan);
//               }).lean();
//             });
//             //console.log(carFound);
//           })
//           .catch(error => {
//             console.log(error);
//           });
//       }
//     });
// };

module.exports.searchCarwithFilter = function (req, res) {
  console.log("filter-----");
  var loc = req.params.pickupLoc;
  var types = req.params.carType;
  var cartypes = types.split(",");
  var psgnum = req.params.passNum;
  var primax = req.params.priceMax;
  var primin = req.params.priceMin;
  if (loc == "AllTypes") {
    Car.find({ price: { $gte: primin, $lte: primax }, type: { $in: cartypes }, passengers: { $lte: psgnum } }, function (err, cars) {
      if (err) res.send(err);
      res.json(cars);
    });
  } else {
    var cartypes = types.split(",");
    Car.find({ pickupLoc: { $regex: loc, $options: "i" }, price: { $gte: primin, $lte: primax }, type: { $in: cartypes }, passengers: { $lte: psgnum } }, function (err, cars) {
      if (err) res.send(err);
      res.json(cars);

    });
  }
};

module.exports.createCar = function (req, res) {
  var car = new Cars(req.body);
  car.save(function (err) {
    if (err) {
      return res.send(err);
    }
    console.log("Car Created");
  });
};

module.exports.deleteCarbyId = function (req, res) {
  // Cars.delete({_id:req.params.id}, function (err) {
  //     if(err)
  //         return res.send(err);
  //     console.log('Car Delelted');
  // })
  console.log("enter delete");
  console.log(req.params.id);
  Car.update(
    { _id: req.params.id },
    {
      $set: { isavailable: false }
    },
    function (err, affected, resp) {
      if (err) {
        return res.send(err);
      }
    }
  );
  res.send("Delete Success!");
};

///////////////// DEMO DATA \\\\\\\\\\\\\\\\\\\\\\\\\\

module.exports.updateCarInfo = function (req, res) {
  console.log("---updateCarInfo ---");
  console.log(req.body);
  Car.update(
    { _id: req.body._id },
    {
      $set: {
        name: req.body.name,
        type: req.body.type,
        imageName: req.body.imageName,
        passengers: req.body.passengers,
        luggage: req.body.luggage,
        price: req.body.price,
        ACsup: req.body.ACsup,
        isAuto: req.body.isAuto,
        pickupLoc: req.body.pickupLoc,
        insurance: req.body.insurance
      }
    },
    function (err, affected, resp) {
      if (err) {
        return res.send(err);
      }
    }
  );
  console.log("update success");
};

///// Demo Content \\\\\

//Tmilios - Working - Create Init Contex
module.exports.createCarContext = function (req, res) {
  // var carInfor = new Car(req.body);
  console.log("in  createCarContext");
  var carInfor;
  CARS.forEach(function (item) {
    console.log("inere");
    console.log(item);
    carInfor = new Car(item);
    console.log(carInfor);
    carInfor
      .save()
      .then(item => {
        console.log("item saved to database");
        if (res.length === CARS.length) {
          res.status(200).send("Items save to database");
        }
      })
      .catch(err => {
        res.status(400).send("unable to save to database");
      });
  });
  return readAllCarInfo();
};
CARS = [
  // {
  //   car_id: "atlk_CARB_KIA_P01",
  //   group: "Car Class B",
  //   maxUnits: 1,
  //   url:"kia-picanto",
  //   unitNumber: 1,
  //   name: "KIA Picanto",
  //   type: "CAR",
  //   gearbox: "AUTOMATIC",
  //   imageName: "/assets/vehicleImages/car/CARB-KIA-PICANTO-WHITE.jpg",
  //   passengers: 4,
  //   price: 22.0,
  //   priceroups: "cls_b",
  //   manufacturer: "Kia",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_CARB_FIAT_P01",
  //   group: "Car Class B",
  //   url:"fiat-panta-class-b",
  //   maxUnits: 4,
  //   unitNumber: 1,
  //   name: "Fiat Panda",
  //   type: "CAR",
  //   gearbox: "MANUAL",
  //   imageName: "/assets/vehicleImages/car/CARB-FIAT-PANDA.jpg",
  //   passengers: 4,
  //   price: 22.0,
  //   priceroups: "cls_b",
  //   manufacturer: "FIAT",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // }
  // },
  // {
  //   car_id: "atlk_SCTR_125_LK_01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "Like 125cc",
  //   type: "SCOOTER",
  //   gearbox: "AUTOMATIC",
  //   imageName: "/assets/vehicleImages/moto/SC-LIKE-125.jpg",
  //   passengers: 2,
  //   price: 28.0,
  //   priceroups: "CLASS A",
  //   manufacturer: "Yamaha",
  //   mileage: "Unlimited",
  //   engine: "125cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_SCTR_200_AP_01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "Agility Plus 200cc",
  //   type: "SCOOTER",
  //   gearbox: "AUTOMATIC",
  //   imageName: "/assets/vehicleImages/moto/SC-AGILITY-200.jpg",
  //   passengers: 2,
  //   price: 32.0,
  //   priceroups: "CLASS A",
  //   manufacturer: "Yamaha",
  //   mileage: "Unlimited",
  //   engine: "125cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_ATV_250_MXU_01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "ATV MXU 250R",
  //   type: "ATV",
  //   gearbox: "AUTOMATIC",
  //   imageName: "/assets/vehicleImages/moto/ATV-MXU-250R-2.jpg",
  //   passengers: 2,
  //   price: 54.0,
  //   priceroups: "CLASS A",
  //   manufacturer: "Yamaha",
  //   mileage: "Unlimited",
  //   engine: "125cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_CARD_VW_P01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "VW POLO",
  //   type: "CAR",
  //   gearbox: "MANUAL",
  //   imageName: "/assets/vehicleImages/cars/CARC-VW-POLO-RED.jpg",
  //   passengers: 5,
  //   doors: 5,
  //   price: 27,
  //   priceroups: "CLASS C",
  //   manufacturer: "Volkswagen",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_CARA_TAYGO_01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "TOYOTA AYGO",
  //   type: "CAR",
  //   gearbox: "MANUAL",
  //   imageName: "/assets/vehicleImages/cars/CARA-TOYOTA-AGO-SILVER.jpg",
  //   passengers: 4,
  //   doors: 3,
  //   price: 37.0,
  //   priceroups: "CLASS A",
  //   manufacturer: "Toyota",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_CARA_HY_I01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "HYUNDAI I10",
  //   type: "CAR",
  //   gearbox: "MANUAL",
  //   imageName: "/assets/vehicleImages/cars/CARA-HYUNADAI-I-10-BLUE.jpg",
  //   passengers: 4,
  //   doors: 3,
  //   price: 37.0,
  //   priceroups: "CLASS A",
  //   manufacturer: "Hyundai",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_CARA_C1_01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "CITROEN C1",
  //   type: "CAR",
  //   gearbox: "MANUAL",
  //   imageName: "/assets/vehicleImages/cars/CARA-CITROEN-CI-BLACK.jpg",
  //   passengers: 4,
  //   doors: 3,
  //   price: 37.0,
  //   priceroups: "CLASS A",
  //   manufacturer: "Citroen",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_CARB_RC_01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "RENAULT CLIO",
  //   type: "CAR",
  //   gearbox: "MANUAL",
  //   imageName: "/assets/vehicleImages/cars/CARB-RENAULT-CLIO-BLACK.jpg",
  //   passengers: 5,
  //   doors: 3,
  //   price: 45.0,
  //   priceroups: "CLASS B",
  //   manufacturer: "Renault",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_CARB_NM_01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "NISSAN MICRA blue",
  //   type: "CAR",
  //   gearbox: "MANUAL",
  //   imageName: "/assets/vehicleImages/cars/CARB-NISSAN-MICRA-BLUE.jpg",
  //   passengers: 5,
  //   doors: 5,
  //   price: 22.0,
  //   priceroups: "CLASS B",
  //   manufacturer: "Nissan",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_CARBA_FP_01",
  //   maxUnits: 5,
  //   unitNumber: 1,
  //   name: "FIAT PANDA",
  //   type: "CAR",
  //   gearbox: "MANUAL",
  //   imageName: "/assets/vehicleImages/cars/CARBA-FIAT-PANDA-WHITE.jpg",
  //   passengers: 5,
  //   doors: 5,
  //   price: 22.0,
  //   priceroups: "CLASS BA",
  //   manufacturer: "Fiat",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_CARC_FF_01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "FORD FIESTA",
  //   type: "CAR",
  //   gearbox: "MANUAL",
  //   imageName: "/assets/vehicleImages/cars/CARC-FORD-FIESTA-BLACK.jpg",
  //   passengers: 4,
  //   doors: 5,
  //   price: 27,
  //   priceroups: "CLASS C",
  //   manufacturer: "Ford",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_CARD_VW_G01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "VW GOLF TSI",
  //   type: "CAR",
  //   gearbox: "AUTOMATIC",
  //   imageName: "/assets/vehicleImages/cars/CARC-VW-GOLF-RED.jpg",
  //   passengers: 5,
  //   doors: 5,
  //   price: 27,
  //   priceroups: "CLASS D",
  //   manufacturer: "Volkswagen",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // {
  //   car_id: "atlk_CARD_HY_A01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "HYUNDAI ACCENT",
  //   type: "CAR",
  //   gearbox: "AUTOMATIC",
  //   imageName: "/assets/vehicleImages/cars/CARD-HYUNADAI-ACCENT-GREY.jpg",
  //   passengers: 5,
  //   doors: 5,
  //   price: 63,
  //   priceroups: "CLASS D",
  //   manufacturer: "Hyundai",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // },
  // ,
  // {
  //   car_id: "atlk_CARD_FT_C01",
  //   maxUnits: 1,
  //   unitNumber: 1,
  //   name: "FIAT 500 Cabrio",
  //   type: "CAR",
  //   gearbox: "AUTOMATIC",
  //   imageName: "/assets/vehicleImages/cars/CARD-FIAT-CABRIO-WHITE.jpg",
  //   passengers: 5,
  //   doors: 5,
  //   price: 63,
  //   priceroups: "CLASS D",
  //   manufacturer: "Fiat",
  //   mileage: "Unlimited",
  //   engine: "1600cc",
  //   fuel: "PETROL",
  //   minAge: 21
  // }
];


          // OLD PLANS
          // [
          //   {
          //     $and: [
          //       { start_timestamp: { $gte: pickDate } }, { start_timestamp: { $lte: returnDate } }
          //     ]
          //   },
          //   { start_timestamp: { $lte: pickDate }, end_timestamp: { $gte: returnDate } }
          // ]