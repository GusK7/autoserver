const nodemailer = require('nodemailer'); 
const config = require('../../config');
var emailConfig = global.gConfig.email;
const validatorModule = require("../validations/validators");
var hbs = require('nodemailer-express-handlebars');

// Create Mail Transporter

// Send Email Generic Function - Send email for other calls
sendMail = async function (mailOptions, handlebarOptions, transporter) { 
  transporter.use("compile", hbs(handlebarOptions));
  return new Promise((resolve, reject) => { 
    transporter.sendMail(mailOptions, (err, info) => {
      if (err) {
        console.error(new Error(`Email Not Send.\n\t${err}`));
        resolve(false);
      } else {
        console.info(`Email has be sent succesfully`);
        resolve(true);
      }
    });
  })
}

// Verify Transporter
verify = function () {
  transporter.verify(function (error, success) {
    if (error) {
      console.log(error);
    } else {
      console.log('Server is ready to take our messages');
    }
  });
}

// Call me Form Send Email
module.exports.callMeFrom = async function (req, res) {
  const transporter = nodemailer.createTransport({
    host: emailConfig.host,
    port: emailConfig.port,
    service:'gmail',
    //secure: false,
    auth: {
       user: emailConfig.user,
       pass: emailConfig.pass
    },
    debug: false,
    logger: true 
  
    });
  
  // Validation of form
  const { error } = validatorModule("callMeForm", req.body);
  if (error) {
    const errors = {};
    error.details.forEach(err => (errors[err.context.key] = err.message));
    return res.status(400).send(errors);
  }
  // Attach the Contact Form Template
  let handlebarOptions = {
    viewEngine: {
      extName: ".hbs",
      partialsDir: __dirname + "/templates/callMe/",
      layoutsDir: __dirname + "/templates/callMe/",
      defaultLayout: "html.hbs"
    },
    viewPath: __dirname + "/templates/callMe/",
    extName: ".hbs"
  };

  // Email Options
  let mailOptions = {
    from:'autolandbooking@gmail.com',
    to:  'autokarpathos@gmail.com',
    subject: 'Call Request from:' +req.body.fullName,
    template: "html",
    context: {
      title: req.body.subject,
      fullName: req.body.fullName,
      phone: req.body.telephone,
      callApp: req.body.callApp,
      timePreffered: req.body.timePreffered,
      callDate: req.body.callDate
    }
  };

  let isSend = await sendMail(mailOptions, handlebarOptions, transporter);
  if (isSend) {
    return res.status(200).send({ Success: "Success" });
  } else {
    return res.status(400).send({ Error: "Error" });
  }
}

// Contact Form Send Email
module.exports.contactFrom = async function (req, res) {
  const transporter = nodemailer.createTransport({
    host: emailConfig.host,
    port: emailConfig.port,
    service:'gmail',
    //secure: false,
    auth: {
       user: emailConfig.user,
       pass: emailConfig.pass
    },
    debug: false,
    logger: true 
  
    }); 
  // Validation of form
  const { error } = validatorModule("contactForm", req.body);
  if (error) { 
    const errors = {};
    error.details.forEach(err => (errors[err.context.key] = err.message)); 
    return res.status(400).send(errors);
  }

  // Attach the Contact Form Template
  let handlebarOptions = {
    viewEngine: {
      extName: ".hbs",
      partialsDir: __dirname + "/templates/contact/",
      layoutsDir: __dirname + "/templates/contact/",
      defaultLayout: "html.hbs"
    },
    viewPath: __dirname + "/templates/contact/",
    extName: ".hbs"
  };

  // Email Options
  let mailOptions = {
    from:'autolandbooking@gmail.com',
    to:  'autokarpathos@gmail.com',
    subject: 'Contact Request: ' + req.body.subject,
    template: "html",
    context: {
      title: req.body.subject,
      fullName: req.body.fullName,
      phone: req.body.phone,
      email: req.body.email,
      message: req.body.message
    }
  }; 

  let isSend = await sendMail(mailOptions, handlebarOptions, transporter);
  if (isSend) {
    return res.status(200).send({ Success: "Success" });
  } else {
    return res.status(400).send({ Error: "Error" });
  }
}

module.exports.bookingRequestForm = async function (req, res) {
  const transporter = nodemailer.createTransport({
    host: emailConfig.host,
    port: emailConfig.port,
    service:'gmail',
    //secure: false,
    auth: {
       user: emailConfig.user,
       pass: emailConfig.pass
    },
    debug: false,
    logger: true 
  
    });
  //   const { error } = validatorModule("contactForm", req.body);
  // if (error) {
  //   const errors = {};
  //   error.details.forEach(err => (errors[err.context.key] = err.message));

  //   return res.status(400).send(errors);
  // }

 // Attach the Contact Form Template 
 let handlebarOptions = {
  viewEngine: {
    extName: ".hbs",
    partialsDir: __dirname + "/templates/reservation/",
    layoutsDir: __dirname + "/templates/reservation/",
    defaultLayout: "html.hbs"
  },
  viewPath: __dirname + "/templates/reservation/",
  extName: ".hbs"
};
// Email Options
let mailOptions = {
  from: 'autolandbooking@gmail.com',
  to: req.body.driverinfo.email,
  subject: 'Autoland Karpathos - ' + 'Code: ' + req.body.bookingCode + ' Vehicle: ' + req.body.vehicleName,
  template: "html",
   context: {
     vehicle: req.body.vehicleName,
     rCode: req.body.bookingCode,
     cDate:new Date(),
     fullName: req.body.driverinfo.firstname + ' ' + req.body.driverinfo.lastname,
     country: req.body.driverinfo.country,
     phone: req.body.driverinfo.phone,
     email: req.body.driverinfo.email,
     pickUpDate: req.body.pickupdate,
     dropDate: req.body.dropoffdate,
     pickLocation: req.body.pickuploc,
     dropLocation: req.body.dropoffloc,
     totalCost: req.body.ammountTotal
   }
};

let isSend = await sendMail(mailOptions, handlebarOptions, transporter);
  if (isSend) {
    return true
  } else {
    return false;;
  }
}


module.exports.bookingAdminRequestForm = async function (req, res) {
  const transporter = nodemailer.createTransport({
    host: emailConfig.host,
    port: emailConfig.port,
    service:'gmail',
    //secure: false,
    auth: {
       user: emailConfig.user,
       pass: emailConfig.pass
    },
    debug: false,
    logger: true 
  
    });
  //   const { error } = validatorModule("contactForm", req.body);
  // if (error) {
  //   const errors = {};
  //   error.details.forEach(err => (errors[err.context.key] = err.message));

  //   return res.status(400).send(errors);
  // }

 // Attach the Contact Form Template 
 let handlebarOptionsAdmin = {
  viewEngine: {
    extName: ".hbs",
    partialsDir: __dirname + "/templates/adminreservation/",
    layoutsDir: __dirname + "/templates/adminreservation/",
    defaultLayout: "html1.hbs"
  },
  viewPath: __dirname + "/templates/adminreservation/",
  extName: ".hbs"
};
let insurance = req.body.data.extras.lenght > 2 ? 'Yes' : 'No';

// Email Options
var bookingID =  req.body.data.booking_code;
let mailOptionsAdmin = {
  from: 'autolandbooking@gmail.com',
  to:'autokarpathos@gmail.com',
  subject: 'Autoland Karpathos - ' + 'Code: ' + bookingID + ' Vehicle: ' + req.body.data.vehicleName,
  template: "html1",
   context: {
     vehicle: req.body.data.vehicleName,
     rCode:  bookingID,
     cDate:new Date(),
     fullName: req.body.data.driverinfo.firstname + ' ' + req.body.data.driverinfo.lastname,
     country: req.body.data.driverinfo.country,
     phone: req.body.data.driverinfo.phone,
     email: req.body.data.driverinfo.email,
     pickUpDate: new Date(Number(req.body.data.pickDateTimeStamp)),
     dropDate: new Date(Number(req.body.data.returnDateTimeStamp)),
     pickLocation: req.body.data.pickuploc,
     dropLocation: req.body.data.dropoffloc,
     totalCost: req.body.data.ammountTotal,
     payment_method: req.body.data.payment_method,
     numOfDays: req.body.data.numOfDays,
     ammountPaid: req.body.data.ammountPaid,
     insurance: insurance,
     ammountPaid: req.body.data.ammountPaid,
     pickUpTime:  req.body.data.pickUpTime,
     returnTime: req.body.data.returnTime,
     travelCo:  req.body.data.travelCompany,
     travelNumber: req.body.data.flightNumber
   }
};
let isSend = await sendMail(mailOptionsAdmin, handlebarOptionsAdmin, transporter);
  if (isSend) {
    return true
  } else {
    return false;;
  }
}