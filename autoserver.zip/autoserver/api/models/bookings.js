var mongoose = require( 'mongoose' ); 

var bookingSchema = new mongoose.Schema(
    {
        car_id: String, 
        vehicleName: String,
        booking_code: String,
        pickDateTimeStamp: Number,
        returnDateTimeStamp: Number,
        pickUpTime: String,
        returnTime: String,
        pickuploc:String,
        dropoffloc:String,
        travelCompany:String,
        flightNumber:String,
        pricePerDay:Number,
        numOfDays: Number,
        insuranceCost:Number,
        ammountTotal:Number,
        ammountPaid:Number,
        ammountRemain:Number,
        payment_method: String,
        driverinfo:Object,
        status: {
          type: String,
          enum: ['Pending', 'Cancelled', 'Approved'],
          default:'Pending'
          },
        email:String,
        booking_code:String,
        booking_timeStamp:Number, 
        from: Date,
        until: Date,
        is_cancelled:Boolean,
          daysBreakdown:  [{
            multipleMonths: Boolean,
            Month: Number,
            days: Number
          }],
        extras: [{
            extra: String,
            cost: Number,
            amount: Number
          }],
        notes:String,
        jwtPay:String
    }
);

module.exports = mongoose.model('Booking', bookingSchema);
