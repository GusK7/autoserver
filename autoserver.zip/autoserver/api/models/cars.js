var mongoose = require( 'mongoose' );


var carsSchema = new mongoose.Schema({
    car_id:String,
    url:String,
    name:String,
    fuel:String,
    passengers:Number,
    price:Number,
    engine: String,
    luggage:Number,
    gearbox:String,
    minAge:String,
    doors:Number,
    pickupLoc:String,
    // features: {
    // type: String,
    // require: true,
    // enum: ['fullInsurance', 'cancel', 'approved', 'active', 'completed']
    // },
    imageName:String, 
    priceroups: String, 
    manufacturer: String,
    mileage:String,
    color:String,
    maxUnits:Number,
    unitNumber:Number,
    itemDesc:String,
    pricing:{
        fullPrice: Number,
        dayPrice: Number,
        insurance: Number
    }
});



mongoose.model('Cars', carsSchema);
