var mongoose = require( 'mongoose' );


var DiscountSchema = new mongoose.Schema({
    discount_id:String,
    discount_type:String,
    price_plan_id:String,
    coupon_discount:String, 
    extra_id:String,
    period_from:Number, 
    period_till:Number,
    discount_percentage:Number
});



mongoose.model('Discounts', DiscountSchema);