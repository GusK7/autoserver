var mongoose = require( 'mongoose' );


var priceGroupsSchema = new mongoose.Schema({
    group_id:String,
    groupName:String 
});



mongoose.model('PriceGroups', priceGroupsSchema);