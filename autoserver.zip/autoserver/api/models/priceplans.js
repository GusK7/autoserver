var mongoose = require( 'mongoose' );


var pricePlansSchema = new mongoose.Schema({
    plan_id:String,
    planName:String,
    start_timestamp:Number,
    end_timestamp:Number,
    daily_rate_mon:Number,
    daily_rate_tue:Number,
    daily_rate_wed: Number,
    daily_rate_thu:Number,
    daily_rate_fri:Number,
    daily_rate_sat:Number,
    daily_rate_sun:Number,
    price_group_id:String
});



mongoose.model('PricePlans', pricePlansSchema);