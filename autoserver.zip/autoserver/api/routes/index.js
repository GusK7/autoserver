var express = require('express');
var router = express.Router();
var jwt = require('express-jwt');
var auth = jwt({
    secret: 'MY_SECRET',
    userProperty: 'payload'
});

var ctrlProfile = require('../controllers/profile');
var ctrlAuth = require('../controllers/authentication');
var ctrlacc = require('../controllers/account');
var ctrlEmail = require('../mailer/mailservice');
var ctrlCrypto = require('../controllers/crypto');


var carList = require('../controllers/products');
var ctrlBooking = require('../controllers/booking');
var carImages = require('../controllers/carImages');
var ctrlfavoritelist = require('../controllers/favoritelist');
var pricing = require('../controllers/pricing');


/**Crypto */ 
router.post('/cservice/smod', ctrlCrypto.bdigest);

/**Mailing Service */ 
//Send and Store Contact Form
router.post('/mailservices/contact', ctrlEmail.contactFrom);
router.post('/mailservices/callme', ctrlEmail.callMeFrom);
router.post('/mailservices/emailbookingadmin', ctrlEmail.bookingAdminRequestForm);

/**CAR Calls */ 
//Get All Car Info
router.get('/carlists', carList.readAllCarInfo);
//router.post('/carlists', carList.postCarInfor);
//router.post('/car', carList.createCar);
//delete a car
router.delete('/car/:id', carList.deleteCarbyId); 
router.put('/car', carList.updateCarInfo);
//router for car id or Custom car id
router.get('/car/:id', carList.searchCarbyID);
//search car by pick location
router.get('/carlists/search/:pickupLoc', carList.searchCarProduct);
//search car by searchBox
router.get('/carlists/search/:searchBox', carList.searchCarProduct);
//search car by filter condition
router.get('/carlists/filter/:pickupLoc&:priceMax&:priceMin&:carType&:passNum', carList.searchCarwithFilter);
//@Tmilios Search with Module Options 
router.post('/carlists/searchoptions', carList.searchCarwithOptions);

// profile
router.get('/profile', auth, ctrlProfile.profileRead);

// authentication
router.post('/register', ctrlAuth.register);
router.post('/login', ctrlAuth.login);

//router.get('/account',ctrlacc.accountRead);
router.get('/account/:email',ctrlacc.accountReadByEmail);
router.post('/account',ctrlacc.createaccount);
router.post('/account/:email',ctrlacc.updateaccountByEmail);


// @Tmilios CAR BOOKINGS
router.get('/bookings', ctrlBooking.bookingRead); 
router.get('/booking/:email',ctrlBooking.bookingsReadByEmail);
router.post('/booking', ctrlBooking.createBooking); 
//router.get('/bookings', ctrlBooking.demo);
router.post('/bookings/success', ctrlBooking.bookingPayUpdate);
router.post('/bookings/updateBooking', ctrlBooking.updateBooking);

//router.post('/favoritelist', ctrlfavoritelist.createFavorite);
router.delete('/favoritelist/:email&:carid', ctrlfavoritelist.DeleteFavorite);
router.get('/favoritelist/:email', ctrlfavoritelist.CarsReadByEmail);
//router.get('/carlists/post', carList.createCarContext); 

// @Tmilios - Pricing of Cars
// Load Price Groups
router.get('/pricing/loadgroups', pricing.createPriceGroups);
// Load Price Plnas
router.get('/pricing/loadplans', pricing.createPricePlans);
// Load Discounts
router.get('/pricing/loaddiscounts', pricing.createDisctounts);
// Get Price Groups
router.get('/pricing/priceplan', pricing.getPricePlans);
// Get Price Groups
router.post('/pricing/priceplandiscounts', pricing.getVehiclePricing);
// Get Price Groups
router.post('/pricing/updatePriceplandiscounts', pricing.setVehiclePricing);




module.exports = router;
