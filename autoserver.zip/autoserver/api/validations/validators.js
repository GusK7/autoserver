const Joi = require("joi");

const validatorModule = (method, body) => { 
  switch (method) {
    case 'searchCarwithOptions': {
        searchSchema = Joi.object().keys({ 
          fromTimestamp: Joi.number().required(),
            pickTime: Joi.string().required(),
          toTimestamp: Joi.number().required(),
          gearBox: Joi.string().optional().allow(''),
          car_id: Joi.string().optional().allow(''),
           returnTime: Joi.string().required()
          });     
          return Joi.validate(body, searchSchema, {abortEarly: false});
    } case 'contactForm': { 
        contactSchema = Joi.object().keys({ 
        fullName: Joi.string().required(),
        subject: Joi.string().required(),
         email: Joi.string().email().required(),
         message: Joi.string().required(),
         phone: Joi.string().optional().allow('')
        }
        );     
        return Joi.validate(body, contactSchema, {abortEarly: false});
    } case 'callMeForm': {
      callMeSchema = Joi.object().keys({ 
      fullName: Joi.string().required(),
      callDate: Joi.string().required(),
      telephone: Joi.number().required(),
      timePreffered: Joi.string().required(),
      callApp: Joi.string().required()
      }
      );     
      return Joi.validate(body, callMeSchema, {abortEarly: false});
  }
    case 'createBooking': {
    bookingSchema = Joi.object().keys({ 
    car_id: Joi.string().required(),
    vehicleName: Joi.string().required(),
    pickupdate: Joi.string().required(),
    dropoffdate: Joi.string().required(),
    pickDateTimeStamp: Joi.number().required(),
    returnDateTimeStamp: Joi.number().required(),
    pickUpTime: Joi.string().required(),
    returnTime: Joi.string().required(),
    pricePerDay: Joi.number().required(),
    insuranceCost: Joi.number().required(),
    numOfDays: Joi.number().required(),
    ammountPaid: Joi.number().optional().allow(''),
    ammountTotal: Joi.number().required(),
    payment_method: Joi.string().required(),
    pickuploc: Joi.string().required(),
    travelCompany: Joi.string().required(),
    flightNumber: Joi.string().optional().allow(''),
    dropoffloc: Joi.string().required(),
    notes: Joi.string().optional().allow(''),
    driverinfo:  Joi.object().pattern(/.*/, [Joi.string(), Joi.string(), Joi.string(),Joi.string(),Joi.string(),Joi.string()]),
    booking_code: Joi.string().optional().allow(''),
    //notes: Joi.array().optional().allow(''),
    extras: Joi.array().optional().items(
      Joi.object().optional().keys({
          extra: Joi.string().optional().error(() => 'extra name is required'),
          cost: Joi.number().optional().error(() => 'cost is required'),
          amount: Joi.number().optional().error(() => 'amount not valid'),
      }))
  }
    );     
    return Joi.validate(body, bookingSchema, {abortEarly: false});
}
  }
}
// Date Validation
// let schema = Joi.object().keys({
//   // format is basically pointless with convert=false
//   dateStr: Joi.date().format('YYYY-MM-DD').options({ convert: false }), 
//   someNumber: Joi.number()
// })

// let payload = {
//   dateStr: '2016-04-07',
//   someNumber: '17'
// 

module.exports = validatorModule;