(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/account/account.component.css":
/*!***********************************************!*\
  !*** ./src/app/account/account.component.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FjY291bnQvYWNjb3VudC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/account/account.component.html":
/*!************************************************!*\
  !*** ./src/app/account/account.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<h2>Personal Information</h2>\n<form (ngSubmit)=\"onSubmit()\" #accountForm=\"ngForm\">\n  <div class=\"form-group row\">\n    <div class=\"col-md-4\">\n      <label>Email: {{email}}</label>\n    </div>\n  </div>\n  <div class=\"form-row\">\n    <div class=\"form-group col-md-6\">\n      <label for=\"name\">name</label>\n      <input type=\"text\" class=\"form-control\" id=\"name\" placeholder=\"Name\" [(ngModel)]=\"account.name\" name=\"name\">\n    </div>\n    <div class=\"form-group col-md-6\">\n      <label for=\"phone\">Phone</label>\n      <input type=\"text\" class=\"form-control\" id=\"phone\" placeholder=\"Phone\" [(ngModel)]=\"account.phone\" name=\"phone\">\n    </div>\n  </div>\n  <div class=\"form-group\">\n    <label for=\"inputAddress\">Address</label>\n    <input type=\"text\" class=\"form-control\" id=\"inputAddress\" placeholder=\"1234 Main St\" [(ngModel)]=\"account.address1\" name=\"address1\">\n  </div>\n  <div class=\"form-group\">\n    <label for=\"inputAddress2\">Address 2</label>\n    <input type=\"text\" class=\"form-control\" id=\"inputAddress2\" placeholder=\"Apartment, studio, or floor\" [(ngModel)]=\"account.address2\" name=\"address2\">\n  </div>\n  <div class=\"form-row\">\n    <div class=\"form-group col-md-6\">\n      <label for=\"inputCity\">City</label>\n      <input type=\"text\" class=\"form-control\" id=\"inputCity\" [(ngModel)]=\"account.city\" name=\"city\">\n    </div>\n    <div class=\"form-group col-md-4\">\n      <label for=\"inputState\">State</label>\n      <select id=\"inputState\" class=\"form-control\" [(ngModel)]=\"account.state\" name=\"state\">\n        <option *ngFor=\"let state of states\" [value]=\"state.state\">{{state.state}}</option>\n      </select>\n    </div>\n    <div class=\"form-group col-md-2\">\n      <label for=\"inputZip\">Zip</label>\n      <input type=\"text\" class=\"form-control\" id=\"inputZip\" [(ngModel)]=\"account.zip\" name=\"zip\">\n    </div>\n  </div>\n  <!--<div class=\"form-group\">-->\n    <!--<div class=\"form-check\">-->\n      <!--<input class=\"form-check-input\" type=\"checkbox\" id=\"gridCheck\">-->\n      <!--<label class=\"form-check-label\" for=\"gridCheck\">-->\n        <!--Check me out-->\n      <!--</label>-->\n    <!--</div>-->\n\n  <!--</div>-->\n  <button type=\"submit\" class=\"btn btn-primary\">Save</button>\n</form>\n<!--<h2>Password</h2>-->\n<!--<form>-->\n  <!--<div class=\"form-group\">-->\n    <!--<label for=\"currentpwd\">Current Password</label>-->\n    <!--<input type=\"password\" id=\"currentpwd\" class=\"form-control\" [(ngModel)]=\"password.currentpassword\" name=\"currentpassword\">-->\n  <!--</div>-->\n  <!--<div class=\"form-group\">-->\n    <!--<label for=\"newpwd\">New Password</label>-->\n    <!--<input type=\"password\" id=\"newpwd\" class=\"form-control\" [(ngModel)]=\"password.newpassword\" name=\"newpassword\">-->\n  <!--</div>-->\n  <!--<button type=\"submit\" class=\"btn btn-primary\">Save</button>-->\n<!--</form>-->\n\n\n"

/***/ }),

/***/ "./src/app/account/account.component.ts":
/*!**********************************************!*\
  !*** ./src/app/account/account.component.ts ***!
  \**********************************************/
/*! exports provided: AccountComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountComponent", function() { return AccountComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_account_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/account.service */ "./src/app/services/account.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");





var AccountComponent = /** @class */ (function () {
    // credentials: TokenPayload = {
    //   email: this.email
    // };
    function AccountComponent(auth, acc, router, routerIonfo) {
        var _this = this;
        this.auth = auth;
        this.acc = acc;
        this.router = router;
        this.routerIonfo = routerIonfo;
        this.states = [
            { state: 'TX' },
            { state: 'CA' },
            { state: 'NY' }
        ];
        this.account = new _services_account_service__WEBPACK_IMPORTED_MODULE_3__["AccountDetail"]('', '', '', '', '', '', '', '', undefined);
        this.password = new _services_account_service__WEBPACK_IMPORTED_MODULE_3__["PassWord"]('', '');
        this.email = this.routerIonfo.snapshot.queryParams["email"];
        this.acc.getAccountByEmail(this.email).subscribe(function (data) {
            if (data != null) {
                _this.flag = true;
                _this.account = data;
            }
            else {
                _this.flag = false;
            }
        }, function (err) { return console.error(err); }, function () { return console.log(_this.account); });
    }
    AccountComponent.prototype.onSubmit = function () {
        var _this = this;
        this.payload = new _services_account_service__WEBPACK_IMPORTED_MODULE_3__["AccountPayload"](this.email, this.account.name, this.account.phone, this.account.address1, this.account.address2, this.account.city, this.account.state, this.account.zip);
        console.log(this.payload);
        if (this.flag == true) {
            this.acc.updateAccountByEmail(this.payload, this.email).subscribe(function () {
                _this.router.navigateByUrl('/profile');
            }, function (err) {
                console.error(err);
            });
        }
        else {
            this.acc.createAccount(this.payload).subscribe(function () {
                _this.router.navigateByUrl('/profile');
            }, function (err) {
                console.error(err);
            });
        }
    };
    AccountComponent.prototype.ngOnInit = function () {
    };
    AccountComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-account',
            template: __webpack_require__(/*! ./account.component.html */ "./src/app/account/account.component.html"),
            styles: [__webpack_require__(/*! ./account.component.css */ "./src/app/account/account.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"], _services_account_service__WEBPACK_IMPORTED_MODULE_3__["AccountService"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]])
    ], AccountComponent);
    return AccountComponent;
}());



/***/ }),

/***/ "./src/app/admincontrolpanel/admincontrolpanel.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/admincontrolpanel/admincontrolpanel.component.css ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".deleteconfirm{\n  color:orangered;\n  text-align:center;\n}\n\n.ng-invalid:not(form){\n  border-left:5px solid red;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWRtaW5jb250cm9scGFuZWwvYWRtaW5jb250cm9scGFuZWwuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQWU7RUFDZixpQkFBaUI7QUFDbkI7O0FBRUE7RUFDRSx5QkFBeUI7QUFDM0IiLCJmaWxlIjoic3JjL2FwcC9hZG1pbmNvbnRyb2xwYW5lbC9hZG1pbmNvbnRyb2xwYW5lbC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmRlbGV0ZWNvbmZpcm17XG4gIGNvbG9yOm9yYW5nZXJlZDtcbiAgdGV4dC1hbGlnbjpjZW50ZXI7XG59XG5cbi5uZy1pbnZhbGlkOm5vdChmb3JtKXtcbiAgYm9yZGVyLWxlZnQ6NXB4IHNvbGlkIHJlZDtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/admincontrolpanel/admincontrolpanel.component.html":
/*!********************************************************************!*\
  !*** ./src/app/admincontrolpanel/admincontrolpanel.component.html ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div style=\"padding-left: 40px;margin-top: 10px\">\n  <button (click)='getAllCarList()' class=\"btn btn-warning\">LIST ALL</button>\n  <button class=\"btn btn-warning\" (click)=\"addBtnClicked()\">ADD ONE</button>\n  <button [ngClass]=\"{ 'disabled': seletedCar == null }\" (click)=\"editBtnClick()\" class=\"btn btn-warning\">EDIT INFO</button>\n  <button [ngClass]=\"{ 'disabled': seletedCar == null }\" (click)=\"deleteBtnClick()\" class=\"btn btn-warning\">REMOVE</button>\n\n  <app-deletedialog [(visible)]=\"showDeleteDialog\" *ngIf=\"seletedCar != null\">\n    <div class='deleteconfirm'>\n      <p>Really want to delete this <b>{{seletedCar.name}}</b> (ID:{{seletedCar._id}}) from list? This operation is unrecoverable!</p>\n    <button (click)=\"confirmDelete()\" class=\"btn btn-warning\">YES</button>\n    <button (click)='closeDialog()' class=\"btn btn-warning\">NO</button>\n    </div>\n  </app-deletedialog>\n\n  <app-deletedialog [(visible)]=\"showUpdataDialog\" *ngIf=\"seletedCar != null\">\n    <div>\n      <!--<div><p>Preview:</p>-->\n        <!--{{imageName}}-->\n        <!--<input type=\"file\" (change)=\"onFileSeleted($event)\">-->\n        <!--<button type=\"button\" (click)=\"onUpload()\">Upload</button>-->\n      <!--</div>-->\n      <div class=\"row\">\n        <div class=\"col s8 offset-1\">\n          <div class=\"card-panel teal lighten-2\">\n            <!--<h4 class=\"center white-text\">Image Preview:</h4>-->\n          </div>\n            <form #imageForm = \"ngForm\" (ngSubmit)=\"onImageSubmit(imageForm.value)\">\n\n              <img [src]='imageUrl'  style=\"width:150px; height:100px;\">\n              <input class=\"form-group\" type=\"file\" #Image accept=\"image/*\"  (change)=\"handleFileInput($event.target.files)\">\n              <!--<button type=\"submit\" [disabled]=\"Image.value ==''\" class=\"btn-large btn-submit\">SUBMIT</button>-->\n\n              <!--<div class=\"row\">-->\n                <!--<label for=\"Caption\">Caption</label>-->\n                <!--<input class=\"form-group\" type=\"text\" #Caption ngModel name=\"Caption\" id=\"Caption\" required placeholder=\"File name\">-->\n              <!--</div>-->\n\n            </form>\n        </div>\n      </div>\n\n\n      <div class=\"col-md-10\">\n        <form>\n          <div class=\"form-group\" >\n            <label for=\"name\">Car name:</label>\n\n            <input type=\"text\" [(ngModel)]='formCarInfo.name' class=\"form-group col-xs-2\" name=\"name\" placeholder=\"Enter car name\" required>\n            <div><label for=\"price\">Price:</label>\n            <input  type=\"text\" class=\"form-group col-xs-1\" [(ngModel)]='formCarInfo.price' name=\"price\" placeholder=\"Price per day\" >\n\n            <label for=\"insurance\">Insurance:</label>\n            <input  type=\"text\" class=\"form-group col-xs-1\" [(ngModel)]='formCarInfo.insurance' name=\"insurance\" placeholder=\"Insurance per day\" >\n            </div><!--style=\"display:inline\"-->\n          </div>\n\n          <div>\n          <label for=\"type\">Car Type</label>\n          <select name = 'type'  [(ngModel)]='formCarInfo.type' class=\"form-group\">\n            <option value=\"Economy\">Economy</option>\n            <option value=\"Compact\">Compact</option>\n            <option value=\"Standard\">Standard</option>\n            <option value=\"SUV\">SUV</option>\n            <option value=\"Luxury\">Luxury</option>\n\n          </select>\n\n          <label for=\"passengerNum\">Seats</label>\n          <select name = 'passengers' [(ngModel)]='formCarInfo.passengers' class=\"form-group\">\n            <option *ngFor=\"let i of [2,3,4,5,6,7]\" value='{{i}}'>{{i}}</option>\n          </select>\n\n          <label for=\"luggage\">Luggage</label>\n          <select name = 'luggage' [(ngModel)]='formCarInfo.luggage' class=\"form-group\">\n            <option *ngFor=\"let i of [1,2,3,4]\" value='{{i}}'>{{i}}</option>\n          </select>\n\n          <label for=\"isAuto\">Auto</label>\n          <select [(ngModel)]='formCarInfo.isAuto' name = 'isAuto' class=\"form-group\">\n            <option value = 'true' [selected]=\"{true:formCarInfo.isAuto == true, false: formCarInfo.isAuto == false}\">YES</option>\n            <option value=\"false\" [selected]=\"{true:formCarInfo.isAuto == true, false: formCarInfo.isAuto == false}\">NO</option>\n          </select>\n\n            <label for=\"ACsup\">A/C</label>\n            <select [(ngModel)]='formCarInfo.ACsup' name = 'ACsup' class=\"form-group\">\n              <option value = 'true' [selected]=\"{true:formCarInfo.ACsup == true, false: formCarInfo.ACsup == false}\">YES</option>\n              <option value=\"false\" [selected]=\"{true:formCarInfo.ACsup == true, false: formCarInfo.ACsup == false}\">NO</option>\n            </select>\n\n          <!--<label for=\"ACsup\">A/C</label>-->\n          <!--<select (change)=\"setACsup($event)\" name = 'ACsup' class=\"form-group\">-->\n            <!--<option *ngFor=\"let i of ['YES', 'NO']\" value=\"{{i}}\" [selected]=\"{true:formCarInfo.ACsup == true && i == 'YES', false:formCarInfo.ACsup == false && i == 'NO'}\">{{i}}</option>-->\n          <!--</select>-->\n\n          </div>\n\n          <!--pickupLoc:String,-->\n          <!--insurance:Number,-->\n          <!--imageName:String,-->\n\n\n          <div class=\"form-group\">\n            <label for=\"pickupLoc\">Location:</label>\n            <input type=\"text\"  [(ngModel)]='formCarInfo.pickupLoc'  class=\"form-control\" name=\"pickupLoc\" placeholder=\"Pick Up Location\" >\n          </div>\n\n\n          <div class='updateconfirm'>\n            <button (click)=\"confirmUpdateCarInfo()\" class=\"btn btn-warning\">SAVE</button>\n            <button (click)='closeDialog()' class=\"btn btn-warning\">CANCEL</button>\n          </div>\n\n        </form>\n      </div>\n    </div>\n  </app-deletedialog>\n\n\n  <app-deletedialog [(visible)]=\"showAddDialog\" >\n    <div>\n      <!--<div><p>Preview:</p>-->\n      <!--{{imageName}}-->\n      <!--<input type=\"file\" (change)=\"onFileSeleted($event)\">-->\n      <!--<button type=\"button\" (click)=\"onUpload()\">Upload</button>-->\n      <!--</div>-->\n      <div class=\"row\">\n        <div class=\"col s8 offset-1\">\n          <div class=\"card-panel teal lighten-2\">\n            <!--<h4 class=\"center white-text\">Image Preview:</h4>-->\n          </div>\n          <form #imageForm = \"ngForm\" (ngSubmit)=\"onImageSubmit(imageForm.value)\">\n\n            <img [src]='imageUrl'  style=\"width:150px; height:100px;\">\n            <input class=\"form-group\" type=\"file\" #Image accept=\"image/*\"  (change)=\"handleFileInput($event.target.files)\">\n            <!--<button type=\"submit\" [disabled]=\"Image.value ==''\" class=\"btn-large btn-submit\">SUBMIT</button>-->\n\n            <!--<div class=\"row\">-->\n            <!--<label for=\"Caption\">Caption</label>-->\n            <!--<input class=\"form-group\" type=\"text\" #Caption ngModel name=\"Caption\" id=\"Caption\" required placeholder=\"File name\">-->\n            <!--</div>-->\n\n          </form>\n        </div>\n      </div>\n\n\n      <div class=\"col-md-10\">\n        <form>\n          <div class=\"form-group\" >\n            <label for=\"name\">Car name:</label>\n\n            <input type=\"text\" [(ngModel)]='formCarInfo.name' class=\"form-group col-xs-2\" name=\"name\" placeholder=\"Enter car name\" required>\n            <label for=\"price\">Price:</label>\n            <input  type=\"text\" class=\"form-group col-xs-1\" [(ngModel)]='formCarInfo.price' name=\"price\" placeholder=\"Price per day\" >\n\n            <label for=\"insurance\">Insurance:</label>\n            <input  type=\"text\" class=\"form-group col-xs-1\" [(ngModel)]='formCarInfo.insurance' name=\"insurance\" placeholder=\"Insurance per day\" >\n            <!--style=\"display:inline\"-->\n          </div>\n\n          <div>\n            <label for=\"type\">Car Type</label>\n            <select name = 'type'  [(ngModel)]='formCarInfo.type' class=\"form-group\">\n              <option value=\"Economy\">Economy</option>\n              <option value=\"Compact\">Compact</option>\n              <option value=\"Standard\">Standard</option>\n              <option value=\"SUV\">SUV</option>\n              <option value=\"Luxury\">Luxury</option>\n\n            </select>\n\n            <label for=\"passengerNum\">Seats</label>\n            <select name = 'passengers' [(ngModel)]='formCarInfo.passengers' class=\"form-group\">\n              <option *ngFor=\"let i of [2,3,4,5,6,7]\" value='{{i}}'>{{i}}</option>\n            </select>\n\n            <label for=\"luggage\">Luggage</label>\n            <select name = 'luggage' [(ngModel)]='formCarInfo.luggage' class=\"form-group\">\n              <option *ngFor=\"let i of [1,2,3,4]\" value='{{i}}'>{{i}}</option>\n            </select>\n\n            <label for=\"isAuto\">Auto</label>\n            <select [(ngModel)]='formCarInfo.isAuto' name = 'isAuto' class=\"form-group\">\n              <option value = 'true' [selected]=\"{true:formCarInfo.isAuto == true, false: formCarInfo.isAuto == false}\">YES</option>\n              <option value=\"false\" [selected]=\"{true:formCarInfo.isAuto == true, false: formCarInfo.isAuto == false}\">NO</option>\n            </select>\n\n            <label for=\"ACsup\">A/C</label>\n            <select [(ngModel)]='formCarInfo.ACsup' name = 'ACsup' class=\"form-group\">\n              <option value = 'true' [selected]=\"{true:formCarInfo.ACsup == true, false: formCarInfo.ACsup == false}\">YES</option>\n              <option value=\"false\" [selected]=\"{true:formCarInfo.ACsup == true, false: formCarInfo.ACsup == false}\">NO</option>\n            </select>\n\n            <!--<label for=\"ACsup\">A/C</label>-->\n            <!--<select (change)=\"setACsup($event)\" name = 'ACsup' class=\"form-group\">-->\n            <!--<option *ngFor=\"let i of ['YES', 'NO']\" value=\"{{i}}\" [selected]=\"{true:formCarInfo.ACsup == true && i == 'YES', false:formCarInfo.ACsup == false && i == 'NO'}\">{{i}}</option>-->\n            <!--</select>-->\n\n          </div>\n\n          <!--pickupLoc:String,-->\n          <!--insurance:Number,-->\n          <!--imageName:String,-->\n\n\n          <div class=\"form-group\">\n            <label for=\"pickupLoc\">Location:</label>\n            <input type=\"text\"  [(ngModel)]='formCarInfo.pickupLoc'  class=\"form-control\" name=\"pickupLoc\" required placeholder=\"Pick Up Location\" >\n          </div>\n\n\n          <div class='addconfirm'>\n            <button (click)=\"clickToAddCar()\" class=\"btn btn-warning\">SAVE</button>\n            <button (click)='closeDialog()' class=\"btn btn-warning\">CANCEL</button>\n          </div>\n\n        </form>\n      </div>\n    </div>\n  </app-deletedialog>\n</div>\n\n"

/***/ }),

/***/ "./src/app/admincontrolpanel/admincontrolpanel.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/admincontrolpanel/admincontrolpanel.component.ts ***!
  \******************************************************************/
/*! exports provided: AdmincontrolpanelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdmincontrolpanelComponent", function() { return AdmincontrolpanelComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/product.service */ "./src/app/services/product.service.ts");
/* harmony import */ var _class_car__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../class/car */ "./src/app/class/car.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/esm5/http.js");





var AdmincontrolpanelComponent = /** @class */ (function () {
    function AdmincontrolpanelComponent(productService, http) {
        this.productService = productService;
        this.http = http;
        this.getAll = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.showDeleteDialog = false;
        this.showUpdataDialog = false;
        this.showAddDialog = false;
        // imageName:string;
        this.imageUrl = '/assets/car-rental-logo.jpg';
    }
    AdmincontrolpanelComponent.prototype.ngOnInit = function () {
        this.seletedCar = null;
        if (this.seletedCar != null) {
            this.formCarInfo = this.seletedCar;
        }
        else {
            this.initCarForm();
        }
    };
    AdmincontrolpanelComponent.prototype.initCarForm = function () {
        this.formCarInfo = new _class_car__WEBPACK_IMPORTED_MODULE_3__["Car"]('', 'Standard', 2, 0, 2, true, true, "", 0, '/assets/car-rental-logo.jpg', true);
    };
    AdmincontrolpanelComponent.prototype.confirmDelete = function () {
        this.productService.deleteCarById(this.seletedCar._id).subscribe(function (data) {
            // console.log(data);
            console.log('*********');
            // this.getAllCarList();
        }, function (err) {
            console.log(err);
        });
        this.getAllCarList();
        this.showDeleteDialog = false;
        console.log("confirm delete: " + this.seletedCar._id + this.seletedCar.name);
    };
    AdmincontrolpanelComponent.prototype.getAllCarList = function () {
        this.getAll.emit();
        this.showDeleteDialog = false;
        this.showUpdataDialog = false;
        this.showAddDialog = false;
    };
    AdmincontrolpanelComponent.prototype.closeDialog = function () {
        this.showDeleteDialog = false;
        this.showUpdataDialog = false;
        this.showAddDialog = false;
    };
    AdmincontrolpanelComponent.prototype.addBtnClicked = function () {
        this.initCarForm();
        this.showAddDialog = true;
    };
    AdmincontrolpanelComponent.prototype.editBtnClick = function () {
        this.initCarForm();
        if (this.seletedCar != null) {
            this.showUpdataDialog = true;
            this.formCarInfo = this.seletedCar;
        }
    };
    AdmincontrolpanelComponent.prototype.deleteBtnClick = function () {
        if (this.seletedCar != null) {
            this.showDeleteDialog = !this.showDeleteDialog;
        }
    };
    // onFileSeleted(e) {
    //   this.imageName = e.target.files[0];
    //   alert(this.imageName);
    //
    // }
    //
    // onUpload() {
    //   const fd = new FormData();
    //   fd.append('image', this.imageName);
    //   // this.http.post()
    // }
    AdmincontrolpanelComponent.prototype.handleFileInput = function (file) {
        var _this = this;
        console.log('handlefile');
        this.fileToUpload = file.item(0);
        var reader = new FileReader();
        reader.onload = function (event) {
            _this.imageUrl = event.target.result;
        };
        reader.readAsDataURL(this.fileToUpload);
        this.formCarInfo.imageName = '/assets/uploadedImage/' + this.fileToUpload.name;
        //
        // reader.onload = function(e) {
        //   var url = e.target;
        //   console.log(e.target); //返回图片url
        // };
    };
    AdmincontrolpanelComponent.prototype.onImageSubmit = function () {
        console.log('onImageSubmit');
        // this.http.post('/api/image', sdfs);
        var file = this.fileToUpload;
        // const headers = new HttpHeaders()
        //   .append('Content-Type', 'multipart/form-data');
        var formData = new FormData();
        formData.append('CarImage', file, file.name);
        console.log(formData);
        this.http.post('/api/image/post', formData)
            .subscribe(function (res) {
            console.log("get response after post picture");
            console.log(res);
        }, function (err) {
            console.log("Error occured when post Image");
        });
        // const endpoint = '/api/image/post';
        // const formData: FormData = new FormData();
        // // formData.append('fileKey', file, file.name);
        // formData.set('imageName', this.fileToUpload.name);
        // formData.set('imageData', this.imageUrl);
        //
        //
        //
        // this.http
        //   .post(endpoint, formData ).subscribe(
        //   res => {
        //           console.log("get response after post picture");
        //           console.log(res);
        //         },
        //         err => {
        //           console.log("Error occured when post Image");
        //         }
        // );
        console.log('postCar finish');
    };
    // setACsup($event) {
    //   console.log($event.target.value);
    //   console.log(this.formCarInfo.ACsup);
    //   // if($event.target.value == 'true'){
    //   //   this.formCarInfo.ACsup = true;
    //   //
    //   //   // formCarInfo_ACsup="";
    //   //   console.log('setacsup to true');
    //   // }
    //   // else {
    //   //   this.formCarInfo.ACsup = false;
    //   //   console.log('setacsup to false');
    //   // }
    //   console.log($event.target.value);
    //   console.log(this.formCarInfo.ACsup);
    //
    // }
    // setIsAuto($event) {
    //   console.log($event.target.value);
    //   console.log(this.formCarInfo.isAuto);
    //   if($event.target.value == 'YES'){
    //     this.formCarInfo.isAuto = true;
    //     // formCarInfo_isAuto: any;
    //   }
    //   else{
    //     this.formCarInfo.isAuto = false;
    //   }
    //   console.log($event.target.value);
    //   console.log(this.formCarInfo.isAuto);
    //
    //
    // }
    AdmincontrolpanelComponent.prototype.clickToAddCar = function () {
        this.showAddDialog = false;
        console.log(this.formCarInfo);
        this.productService.createCar(this.formCarInfo).subscribe(function (data) {
            console.log(data);
        }, function (err) {
            console.log(err);
        });
        this.getAllCarList();
    };
    AdmincontrolpanelComponent.prototype.confirmUpdateCarInfo = function () {
        this.showUpdataDialog = false;
        console.log('---updated infor---');
        console.log(this.formCarInfo);
        this.productService.putCar(this.formCarInfo).subscribe(function (data) {
            console.log(data);
        }, function (err) {
            console.log(err);
        });
        this.getAllCarList();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], AdmincontrolpanelComponent.prototype, "getAll", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _class_car__WEBPACK_IMPORTED_MODULE_3__["Car"])
    ], AdmincontrolpanelComponent.prototype, "seletedCar", void 0);
    AdmincontrolpanelComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-admincontrolpanel',
            template: __webpack_require__(/*! ./admincontrolpanel.component.html */ "./src/app/admincontrolpanel/admincontrolpanel.component.html"),
            styles: [__webpack_require__(/*! ./admincontrolpanel.component.css */ "./src/app/admincontrolpanel/admincontrolpanel.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_product_service__WEBPACK_IMPORTED_MODULE_2__["ProductService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]])
    ], AdmincontrolpanelComponent);
    return AdmincontrolpanelComponent;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/esm5/common.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _register_register_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./register/register.component */ "./src/app/register/register.component.ts");
/* harmony import */ var _profile_profile_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./profile/profile.component */ "./src/app/profile/profile.component.ts");
/* harmony import */ var _services_auth_guard_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./services/auth-guard.service */ "./src/app/services/auth-guard.service.ts");
/* harmony import */ var _welcome_welcome_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./welcome/welcome.component */ "./src/app/welcome/welcome.component.ts");
/* harmony import */ var _bookings_bookings_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./bookings/bookings.component */ "./src/app/bookings/bookings.component.ts");
/* harmony import */ var _account_account_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./account/account.component */ "./src/app/account/account.component.ts");
/* harmony import */ var _favoritelist_favoritelist_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./favoritelist/favoritelist.component */ "./src/app/favoritelist/favoritelist.component.ts");
/* harmony import */ var _bookingdetail_bookingdetail_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./bookingdetail/bookingdetail.component */ "./src/app/bookingdetail/bookingdetail.component.ts");
/* harmony import */ var _services_admin_service_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./services/admin-service.service */ "./src/app/services/admin-service.service.ts");















var routes = [
    {
        path: '',
        component: _welcome_welcome_component__WEBPACK_IMPORTED_MODULE_9__["WelcomeComponent"],
        canActivate: [_services_admin_service_service__WEBPACK_IMPORTED_MODULE_14__["AdminServiceService"]]
    },
    {
        path: 'login',
        component: _login_login_component__WEBPACK_IMPORTED_MODULE_4__["LoginComponent"]
    }, {
        path: 'register',
        component: _register_register_component__WEBPACK_IMPORTED_MODULE_6__["RegisterComponent"]
    }, {
        path: 'profile',
        component: _profile_profile_component__WEBPACK_IMPORTED_MODULE_7__["ProfileComponent"],
        canActivate: [_services_auth_guard_service__WEBPACK_IMPORTED_MODULE_8__["AuthGuardService"]],
        children: [
            {
                path: 'bookings',
                component: _bookings_bookings_component__WEBPACK_IMPORTED_MODULE_10__["BookingsComponent"]
            },
            {
                path: 'account',
                component: _account_account_component__WEBPACK_IMPORTED_MODULE_11__["AccountComponent"]
            },
            {
                path: 'favoritelist',
                component: _favoritelist_favoritelist_component__WEBPACK_IMPORTED_MODULE_12__["FavoritelistComponent"]
            }
        ]
    },
    {
        path: 'home',
        component: _home_home_component__WEBPACK_IMPORTED_MODULE_5__["HomeComponent"]
    },
    {
        path: 'bookingdetail',
        component: _bookingdetail_bookingdetail_component__WEBPACK_IMPORTED_MODULE_13__["BookingdetailComponent"]
    }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forRoot(routes)
            ],
            declarations: [],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--The content below is only a placeholder and can be replaced.-->\n<!--<div class=\"navbar navbar-default\">-->\n  <!--<div class=\"container\">-->\n    <!--<div id=\"navbar-main\">-->\n      <!--<ul class=\"nav navbar-nav\">-->\n        <!--<li><a routerLink=\"/\">Home</a></li>-->\n      <!--</ul>-->\n      <!--<ul class=\"nav navbar-nav navbar-right\">-->\n        <!--<li *ngIf=\"!auth.isLoggedIn()\"><a routerLink=\"/login\">Sign in</a></li>-->\n        <!--<li *ngIf=\"auth.isLoggedIn()\"><a routerLink=\"/profile\">{{ auth.getUserDetails()?.name }}</a></li>-->\n        <!--<li *ngIf=\"auth.isLoggedIn()\"><a (click)=\"auth.logout()\">Logout</a></li>-->\n      <!--</ul>-->\n    <!--</div>-->\n  <!--</div>-->\n<!--</div>-->\n<router-outlet></router-outlet>\n\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/authentication.service */ "./src/app/services/authentication.service.ts");



var AppComponent = /** @class */ (function () {
    function AppComponent(auth) {
        this.auth = auth;
    }
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/esm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/esm5/animations.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/material/tabs */ "./node_modules/@angular/material/esm5/tabs.es5.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! .//app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./header/header.component */ "./src/app/header/header.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/footer/footer.component.ts");
/* harmony import */ var _register_register_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./register/register.component */ "./src/app/register/register.component.ts");
/* harmony import */ var _profile_profile_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./profile/profile.component */ "./src/app/profile/profile.component.ts");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_auth_guard_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./services/auth-guard.service */ "./src/app/services/auth-guard.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var _search_search_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./search/search.component */ "./src/app/search/search.component.ts");
/* harmony import */ var _welcome_welcome_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./welcome/welcome.component */ "./src/app/welcome/welcome.component.ts");
/* harmony import */ var _filter_filter_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./filter/filter.component */ "./src/app/filter/filter.component.ts");
/* harmony import */ var _carlists_carlists_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./carlists/carlists.component */ "./src/app/carlists/carlists.component.ts");
/* harmony import */ var _search_welcome_search_welcome_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./search-welcome/search-welcome.component */ "./src/app/search-welcome/search-welcome.component.ts");
/* harmony import */ var _bookings_bookings_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./bookings/bookings.component */ "./src/app/bookings/bookings.component.ts");
/* harmony import */ var _account_account_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./account/account.component */ "./src/app/account/account.component.ts");
/* harmony import */ var _services_bookings_service__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./services/bookings.service */ "./src/app/services/bookings.service.ts");
/* harmony import */ var _services_account_service__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./services/account.service */ "./src/app/services/account.service.ts");
/* harmony import */ var _favoritelist_favoritelist_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./favoritelist/favoritelist.component */ "./src/app/favoritelist/favoritelist.component.ts");
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./services/product.service */ "./src/app/services/product.service.ts");
/* harmony import */ var _pagination_pagination_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./pagination/pagination.component */ "./src/app/pagination/pagination.component.ts");
/* harmony import */ var _card_card_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./card/card.component */ "./src/app/card/card.component.ts");
/* harmony import */ var _bookingdetail_bookingdetail_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./bookingdetail/bookingdetail.component */ "./src/app/bookingdetail/bookingdetail.component.ts");
/* harmony import */ var _admincontrolpanel_admincontrolpanel_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./admincontrolpanel/admincontrolpanel.component */ "./src/app/admincontrolpanel/admincontrolpanel.component.ts");
/* harmony import */ var _deletedialog_deletedialog_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./deletedialog/deletedialog.component */ "./src/app/deletedialog/deletedialog.component.ts");
/* harmony import */ var angular_svg_icon__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! angular-svg-icon */ "./node_modules/angular-svg-icon/index.js");
/* harmony import */ var _services_favoritelist_service__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./services/favoritelist.service */ "./src/app/services/favoritelist.service.ts");
/* harmony import */ var _services_data_bus_service__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./services/data-bus.service */ "./src/app/services/data-bus.service.ts");
/* harmony import */ var _services_admin_service_service__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./services/admin-service.service */ "./src/app/services/admin-service.service.ts");







































var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"],
                _login_login_component__WEBPACK_IMPORTED_MODULE_9__["LoginComponent"],
                _header_header_component__WEBPACK_IMPORTED_MODULE_11__["HeaderComponent"],
                _home_home_component__WEBPACK_IMPORTED_MODULE_12__["HomeComponent"],
                _footer_footer_component__WEBPACK_IMPORTED_MODULE_13__["FooterComponent"],
                _register_register_component__WEBPACK_IMPORTED_MODULE_14__["RegisterComponent"],
                _profile_profile_component__WEBPACK_IMPORTED_MODULE_15__["ProfileComponent"],
                _search_search_component__WEBPACK_IMPORTED_MODULE_19__["SearchComponent"],
                _welcome_welcome_component__WEBPACK_IMPORTED_MODULE_20__["WelcomeComponent"],
                _filter_filter_component__WEBPACK_IMPORTED_MODULE_21__["FilterComponent"],
                _carlists_carlists_component__WEBPACK_IMPORTED_MODULE_22__["CarlistsComponent"],
                _search_welcome_search_welcome_component__WEBPACK_IMPORTED_MODULE_23__["SearchWelcomeComponent"],
                _bookings_bookings_component__WEBPACK_IMPORTED_MODULE_24__["BookingsComponent"],
                _account_account_component__WEBPACK_IMPORTED_MODULE_25__["AccountComponent"],
                _favoritelist_favoritelist_component__WEBPACK_IMPORTED_MODULE_28__["FavoritelistComponent"],
                _pagination_pagination_component__WEBPACK_IMPORTED_MODULE_30__["PaginationComponent"],
                _card_card_component__WEBPACK_IMPORTED_MODULE_31__["CardComponent"],
                _bookingdetail_bookingdetail_component__WEBPACK_IMPORTED_MODULE_32__["BookingdetailComponent"],
                _card_card_component__WEBPACK_IMPORTED_MODULE_31__["CardComponent"],
                _admincontrolpanel_admincontrolpanel_component__WEBPACK_IMPORTED_MODULE_33__["AdmincontrolpanelComponent"],
                _deletedialog_deletedialog_component__WEBPACK_IMPORTED_MODULE_34__["DeletedialogComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_10__["AppRoutingModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_18__["HttpClientModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__["BrowserAnimationsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatCheckboxModule"],
                _angular_material_tabs__WEBPACK_IMPORTED_MODULE_6__["MatTabsModule"],
                angular_svg_icon__WEBPACK_IMPORTED_MODULE_35__["AngularSvgIconModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__["NgbModule"]
            ],
            providers: [
                _services_authentication_service__WEBPACK_IMPORTED_MODULE_16__["AuthenticationService"],
                _services_auth_guard_service__WEBPACK_IMPORTED_MODULE_17__["AuthGuardService"],
                _services_bookings_service__WEBPACK_IMPORTED_MODULE_26__["BookingsService"],
                _services_account_service__WEBPACK_IMPORTED_MODULE_27__["AccountService"],
                _services_product_service__WEBPACK_IMPORTED_MODULE_29__["ProductService"],
                _services_favoritelist_service__WEBPACK_IMPORTED_MODULE_36__["FavoritelistService"],
                _services_data_bus_service__WEBPACK_IMPORTED_MODULE_37__["DataBusService"],
                _services_admin_service_service__WEBPACK_IMPORTED_MODULE_38__["AdminServiceService"]
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/bookingdetail/bookingdetail.component.css":
/*!***********************************************************!*\
  !*** ./src/app/bookingdetail/bookingdetail.component.css ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".booking_page{\n  padding: 20px 0 0;\n  background-color: #ebebeb;\n\n}\n.left{\n  background-color: #ebebeb;\n}\n.right{\n  background-color: #4CAF50;\n}\n.margin{\n  margin-left: 5%;\n  margin-right: 5%;\n}\n.options{\n  border-collapse:separate;\n  border-spacing:20px 1px;\n  align-content: center;\n}\n.white-panel{\n  background-color: #fff;\n  padding: 20px 15px 8px;\n  margin-bottom: 15px;\n  border-bottom: 1px solid #dedede;\n  width: 100%;\n}\n.white-panel-last{\n  background-color: #fff;\n  padding: 20px 15px 8px;\n  /*margin-bottom: 15px;*/\n  border-bottom: 1px solid #dedede;\n  width: 100%;\n}\n.price_detail{\n  display: inline-block;\n  width: 100%;\n}\n.price_total{\n  font-size: 2.25rem;\n  display: block;\n  color: #000;\n  font-family: \"Roboto Condensed\",sans-serif;\n  font-weight: 700;\n  width: 100%;\n  text-align: right;\n\n}\n.pay_now{\n  color: #F66500;\n  font-size: 14px;\n  top: 12px;\n  position: relative;\n  font-weight: 500;\n  float: left;\n}\n.price_detail h3{\n  color: #f37121;\n  font-size: 1.125rem;\n  line-height: 1.375rem;\n}\n.tb{\n  margin-top: 15px;\n  width: 100%;\n  display: table;\n\n}\n.tb .tb_row{\n  display: table-row;\n}\n.tb_cell{\n  display: table-cell;\n}\n.tb_cell.bold{\n  font-weight: 700;\n}\n.tb_row .tb_cell:first-child {\n  text-align: left;\n  width: 80%;\n  font-size: .8125rem;\n  line-height: 1.3125rem;\n}\n.tb_row .tb_cell {\n  text-align: right;\n  padding: 3px 0;\n  width: 20%;\n  font-size: .8125rem;\n  line-height: 1.3125rem;\n}\n.white-panel h3{\n  color: #f37121;\n  font-size: 1.125rem;\n  line-height: 1.375rem;\n}\n.white-panel-last h3{\n  color: #f37121;\n  font-size: 1.125rem;\n  line-height: 1.375rem;\n}\n.form-row .second{\n  margin-left: 20px;\n}\n.form-group label{\n  font-size: .8125rem;\n  line-height: 1.3125rem;\n}\n.credit_card{\n  margin-top: 15px;\n  margin-bottom: 15px;\n  list-style: none;\n}\n.credit_term{\n  font-size: .8125rem;\n  line-height: 1.3125rem;\n}\n.credit_card li{\n  margin-right: 12px;\n  float: left;\n  width: 50px;\n}\n.credit_card img{\n  display: inline-block;\n  vertical-align: middle;\n  max-width: 100%;\n  height: auto;\n}\n#Person{\n  height:20%;\n  width: 10%;\n  margin: 0px;\n  padding-right:0px;\n  text-align:center;\n}\n#luggage{\n  margin: 0px;\n  padding:0px;\n  text-align:center;\n}\n#Auto{\n  margin: 0px;\n  padding:0px;\n  text-align:center;\n}\n#AC{\n  margin: 0px;\n  padding:0px;\n  text-align:center;\n}\n.feature {\n  font-size: .8125rem;\n  line-height: 1.3125rem;\n  list-style: none;\n  width: 100%;\n}\n.spec{\n  color: #fff;\n}\n.points{\n  list-style: disc;\n  padding-left: 20px;\n  font-size: .8125rem;\n  line-height: 1.3125rem;\n}\nul  {\n  margin:0px;\n  padding:0px;\n\n}\n.Important-info{\n  list-style: disc;\n  font-size: .8125rem;\n  line-height: 1.3125rem\n}\n#img {\n  height: 60%;\n  width: 60%;\n}\n#location{\n  list-style: disc;\n  padding-left: 20px;\n  font-size: .8125rem;\n  line-height: 1.3125rem;\n}\n#backtoResults{\n  cursor: pointer;\n}\n.agree{\n  font-size: .8125rem;\n  line-height: 1.3125rem;\n}\n#terms, #privacy{\n  color: #f37121;\n}\n.orange{\n  background-color: #f37121;\n  color: #fff;\n}\n.new_form{\n  color: #666;\n  text-align: left;\n  margin-bottom: 100px;\n}\n.new_list{\n  list-style: none;\n}\n.new_item{\n  background: #f4f4f4;\n  /*margin-bottom: 1px;*/\n  /*!*padding: 5px 5px 5px 5px;*!*/\n}\n.new_label{\n  width: 60%;\n  float: left;\n  margin-left: 10px;\n  font-size: .8125rem;\n  line-height: 1.3125rem;\n  display: inline;\n}\n.new_blank{\n  width: 60%;\n  display: inline;\n}\n.new_price{\n\n  width: 20%;\n  float: left;\n  margin-left: 10px;\n  font-size: .8125rem;\n  line-height: 1.3125rem;\n  display: inline;\n}\n.new_check{\n  display: inline-block;\n  vertical-align: middle;\n  float: right;\n  width: 10%;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYm9va2luZ2RldGFpbC9ib29raW5nZGV0YWlsLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxpQkFBaUI7RUFDakIseUJBQXlCOztBQUUzQjtBQUNBO0VBQ0UseUJBQXlCO0FBQzNCO0FBRUE7RUFDRSx5QkFBeUI7QUFDM0I7QUFFQTtFQUNFLGVBQWU7RUFDZixnQkFBZ0I7QUFDbEI7QUFFQTtFQUNFLHdCQUF3QjtFQUN4Qix1QkFBdUI7RUFDdkIscUJBQXFCO0FBQ3ZCO0FBRUE7RUFDRSxzQkFBc0I7RUFDdEIsc0JBQXNCO0VBQ3RCLG1CQUFtQjtFQUNuQixnQ0FBZ0M7RUFDaEMsV0FBVztBQUNiO0FBRUE7RUFDRSxzQkFBc0I7RUFDdEIsc0JBQXNCO0VBQ3RCLHVCQUF1QjtFQUN2QixnQ0FBZ0M7RUFDaEMsV0FBVztBQUNiO0FBR0E7RUFDRSxxQkFBcUI7RUFDckIsV0FBVztBQUNiO0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsY0FBYztFQUNkLFdBQVc7RUFDWCwwQ0FBMEM7RUFDMUMsZ0JBQWdCO0VBQ2hCLFdBQVc7RUFDWCxpQkFBaUI7O0FBRW5CO0FBRUE7RUFDRSxjQUFjO0VBQ2QsZUFBZTtFQUNmLFNBQVM7RUFDVCxrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLFdBQVc7QUFDYjtBQUVBO0VBQ0UsY0FBYztFQUNkLG1CQUFtQjtFQUNuQixxQkFBcUI7QUFDdkI7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsY0FBYzs7QUFFaEI7QUFFQTtFQUNFLGtCQUFrQjtBQUNwQjtBQUVBO0VBQ0UsbUJBQW1CO0FBQ3JCO0FBRUE7RUFDRSxnQkFBZ0I7QUFDbEI7QUFHQTtFQUNFLGdCQUFnQjtFQUNoQixVQUFVO0VBQ1YsbUJBQW1CO0VBQ25CLHNCQUFzQjtBQUN4QjtBQUVBO0VBQ0UsaUJBQWlCO0VBQ2pCLGNBQWM7RUFDZCxVQUFVO0VBQ1YsbUJBQW1CO0VBQ25CLHNCQUFzQjtBQUN4QjtBQUVBO0VBQ0UsY0FBYztFQUNkLG1CQUFtQjtFQUNuQixxQkFBcUI7QUFDdkI7QUFFQTtFQUNFLGNBQWM7RUFDZCxtQkFBbUI7RUFDbkIscUJBQXFCO0FBQ3ZCO0FBRUE7RUFDRSxpQkFBaUI7QUFDbkI7QUFFQTtFQUNFLG1CQUFtQjtFQUNuQixzQkFBc0I7QUFDeEI7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixtQkFBbUI7RUFDbkIsZ0JBQWdCO0FBQ2xCO0FBRUE7RUFDRSxtQkFBbUI7RUFDbkIsc0JBQXNCO0FBQ3hCO0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFdBQVc7QUFDYjtBQUVBO0VBQ0UscUJBQXFCO0VBQ3JCLHNCQUFzQjtFQUN0QixlQUFlO0VBQ2YsWUFBWTtBQUNkO0FBRUE7RUFDRSxVQUFVO0VBQ1YsVUFBVTtFQUNWLFdBQVc7RUFDWCxpQkFBaUI7RUFDakIsaUJBQWlCO0FBQ25CO0FBQ0E7RUFDRSxXQUFXO0VBQ1gsV0FBVztFQUNYLGlCQUFpQjtBQUNuQjtBQUNBO0VBQ0UsV0FBVztFQUNYLFdBQVc7RUFDWCxpQkFBaUI7QUFDbkI7QUFFQTtFQUNFLFdBQVc7RUFDWCxXQUFXO0VBQ1gsaUJBQWlCO0FBQ25CO0FBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsc0JBQXNCO0VBQ3RCLGdCQUFnQjtFQUNoQixXQUFXO0FBQ2I7QUFDQTtFQUNFLFdBQVc7QUFDYjtBQUVBO0VBQ0UsZ0JBQWdCO0VBQ2hCLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsc0JBQXNCO0FBQ3hCO0FBQ0E7RUFDRSxVQUFVO0VBQ1YsV0FBVzs7QUFFYjtBQUNBO0VBQ0UsZ0JBQWdCO0VBQ2hCLG1CQUFtQjtFQUNuQjtBQUNGO0FBQ0E7RUFDRSxXQUFXO0VBQ1gsVUFBVTtBQUNaO0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCLG1CQUFtQjtFQUNuQixzQkFBc0I7QUFDeEI7QUFDQTtFQUNFLGVBQWU7QUFDakI7QUFFQTtFQUNFLG1CQUFtQjtFQUNuQixzQkFBc0I7QUFDeEI7QUFFQTtFQUNFLGNBQWM7QUFDaEI7QUFFQTtFQUNFLHlCQUF5QjtFQUN6QixXQUFXO0FBQ2I7QUFFQTtFQUNFLFdBQVc7RUFDWCxnQkFBZ0I7RUFDaEIsb0JBQW9CO0FBQ3RCO0FBRUE7RUFDRSxnQkFBZ0I7QUFDbEI7QUFFQTtFQUNFLG1CQUFtQjtFQUNuQixzQkFBc0I7RUFDdEIsZ0NBQWdDO0FBQ2xDO0FBRUE7RUFDRSxVQUFVO0VBQ1YsV0FBVztFQUNYLGlCQUFpQjtFQUNqQixtQkFBbUI7RUFDbkIsc0JBQXNCO0VBQ3RCLGVBQWU7QUFDakI7QUFFQTtFQUNFLFVBQVU7RUFDVixlQUFlO0FBQ2pCO0FBR0E7O0VBRUUsVUFBVTtFQUNWLFdBQVc7RUFDWCxpQkFBaUI7RUFDakIsbUJBQW1CO0VBQ25CLHNCQUFzQjtFQUN0QixlQUFlO0FBQ2pCO0FBRUE7RUFDRSxxQkFBcUI7RUFDckIsc0JBQXNCO0VBQ3RCLFlBQVk7RUFDWixVQUFVO0FBQ1oiLCJmaWxlIjoic3JjL2FwcC9ib29raW5nZGV0YWlsL2Jvb2tpbmdkZXRhaWwuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ib29raW5nX3BhZ2V7XG4gIHBhZGRpbmc6IDIwcHggMCAwO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWJlYmViO1xuXG59XG4ubGVmdHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ViZWJlYjtcbn1cblxuLnJpZ2h0e1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNENBRjUwO1xufVxuXG4ubWFyZ2lue1xuICBtYXJnaW4tbGVmdDogNSU7XG4gIG1hcmdpbi1yaWdodDogNSU7XG59XG5cbi5vcHRpb25ze1xuICBib3JkZXItY29sbGFwc2U6c2VwYXJhdGU7XG4gIGJvcmRlci1zcGFjaW5nOjIwcHggMXB4O1xuICBhbGlnbi1jb250ZW50OiBjZW50ZXI7XG59XG5cbi53aGl0ZS1wYW5lbHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgcGFkZGluZzogMjBweCAxNXB4IDhweDtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkZWRlZGU7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ud2hpdGUtcGFuZWwtbGFzdHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgcGFkZGluZzogMjBweCAxNXB4IDhweDtcbiAgLyptYXJnaW4tYm90dG9tOiAxNXB4OyovXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZGVkZWRlO1xuICB3aWR0aDogMTAwJTtcbn1cblxuXG4ucHJpY2VfZGV0YWlse1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ucHJpY2VfdG90YWx7XG4gIGZvbnQtc2l6ZTogMi4yNXJlbTtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGNvbG9yOiAjMDAwO1xuICBmb250LWZhbWlseTogXCJSb2JvdG8gQ29uZGVuc2VkXCIsc2Fucy1zZXJpZjtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgd2lkdGg6IDEwMCU7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuXG59XG5cbi5wYXlfbm93e1xuICBjb2xvcjogI0Y2NjUwMDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICB0b3A6IDEycHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZmxvYXQ6IGxlZnQ7XG59XG5cbi5wcmljZV9kZXRhaWwgaDN7XG4gIGNvbG9yOiAjZjM3MTIxO1xuICBmb250LXNpemU6IDEuMTI1cmVtO1xuICBsaW5lLWhlaWdodDogMS4zNzVyZW07XG59XG5cbi50YntcbiAgbWFyZ2luLXRvcDogMTVweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IHRhYmxlO1xuXG59XG5cbi50YiAudGJfcm93e1xuICBkaXNwbGF5OiB0YWJsZS1yb3c7XG59XG5cbi50Yl9jZWxse1xuICBkaXNwbGF5OiB0YWJsZS1jZWxsO1xufVxuXG4udGJfY2VsbC5ib2xke1xuICBmb250LXdlaWdodDogNzAwO1xufVxuXG5cbi50Yl9yb3cgLnRiX2NlbGw6Zmlyc3QtY2hpbGQge1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICB3aWR0aDogODAlO1xuICBmb250LXNpemU6IC44MTI1cmVtO1xuICBsaW5lLWhlaWdodDogMS4zMTI1cmVtO1xufVxuXG4udGJfcm93IC50Yl9jZWxsIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gIHBhZGRpbmc6IDNweCAwO1xuICB3aWR0aDogMjAlO1xuICBmb250LXNpemU6IC44MTI1cmVtO1xuICBsaW5lLWhlaWdodDogMS4zMTI1cmVtO1xufVxuXG4ud2hpdGUtcGFuZWwgaDN7XG4gIGNvbG9yOiAjZjM3MTIxO1xuICBmb250LXNpemU6IDEuMTI1cmVtO1xuICBsaW5lLWhlaWdodDogMS4zNzVyZW07XG59XG5cbi53aGl0ZS1wYW5lbC1sYXN0IGgze1xuICBjb2xvcjogI2YzNzEyMTtcbiAgZm9udC1zaXplOiAxLjEyNXJlbTtcbiAgbGluZS1oZWlnaHQ6IDEuMzc1cmVtO1xufVxuXG4uZm9ybS1yb3cgLnNlY29uZHtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG59XG5cbi5mb3JtLWdyb3VwIGxhYmVse1xuICBmb250LXNpemU6IC44MTI1cmVtO1xuICBsaW5lLWhlaWdodDogMS4zMTI1cmVtO1xufVxuXG4uY3JlZGl0X2NhcmR7XG4gIG1hcmdpbi10b3A6IDE1cHg7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG4gIGxpc3Qtc3R5bGU6IG5vbmU7XG59XG5cbi5jcmVkaXRfdGVybXtcbiAgZm9udC1zaXplOiAuODEyNXJlbTtcbiAgbGluZS1oZWlnaHQ6IDEuMzEyNXJlbTtcbn1cblxuLmNyZWRpdF9jYXJkIGxpe1xuICBtYXJnaW4tcmlnaHQ6IDEycHg7XG4gIGZsb2F0OiBsZWZ0O1xuICB3aWR0aDogNTBweDtcbn1cblxuLmNyZWRpdF9jYXJkIGltZ3tcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBtYXgtd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogYXV0bztcbn1cblxuI1BlcnNvbntcbiAgaGVpZ2h0OjIwJTtcbiAgd2lkdGg6IDEwJTtcbiAgbWFyZ2luOiAwcHg7XG4gIHBhZGRpbmctcmlnaHQ6MHB4O1xuICB0ZXh0LWFsaWduOmNlbnRlcjtcbn1cbiNsdWdnYWdle1xuICBtYXJnaW46IDBweDtcbiAgcGFkZGluZzowcHg7XG4gIHRleHQtYWxpZ246Y2VudGVyO1xufVxuI0F1dG97XG4gIG1hcmdpbjogMHB4O1xuICBwYWRkaW5nOjBweDtcbiAgdGV4dC1hbGlnbjpjZW50ZXI7XG59XG5cbiNBQ3tcbiAgbWFyZ2luOiAwcHg7XG4gIHBhZGRpbmc6MHB4O1xuICB0ZXh0LWFsaWduOmNlbnRlcjtcbn1cbi5mZWF0dXJlIHtcbiAgZm9udC1zaXplOiAuODEyNXJlbTtcbiAgbGluZS1oZWlnaHQ6IDEuMzEyNXJlbTtcbiAgbGlzdC1zdHlsZTogbm9uZTtcbiAgd2lkdGg6IDEwMCU7XG59XG4uc3BlY3tcbiAgY29sb3I6ICNmZmY7XG59XG5cbi5wb2ludHN7XG4gIGxpc3Qtc3R5bGU6IGRpc2M7XG4gIHBhZGRpbmctbGVmdDogMjBweDtcbiAgZm9udC1zaXplOiAuODEyNXJlbTtcbiAgbGluZS1oZWlnaHQ6IDEuMzEyNXJlbTtcbn1cbnVsICB7XG4gIG1hcmdpbjowcHg7XG4gIHBhZGRpbmc6MHB4O1xuXG59XG4uSW1wb3J0YW50LWluZm97XG4gIGxpc3Qtc3R5bGU6IGRpc2M7XG4gIGZvbnQtc2l6ZTogLjgxMjVyZW07XG4gIGxpbmUtaGVpZ2h0OiAxLjMxMjVyZW1cbn1cbiNpbWcge1xuICBoZWlnaHQ6IDYwJTtcbiAgd2lkdGg6IDYwJTtcbn1cblxuI2xvY2F0aW9ue1xuICBsaXN0LXN0eWxlOiBkaXNjO1xuICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gIGZvbnQtc2l6ZTogLjgxMjVyZW07XG4gIGxpbmUtaGVpZ2h0OiAxLjMxMjVyZW07XG59XG4jYmFja3RvUmVzdWx0c3tcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4uYWdyZWV7XG4gIGZvbnQtc2l6ZTogLjgxMjVyZW07XG4gIGxpbmUtaGVpZ2h0OiAxLjMxMjVyZW07XG59XG5cbiN0ZXJtcywgI3ByaXZhY3l7XG4gIGNvbG9yOiAjZjM3MTIxO1xufVxuXG4ub3Jhbmdle1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjM3MTIxO1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLm5ld19mb3Jte1xuICBjb2xvcjogIzY2NjtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgbWFyZ2luLWJvdHRvbTogMTAwcHg7XG59XG5cbi5uZXdfbGlzdHtcbiAgbGlzdC1zdHlsZTogbm9uZTtcbn1cblxuLm5ld19pdGVte1xuICBiYWNrZ3JvdW5kOiAjZjRmNGY0O1xuICAvKm1hcmdpbi1ib3R0b206IDFweDsqL1xuICAvKiEqcGFkZGluZzogNXB4IDVweCA1cHggNXB4OyohKi9cbn1cblxuLm5ld19sYWJlbHtcbiAgd2lkdGg6IDYwJTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBmb250LXNpemU6IC44MTI1cmVtO1xuICBsaW5lLWhlaWdodDogMS4zMTI1cmVtO1xuICBkaXNwbGF5OiBpbmxpbmU7XG59XG5cbi5uZXdfYmxhbmt7XG4gIHdpZHRoOiA2MCU7XG4gIGRpc3BsYXk6IGlubGluZTtcbn1cblxuXG4ubmV3X3ByaWNle1xuXG4gIHdpZHRoOiAyMCU7XG4gIGZsb2F0OiBsZWZ0O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgZm9udC1zaXplOiAuODEyNXJlbTtcbiAgbGluZS1oZWlnaHQ6IDEuMzEyNXJlbTtcbiAgZGlzcGxheTogaW5saW5lO1xufVxuXG4ubmV3X2NoZWNre1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGZsb2F0OiByaWdodDtcbiAgd2lkdGg6IDEwJTtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/bookingdetail/bookingdetail.component.html":
/*!************************************************************!*\
  !*** ./src/app/bookingdetail/bookingdetail.component.html ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\n<div class=\"booking_page\">\n<div class=\"container\">\n  <h4 class=\"margin\" style=\"margin-bottom: 20px\">Reserve your car now</h4>\n  <div class=\"row margin\">\n    <div class=\"col-md-4 left\">\n      <div class=\"row\">\n        <div class=\"white-panel\" id = \"backtoResults\">\n          <div class=\"Car_detail\">\n            <h3>Back to results </h3>\n          </div>\n\n        </div>\n        <div class=\"white-panel\">\n          <div class=\"Car_detail\">\n            <h2>{{car.name }}</h2>\n            <div class=\"row\" >\n              <img src={{car.imageName}} id= \"img\" >\n            </div>\n            <div class=\"row\" id = \"feature\">\n              <table class = \"options\">\n                <tr>\n                  <th><svg-icon src = \"../assets/icons/Person.svg\"></svg-icon></th>\n                  <th><svg-icon src = \"../assets/icons/luggage.svg\"></svg-icon></th>\n                  <th><svg-icon src = \"../assets/icons/AC.svg\"></svg-icon></th>\n                  <th><svg-icon src = \"../assets/icons/Auto.svg\"></svg-icon></th>\n                </tr>\n                <tr>\n                  <td>{{car.passengers}}</td>\n                  <td>{{car.luggage}}</td>\n                  <td>{{car.ACsup}}</td>\n                  <td>{{car.isAuto}}</td>\n                </tr>\n              </table>\n            </div>\n              <table class = \"feature\">\n                <th>Features:</th>\n                <tr><img src = \"../assets/icons/check.png\" style =\"width:20px; height :20px;\" >{{car.type}}</tr>\n                <tr><img src = \"../assets/icons/check.png\" style =\"width:20px; height :20px;\" >Free cancellation</tr>\n                <tr><img src = \"../assets/icons/check.png\" style =\"width:20px; height :20px;\" >Unlimited mileage</tr>\n              </table>\n            </div>\n        </div>\n        <div class=\"white-panel\" id = \"location\">\n          <h6>CAR RENTAL LOCATION</h6>\n          <p>PROCEED TO THE COUNTER IN THE BAGGAGE CLAIM AREA. COURTESY BUS SERVICE IS AVAILABLE IN THE LOWER/MAIN ENTRANCE AREA.</p>\n          <p><b>Pick-Up</b> {{searchInfo[2]}}, {{searchInfo[3]}}\n          </p>\n          <div>\n            <!-- DALLAS LOVE FIELD - Dallas Love Field\n            Shuttle to Car -->\n            <b>{{searchInfo[0]}}</b>\n          </div>\n          <p><b>Drop-Off</b> {{searchInfo[4]}}, {{searchInfo[5]}} </p>\n            <div>\n            <b>{{searchInfo[1]}}</b>\n            </div>\n\n\n        </div>\n        <div class=\"white-panel-last\">\n          <div class=\"Important-info\">\n            <h6>IMPORTANT INFORMATION</h6>\n            <p>Budget rental policies</p>\n            <p>You may cancel this reservation at any time without penalty.</p>\n            <p>If you are a local renter or do not have proof of a return flight, please review the Car Rental Company Rules and Restrictions below for restrictions on mileage and written proof of insurance.</p>\n            <p>Car Rental Company Rules & Restrictions(e.g., insurance, driver age, mileage and geographic restrictions, shuttle info and additional charges)</p>\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"col-md-8\">\n      <div class=\"row\">\n        <div class=\"white-panel\">\n          <div class=\"price_detail\">\n            <h3>Total amount of your booking</h3>\n            <div class=\"price_total\">\n              <span class=\"pay_now\">Pay Now Special</span>\n              ${{price.total | number:'1.2-2'}}\n              <!--<sup>81</sup>-->\n            </div>\n            <div class=\"new_form\">\n              <h3>Recommended Options</h3>\n              <ul class=\"new_list\">\n                <li class=\"new_item\">\n                  <div></div>\n                  <div class=\"new_label\">Basic Insurance</div>\n                  <div class=\"new_price\">${{car.insurance | number:'1.2-2'}}/day</div>\n                  <div class=\"new_check\">\n                    <input type=\"checkbox\" class=\"form-check-input\" (change)=\"onchange($event)\" [value]=\"car.insurance\">\n                  </div>\n                </li>\n                <li class=\"new_item\">\n                  <div></div>\n                  <div class=\"new_label\">Personal Accident Protection</div>\n                  <div class=\"new_price\">${{price.pap | number:'1.2-2'}}/day</div>\n                  <div class=\"new_check\">\n                    <input type=\"checkbox\" class=\"form-check-input\" (change)=\"onchange($event)\" [value]=\"price.pap\">\n                  </div>\n                </li>\n                <li class=\"new_item\">\n                  <div></div>\n                  <div class=\"new_label\">Supplemental Liability Insurance</div>\n                  <div class=\"new_price\">${{price.sli | number:'1.2-2'}}/day</div>\n                  <div class=\"new_check\">\n                    <input type=\"checkbox\" class=\"form-check-input\" (change)=\"onchange($event)\" [value]=\"price.sli\">\n                  </div>\n                </li>\n                <li class=\"new_item\">\n                  <div></div>\n                  <div class=\"new_label\">\n                    Extended Roadside Protection</div>\n                  <div class=\"new_price\">${{price.erp | number:'1.2-2'}}/day</div>\n                  <div class=\"new_check\">\n                    <input type=\"checkbox\" class=\"form-check-input\" (change)=\"onchange($event)\" [value]=\"price.erp\">\n                  </div>\n                </li>\n              </ul>\n            </div>\n            <div class=\"tb\">\n              <div class=\"tb_row\">\n                <div class=\"tb_cell bold\">{{price.day}} days @ ${{car.price | number:'1.2-2'}}/day</div>\n                <div class=\"tb_cell bold\">${{price.day * car.price | number:'1.2-2'}}</div>\n              </div>\n              <div class=\"tb_row\">\n                <div class=\"tb_cell bold\">Estimated Taxes & Fees</div>\n                <div class=\"tb_cell bold\">${{price.tax | number:'1.2-2'}}</div>\n              </div>\n              <div class=\"tb_row\">\n                <div class=\"tb_cell bold\">Total amount of your booking\t</div>\n                <div class=\"tb_cell bold\">${{price.total | number:'1.2-2'}}</div>\n              </div>\n            </div>\n\n          </div>\n        </div>\n        <div class=\"white-panel\">\n          <h3>Driver Information</h3>\n          <form ngForm>\n            <div class=\"form-row\">\n              <div class=\"form-group col-md-4\">\n                <label>First Name:</label>\n                <input type=\"text\" class=\"form-control\" [(ngModel)]=\"driverinfo.firstname\" name=\"first\">\n              </div>\n              <div class=\"form-group col-md-4 second\">\n                <label>Last Name:</label>\n                <input type=\"text\" class=\"form-control\" [(ngModel)]=\"driverinfo.lastname\" name=\"last\">\n              </div>\n            </div>\n            <div class=\"form-row\">\n              <div class=\"form-group col-md-4\">\n                <label>Email Address:</label>\n                <input type=\"email\" class=\"form-control\"  [(ngModel)]=\"driverinfo.email\" name=\"email\">\n              </div>\n              <div class=\"form-group col-md-4 second\">\n                <label>Phone:</label>\n                <input type=\"text\" class=\"form-control\"  [(ngModel)]=\"driverinfo.phone\" name=\"phone\">\n              </div>\n            </div>\n          </form>\n        </div>\n        <div class=\"white-panel\">\n          <h3>Payment Information</h3>\n          <p class=\"credit_term\">A valid credit card is necessary to complete the booking. We accept:</p>\n          <ul class=\"credit_card\">\n            <li><img src=\"../../assets/credit_cards/visa.png\"></li>\n            <li><img src=\"../../assets/credit_cards/master.png\"></li>\n            <li><img src=\"../../assets/credit_cards/american_express.png\"></li>\n            <li><img src=\"../../assets/credit_cards/discover.png\"></li>\n          </ul><br><br>\n          <form>\n            <div class=\"form-row\">\n              <div class=\"form-group col-md-4\">\n                <label>Credit Card Number:</label>\n                <input type=\"text\" class=\"form-control\">\n              </div>\n              <div class=\"form-group col-md-2 second\">\n                <label>CVC Code:</label>\n                <input type=\"text\" class=\"form-control\">\n              </div>\n            </div>\n          <div class=\"form-row\">\n            <div class=\"form-group col-md-3\">\n              <label>Expiration Date:</label>\n              <select class=\"form-control\"><option value=\"\">Month</option>\n                <option value=\"01\">01</option>\n                <option value=\"02\">02</option>\n                <option value=\"03\">03</option>\n                <option value=\"04\">04</option>\n                <option value=\"05\">05</option>\n                <option value=\"06\">06</option>\n                <option value=\"07\">07</option>\n                <option value=\"08\">08</option>\n                <option value=\"09\">09</option>\n                <option value=\"10\">10</option>\n                <option value=\"11\">11</option>\n                <option value=\"12\">12</option>\n              </select>\n            </div>\n            <div class=\"form-group col-md-3 second\">\n              <label class=\"spec\">E</label>\n              <select class=\"form-control\"><option value=\"\">Year</option>\n                <option value=\"2018\">2018</option>\n                <option value=\"2019\">2019</option>\n                <option value=\"2020\">2020</option>\n                <option value=\"2021\">2021</option>\n                <option value=\"2022\">2022</option>\n                <option value=\"2023\">2023</option>\n                <option value=\"2024\">2024</option>\n                <option value=\"2025\">2025</option>\n                <option value=\"2026\">2026</option>\n                <option value=\"2027\">2027</option>\n              </select>\n            </div>\n          </div>\n          <div class=\"form-row\">\n            <div class=\"col-md-4 form-group\">\n              <label>First Name</label>\n              <input class=\"form-control\" type=\"text\">\n            </div>\n            <div class=\"col-md-4 form-group second\">\n              <label>Last Name</label>\n              <input class=\"form-control\" type=\"text\">\n            </div>\n          </div>\n            <div class=\"form-row\">\n              <div class=\"col-md-4 form-group\">\n                <label>Billing Address</label>\n                <input class=\"form-control\" type=\"text\">\n              </div>\n              <div class=\"col-md-4 form-group second\">\n                <label>Billing Address2</label>\n                <input class=\"form-control\" type=\"text\">\n              </div>\n            </div>\n            <div class=\"form-row\">\n              <div class=\"col-md-4 form-group\">\n                <label>City</label>\n                <input class=\"form-control\" type=\"text\">\n              </div>\n              <div class=\"col-md-4 form-group second\">\n                <label>Zip/Postal Code</label>\n                <input class=\"form-control\" type=\"text\">\n              </div>\n            </div>\n            <div class=\"form-row\">\n              <div class=\"col-md-4 form-group\">\n                <label>Country</label>\n                <select class=\"form-control\"><!----><option value=\"182\">Albania</option>\n                  <option value=\"201\">Algeria</option>\n                  <option value=\"253\">American Samoa</option>\n                  <option value=\"70\">Andorra</option>\n                  <option value=\"252\">Angola</option>\n                  <option value=\"251\">Anguilla</option>\n                  <option value=\"190\">Antigua And Barbuda</option>\n                  <option value=\"72\">Argentina</option>\n                  <option value=\"80\">Armenia</option>\n                  <option value=\"35\">Aruba</option>\n                  <option value=\"33\">Australia</option>\n                  <option value=\"54\">Austria</option>\n                  <option value=\"250\">Azerbaijan</option>\n                  <option value=\"105\">Bahamas</option>\n                  <option value=\"170\">Bahrain</option>\n                  <option value=\"185\">Barbades</option>\n                  <option value=\"249\">Belarus</option>\n                  <option value=\"16\">Belgium</option>\n                  <option value=\"53\">Belize</option>\n                  <option value=\"248\">Benin</option>\n                  <option value=\"168\">Bolivia</option>\n                  <option value=\"259\">Bonaire</option>\n                  <option value=\"160\">Bosnia And Herzegovina</option>\n                  <option value=\"247\">Botswana</option>\n                  <option value=\"68\">Brazil</option>\n                  <option value=\"254\">British Virgin Island</option>\n                  <option value=\"161\">Brunei Darussalam</option>\n                  <option value=\"57\">Bulgaria</option>\n                  <option value=\"246\">Burkina Faso</option>\n                  <option value=\"245\">Cambodia</option>\n                  <option value=\"244\">Cameroon</option>\n                  <option value=\"9\">Canada</option>\n                  <option value=\"187\">Cape Verde</option>\n                  <option value=\"192\">Cayman Islands</option>\n                  <option value=\"243\">Central African Republic</option>\n                  <option value=\"46\">Chile</option>\n                  <option value=\"158\">China</option>\n                  <option value=\"241\">Christmas Island</option>\n                  <option value=\"186\">Colombia</option>\n                  <option value=\"240\">Congo</option>\n                  <option value=\"239\">Congo</option>\n                  <option value=\"238\">Cook Islands</option>\n                  <option value=\"36\">Costa Rica</option>\n                  <option value=\"47\">Croatia</option>\n                  <option value=\"42\">Cuba</option>\n                  <option value=\"94\">Curacao</option>\n                  <option value=\"50\">Cyprus</option>\n                  <option value=\"61\">Czech Republic</option>\n                  <option value=\"37\">Denmark</option>\n                  <option value=\"78\">Dominica</option>\n                  <option value=\"41\">Dominican Republic</option>\n                  <option value=\"75\">Ecuador</option>\n                  <option value=\"74\">Egypt</option>\n                  <option value=\"117\">El Salvador</option>\n                  <option value=\"236\">Equatorial Guinea</option>\n                  <option value=\"73\">Estonia</option>\n                  <option value=\"235\">Faroe Islands</option>\n                  <option value=\"203\">Federated States Of Micronesia</option>\n                  <option value=\"234\">Fiji</option>\n                  <option value=\"38\">Finland</option>\n                  <option value=\"1\">France</option>\n                  <option value=\"58\">French Guiana</option>\n                  <option value=\"92\">French Polynesia</option>\n                  <option value=\"233\">Gabon</option>\n                  <option value=\"232\">Gambia</option>\n                  <option value=\"231\">Georgia</option>\n                  <option value=\"2\">Germany</option>\n                  <option value=\"230\">Ghana</option>\n                  <option value=\"205\">Gibraltar</option>\n                  <option value=\"11\">Greece</option>\n                  <option value=\"199\">Greenland</option>\n                  <option value=\"229\">Grenada</option>\n                  <option value=\"4\">Guadeloupe</option>\n                  <option value=\"255\">Guam</option>\n                  <option value=\"52\">Guatemala</option>\n                  <option value=\"155\">Guernsey</option>\n                  <option value=\"228\">Guinea</option>\n                  <option value=\"227\">Haiti</option>\n                  <option value=\"116\">Honduras</option>\n                  <option value=\"226\">Hong_kong</option>\n                  <option value=\"59\">Hungary</option>\n                  <option value=\"24\">Iceland</option>\n                  <option value=\"164\">India</option>\n                  <option value=\"137\">Indonesia</option>\n                  <option value=\"21\">Ireland</option>\n                  <option value=\"49\">Israel</option>\n                  <option value=\"10\">Italy</option>\n                  <option value=\"237\">Ivory Coast</option>\n                  <option value=\"118\">Jamaica</option>\n                  <option value=\"204\">Japan</option>\n                  <option value=\"154\">Jersey</option>\n                  <option value=\"93\">Jordan</option>\n                  <option value=\"66\">Kenya</option>\n                  <option value=\"219\">Korea Democratic People's Republic Of</option>\n                  <option value=\"159\">Korea Republic Of</option>\n                  <option value=\"149\">Kosovo</option>\n                  <option value=\"172\">Kuwait</option>\n                  <option value=\"86\">Latvia</option>\n                  <option value=\"258\">Lebanon</option>\n                  <option value=\"225\">Lesotho</option>\n                  <option value=\"60\">Libyan Arab Jamahiriya</option>\n                  <option value=\"261\">Liechtenstein</option>\n                  <option value=\"63\">Lithuania</option>\n                  <option value=\"7\">Luxembourg</option>\n                  <option value=\"162\">Macao</option>\n                  <option value=\"88\">Macedonia</option>\n                  <option value=\"81\">Madagascar</option>\n                  <option value=\"224\">Malawi</option>\n                  <option value=\"143\">Malaysia</option>\n                  <option value=\"223\">Mali</option>\n                  <option value=\"17\">Malta</option>\n                  <option value=\"5\">Martinique</option>\n                  <option value=\"44\">Mauritius</option>\n                  <option value=\"181\">Mayotte</option>\n                  <option value=\"18\">Mexico</option>\n                  <option value=\"200\">Monaco</option>\n                  <option value=\"198\">Mongolia</option>\n                  <option value=\"173\">Montenegro</option>\n                  <option value=\"43\">Morocco</option>\n                  <option value=\"91\">Mozambique</option>\n                  <option value=\"48\">Namibia</option>\n                  <option value=\"222\">Nauru</option>\n                  <option value=\"64\">Netherlands</option>\n                  <option value=\"8\">New Caledonia</option>\n                  <option value=\"32\">New Zealand</option>\n                  <option value=\"82\">Nicaragua</option>\n                  <option value=\"221\">Nigeria</option>\n                  <option value=\"220\">Niue</option>\n                  <option value=\"257\">Northern Mariana Islands</option>\n                  <option value=\"39\">Norway</option>\n                  <option value=\"104\">Oman</option>\n                  <option value=\"146\">Pakistan</option>\n                  <option value=\"202\">Palau</option>\n                  <option value=\"183\">Panama</option>\n                  <option value=\"218\">Papua New Guinea</option>\n                  <option value=\"174\">Paraguay</option>\n                  <option value=\"76\">Peru</option>\n                  <option value=\"166\">Philippines</option>\n                  <option value=\"26\">Poland</option>\n                  <option value=\"19\">Portugal</option>\n                  <option value=\"193\">Puerto Rico</option>\n                  <option value=\"171\">Qatar</option>\n                  <option value=\"101\">Republic Of Moldova</option>\n                  <option value=\"6\">Reunion</option>\n                  <option value=\"55\">Romania</option>\n                  <option value=\"184\">Russian Federation</option>\n                  <option value=\"34\">Saint Barthelemy</option>\n                  <option value=\"217\">Saint Kitts And Nevis</option>\n                  <option value=\"77\">Saint Lucia</option>\n                  <option value=\"191\">Saint Martin</option>\n                  <option value=\"108\">Saint Vincent And The Grenadines</option>\n                  <option value=\"216\">Samoa</option>\n                  <option value=\"215\">Sao Tome And Principe</option>\n                  <option value=\"214\">Saudi Arabia</option>\n                  <option value=\"65\">Senegal</option>\n                  <option value=\"150\">Serbia</option>\n                  <option value=\"87\">Seychelles</option>\n                  <option value=\"165\">Singapore</option>\n                  <option value=\"260\">Sint Maarten</option>\n                  <option value=\"79\">Slovakia</option>\n                  <option value=\"69\">Slovenia</option>\n                  <option value=\"213\">Solomon Islands</option>\n                  <option value=\"30\">South Africa</option>\n                  <option value=\"12\">Spain</option>\n                  <option value=\"96\">Sri Lanka</option>\n                  <option value=\"197\">Sudan</option>\n                  <option value=\"169\">Suriname</option>\n                  <option value=\"212\">Swaziland</option>\n                  <option value=\"40\">Sweden</option>\n                  <option value=\"23\">Switzerland</option>\n                  <option value=\"99\">Syrian Arab Republic</option>\n                  <option value=\"211\">Taiwan</option>\n                  <option value=\"83\">Tanzania United Republic Of</option>\n                  <option value=\"242\">Tchad</option>\n                  <option value=\"67\">Thailand</option>\n                  <option value=\"210\">Togo</option>\n                  <option value=\"194\">Tokelau</option>\n                  <option value=\"209\">Tonga</option>\n                  <option value=\"195\">Trinidad And Tobago</option>\n                  <option value=\"20\">Tunisia</option>\n                  <option value=\"62\">Turkey</option>\n                  <option value=\"196\">Turks And Caicos Islands</option>\n                  <option value=\"256\">US Virgin Island</option>\n                  <option value=\"188\">Uganda</option>\n                  <option value=\"89\">Ukraine</option>\n                  <option value=\"100\">United Arab Emirats</option>\n                  <option value=\"13\">United Kingdom</option>\n                  <option value=\"3\">United States</option>\n                  <option value=\"119\">Uruguay</option>\n                  <option value=\"208\">Vanuatu</option>\n                  <option value=\"156\">Venezuela</option>\n                  <option value=\"207\">Vietnam</option>\n                  <option value=\"98\">Yemen</option>\n                  <option value=\"206\">Zambia</option>\n                  <option value=\"71\">Zimbabwe</option>\n                </select>\n              </div>\n              <div class=\"col-md-4 form-group second\">\n                <label>State</label>\n                <select class=\"form-control\"><option value=\"\">Please Choose State</option>\n                  <option value=\"AL\">Alabama (AL)</option>\n                  <option value=\"AK\">Alaska (AK)</option>\n                  <option value=\"AZ\">Arizona (AZ)</option>\n                  <option value=\"AR\">Arkansas (AR)</option>\n                  <option value=\"AA\">Armed Forces Americas (AA)</option>\n                  <option value=\"AE\">Armed Forces Europe/Middle East/Canada (AE)</option>\n                  <option value=\"AP\">Armed Forces Pacific (AP)</option>\n                  <option value=\"CA\">California (CA)</option>\n                  <option value=\"CO\">Colorado (CO)</option>\n                  <option value=\"CT\">Connecticut (CT)</option>\n                  <option value=\"DE\">Delaware (DE)</option>\n                  <option value=\"DC\">District of Columbia (DC)</option>\n                  <option value=\"FL\">Florida (FL)</option>\n                  <option value=\"GA\">Georgia (GA)</option>\n                  <option value=\"HI\">Hawaii (HI)</option>\n                  <option value=\"ID\">Idaho (ID)</option>\n                  <option value=\"IL\">Illinois (IL)</option>\n                  <option value=\"IN\">Indiana (IN)</option>\n                  <option value=\"IA\">Iowa (IA)</option>\n                  <option value=\"KS\">Kansas (KS)</option>\n                  <option value=\"KY\">Kentucky (KY)</option>\n                  <option value=\"LA\">Louisiana (LA)</option>\n                  <option value=\"ME\">Maine (ME)</option>\n                  <option value=\"MD\">Maryland (MD)</option>\n                  <option value=\"MA\">Massachusetts (MA)</option>\n                  <option value=\"MI\">Michigan (MI)</option>\n                  <option value=\"MN\">Minnesota (MN)</option>\n                  <option value=\"MS\">Mississippi (MS)</option>\n                  <option value=\"MO\">Missouri (MO)</option>\n                  <option value=\"MT\">Montana (MT)</option>\n                  <option value=\"NE\">Nebraska (NE)</option>\n                  <option value=\"NV\">Nevada (NV)</option>\n                  <option value=\"NH\">New Hampshire (NH)</option>\n                  <option value=\"NJ\">New Jersey (NJ)</option>\n                  <option value=\"NM\">New Mexico (NM)</option>\n                  <option value=\"NY\">New York (NY)</option>\n                  <option value=\"NC\">North Carolina (NC)</option>\n                  <option value=\"ND\">North Dakota (ND)</option>\n                  <option value=\"OH\">Ohio (OH)</option>\n                  <option value=\"OK\">Oklahoma (OK)</option>\n                  <option value=\"OR\">Oregon (OR)</option>\n                  <option value=\"PA\">Pennsylvania (PA)</option>\n                  <option value=\"RI\">Rhode Island (RI)</option>\n                  <option value=\"SC\">South Carolina (SC)</option>\n                  <option value=\"SD\">South Dakota (SD)</option>\n                  <option value=\"TN\">Tennessee (TN)</option>\n                  <option value=\"TX\">Texas (TX)</option>\n                  <option value=\"UT\">Utah (UT)</option>\n                  <option value=\"VT\">Vermont (VT)</option>\n                  <option value=\"VA\">Virginia (VA)</option>\n                  <option value=\"WA\">Washington (WA)</option>\n                  <option value=\"WV\">West Virginia (WV)</option>\n                  <option value=\"WI\">Wisconsin (WI)</option>\n                  <option value=\"WY\">Wyoming (WY)</option>\n                </select>\n              </div>\n            </div>\n          </form>\n        </div>\n        <div class=\"white-panel-last\">\n          <h3>Complete Your Reservation</h3>\n          <ul class=\"points\">\n            <li>The name on the credit card used to make the reservation must match the driver's name.</li>\n            <li>The same credit card must be presented at the counter upon pick-up.</li>\n            <li>Your card will be charged for the total cost of this reservation {{price.total | number:'1.2-2'}} (USD) when you reserve your car.</li>\n            <!----><!---->                    <li>This pre-paid reservation cannot be changed or refunded.</li>\n            <!----><!----><!----><!----></ul>\n          <hr>\n          <p class=\"agree\">By clicking Reserve Now, I acknowledge that I have read and accept the <span id=\"terms\">Terms of Use</span> and <span id=\"privacy\">Privacy Policy</span>. I also may receive emails about special offers available on CarRentals.com.</p>\n          <button class=\"btn orange\" (click)=\"onclick()\">RESERVE NOW</button>\n        </div>\n      </div>\n    </div>\n  </div>\n\n</div>\n</div>\n<app-footer></app-footer>\n"

/***/ }),

/***/ "./src/app/bookingdetail/bookingdetail.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/bookingdetail/bookingdetail.component.ts ***!
  \**********************************************************/
/*! exports provided: BookingdetailComponent, pricedetail */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookingdetailComponent", function() { return BookingdetailComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pricedetail", function() { return pricedetail; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _services_bookings_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/bookings.service */ "./src/app/services/bookings.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var _services_data_bus_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/data-bus.service */ "./src/app/services/data-bus.service.ts");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");






var BookingdetailComponent = /** @class */ (function () {
    function BookingdetailComponent(bookingservice, router, dataBus, auth) {
        var _this = this;
        this.bookingservice = bookingservice;
        this.router = router;
        this.dataBus = dataBus;
        this.auth = auth;
        this.driverinfo = {
            firstname: '',
            lastname: '',
            email: '',
            phone: ''
        };
        //pricepayload:pricedetail = new pricedetail(3,26.99,5.49,8.96,6.99,48.09,64.28, 591.32);
        this.booking = new _services_bookings_service__WEBPACK_IMPORTED_MODULE_2__["Booking"]('2018-01-01', '2018-01-02', 'DFW', 'DFW', 0, '1', 'a@a.com', this.driverinfo);
        this.car = this.dataBus.getCarInfo();
        this.price = new pricedetail(3, 26.99, 5.49, 8.96, 6.99, 48.09, 64.28, 0);
        this.price.base = this.car.price;
        this.price.total = this.price.base * this.price.day + this.price.tax;
        this.searchInfo = this.dataBus.getSearchCondi();
        console.log(this.searchInfo);
        this.dataBus.carValueUpdate.subscribe(function (val) {
            _this.car = _this.dataBus.getCarInfo();
            _this.price.base = _this.car.price;
            // console.log(this.price.base);
            // this.price.day = 3;
            // this.price.sli = 20;
            // this.price.erp =9.99;
            // this.price.loss =8.88;
            // this.price.tax =48.25;
            console.log(_this.price.total);
            console.log('---init--get--car');
            console.log(_this.car);
        }, function (err) {
            console.log(err);
        });
    }
    BookingdetailComponent.prototype.ngOnInit = function () {
        //this.price.total = (this.price.base + this.price.tax) * this.price.day;
        var _this = this;
        this.dataBus.carSearchCondiUpdate.subscribe(function (val) {
            _this.searchInfo = _this.dataBus.getSearchCondi();
            console.log('---init--get--search Info');
            console.log(_this.searchInfo);
        });
    };
    //   ngAfterContentChecked(){
    //     this.car = this.dataBus.getCarInfo();
    //     console.log('---ngAfterContentChecked');
    //     console.log(this.car);
    //
    // }
    BookingdetailComponent.prototype.onchange = function (event) {
        if (event.target.checked) {
            this.price.total += event.target.value * this.price.day;
        }
        else {
            this.price.total -= event.target.value * this.price.day;
        }
    };
    BookingdetailComponent.prototype.onclick = function () {
        var _this = this;
        this.booking.driverinfo = this.driverinfo;
        this.booking.carid = this.car._id;
        this.booking.pickuploc = this.car.pickupLoc;
        this.booking.dropoffloc = this.searchInfo[1];
        this.booking.pickupdate = this.searchInfo[2] + ' ' + this.searchInfo[3];
        this.booking.dropoffdate = this.searchInfo[4] + ' ' + this.searchInfo[5];
        if (this.auth.isLoggedIn()) {
            this.booking.email = this.auth.getUserDetails().email;
        }
        this.booking.price = this.price.total;
        console.log(this.booking);
        this.bookingservice.createBooking(this.booking).subscribe(function (data) {
            console.log(data);
            _this.router.navigateByUrl('/home');
        }, function (err) {
            console.log(err);
        });
    };
    BookingdetailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-bookingdetail',
            template: __webpack_require__(/*! ./bookingdetail.component.html */ "./src/app/bookingdetail/bookingdetail.component.html"),
            styles: [__webpack_require__(/*! ./bookingdetail.component.css */ "./src/app/bookingdetail/bookingdetail.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_bookings_service__WEBPACK_IMPORTED_MODULE_2__["BookingsService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _services_data_bus_service__WEBPACK_IMPORTED_MODULE_4__["DataBusService"], _services_authentication_service__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"]])
    ], BookingdetailComponent);
    return BookingdetailComponent;
}());

var pricedetail = /** @class */ (function () {
    function pricedetail(day, loss, pap, sli, erp, tax, base, total) {
        this.day = day;
        this.loss = loss;
        this.pap = pap;
        this.sli = sli;
        this.erp = erp;
        this.tax = tax;
        this.base = base;
        this.total = total;
    }
    return pricedetail;
}());



/***/ }),

/***/ "./src/app/bookings/bookings.component.css":
/*!*************************************************!*\
  !*** ./src/app/bookings/bookings.component.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Jvb2tpbmdzL2Jvb2tpbmdzLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/bookings/bookings.component.html":
/*!**************************************************!*\
  !*** ./src/app/bookings/bookings.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--<ul class=\"nav nav-tabs\">-->\n\n  <!--<li class=\"nav-item\">-->\n    <!--<a class=\"nav-link\" routerLink=\"/profile/bookings/upcbookings\">Upcoming Bookings</a>-->\n  <!--</li>-->\n\n  <!--<li class=\"nav-item\">-->\n    <!--<a class=\"nav-link\" routerLink=\"/profile/bookings/pastbookings\">Past Bookings</a>-->\n  <!--</li>-->\n\n  <!--<li class=\"nav-item\">-->\n    <!--<a class=\"nav-link\" routerLink=\"/profile/bookings/cncldbookings\">Cancelled Bookings</a>-->\n  <!--</li>-->\n\n<!--</ul>-->\n<!--<router-outlet></router-outlet>-->\n<div class=\"container\">\n  <table class=\"table table-hover\">\n    <thead>\n    <tr>\n      <th>Pickup Location</th>\n      <th>Dropoff Location</th>\n      <th>Pickup Date</th>\n      <th>Dropoff Date</th>\n      <th>Price</th>\n      <th>Driver Email</th>\n      <th>Car</th>\n    </tr>\n    </thead>\n    <tbody *ngFor=\"let array of singlearray\">\n      <td>{{array.booking.pickuploc}}</td>\n      <td>{{array.booking.dropoffloc}}</td>\n      <td>{{array.booking.pickupdate}}</td>\n      <td>{{array.booking.dropoffdate}}</td>\n      <td>{{array.booking.price | number:'1.2-2'}}</td>\n      <td>{{array.booking.driverinfo.email}}</td>\n      <td>{{array.car.name}}</td>\n    </tbody>\n  </table>\n</div>\n"

/***/ }),

/***/ "./src/app/bookings/bookings.component.ts":
/*!************************************************!*\
  !*** ./src/app/bookings/bookings.component.ts ***!
  \************************************************/
/*! exports provided: BookingsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookingsComponent", function() { return BookingsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _services_bookings_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/bookings.service */ "./src/app/services/bookings.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/product.service */ "./src/app/services/product.service.ts");





var BookingsComponent = /** @class */ (function () {
    function BookingsComponent(BookingService, routerIonfo, prdservice) {
        this.BookingService = BookingService;
        this.routerIonfo = routerIonfo;
        this.prdservice = prdservice;
        this.bookings = [];
        this.cars = [];
        this.singlearray = [];
        this.email = this.routerIonfo.snapshot.queryParams["email"];
    }
    BookingsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.BookingService.getBookingsByEmail(this.email).subscribe(function (data) {
            _this.bookings = data;
            var _loop_1 = function (booking) {
                _this.prdservice.searchCarId(booking.carid).subscribe(function (car) {
                    console.log(car);
                    _this.singlearray.push({
                        booking: booking,
                        car: car
                    });
                }, function (err) {
                    console.log(err);
                });
            };
            for (var _i = 0, _a = _this.bookings; _i < _a.length; _i++) {
                var booking = _a[_i];
                _loop_1(booking);
            }
            // for(let i = 0; i < this.bookings.length; i++){
            //   this.singlearray.push(
            //     {
            //       booking:this.bookings[i],
            //       car:this.cars[i]
            //     }
            //   )
            // }
            //console.log(this.bookings);
        }, function (err) {
            console.log(err);
        });
    };
    BookingsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-bookings',
            template: __webpack_require__(/*! ./bookings.component.html */ "./src/app/bookings/bookings.component.html"),
            styles: [__webpack_require__(/*! ./bookings.component.css */ "./src/app/bookings/bookings.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_bookings_service__WEBPACK_IMPORTED_MODULE_2__["BookingsService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _services_product_service__WEBPACK_IMPORTED_MODULE_4__["ProductService"]])
    ], BookingsComponent);
    return BookingsComponent;
}());



/***/ }),

/***/ "./src/app/card/card.component.css":
/*!*****************************************!*\
  !*** ./src/app/card/card.component.css ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#main_row{\n    padding: 5px;\n}\n#model_name {\n    font-weight: 700;\n    font-size: 40px;\n}\n#model_name_r{\n    padding-top: 0px;\n}\nli{\n  list-style: none;\n}\n#image {\n    height: 100px;\n    width: 200px;\n}\n#card {\n    background: rgb(255, 255, 255);\n    -webkit-box-orient: horizontal;\n    -webkit-box-direction: normal;\n            flex-direction: row;\n    border:1px solid #eee;\n    box-shadow: 0 0 5px rgba(0,0,0,.1)\n}\n#col_r {\n    margin-top: 20px;\n    margin-bottom: 20px;\n    background-color: rgb(245,245,245);\n}\n#price_text{\n    font-size: 20px;\n}\n#pickuptext {\n    color: rgb(153,153,153);\n    font-size: 30px;\n}\n#button_row{\n  position: relative;\n  margin-top: 30%;\n  text-align: center;\n}\n#continue_button {\n    position: relative;\n    -webkit-box-align: center;\n            align-items: center;\n    background-color: rgb(243,113,33);\n}\n#model_name_r{\n    padding-left: 0px;\n    text-align: left;\n}\nlabel {\n  /* Presentation */\n  font-size: 30px\n}\n/* Required Styling */\nlabel input[type=\"checkbox\"] {\n  display: none;\n}\n.custom-checkbox {\n  position: relative;\n  cursor: pointer;\n}\n.custom-checkbox .glyphicon {\n  position: absolute;\n  bottom:0.05px;\n  left: -1.25em;\n}\n.custom-checkbox .glyphicon-star {\n  opacity: 0;\n  -webkit-transition: opacity 0.2s ease-in-out;\n  transition: opacity 0.2s ease-in-out;\n}\n.custom-checkbox:hover .glyphicon-star{\n  opacity: 0.5;\n}\n.custom-checkbox input[type=\"checkbox\"]:checked ~ .glyphicon-star {\n  opacity: 1;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2FyZC9jYXJkLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxZQUFZO0FBQ2hCO0FBQ0E7SUFDSSxnQkFBZ0I7SUFDaEIsZUFBZTtBQUNuQjtBQUNBO0lBQ0ksZ0JBQWdCO0FBQ3BCO0FBQ0E7RUFDRSxnQkFBZ0I7QUFDbEI7QUFDQTtJQUNJLGFBQWE7SUFDYixZQUFZO0FBQ2hCO0FBQ0E7SUFDSSw4QkFBOEI7SUFDOUIsOEJBQW1CO0lBQW5CLDZCQUFtQjtZQUFuQixtQkFBbUI7SUFDbkIscUJBQXFCO0lBQ3JCO0FBQ0o7QUFFQTtJQUNJLGdCQUFnQjtJQUNoQixtQkFBbUI7SUFDbkIsa0NBQWtDO0FBQ3RDO0FBQ0E7SUFDSSxlQUFlO0FBQ25CO0FBQ0E7SUFDSSx1QkFBdUI7SUFDdkIsZUFBZTtBQUNuQjtBQUNBO0VBQ0Usa0JBQWtCO0VBQ2xCLGVBQWU7RUFDZixrQkFBa0I7QUFDcEI7QUFDQTtJQUNJLGtCQUFrQjtJQUNsQix5QkFBbUI7WUFBbkIsbUJBQW1CO0lBQ25CLGlDQUFpQztBQUNyQztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLGdCQUFnQjtBQUNwQjtBQUVBO0VBQ0UsaUJBQWlCO0VBQ2pCO0FBQ0Y7QUFFQSxxQkFBcUI7QUFFckI7RUFDRSxhQUFhO0FBQ2Y7QUFFQTtFQUNFLGtCQUFrQjtFQUNsQixlQUFlO0FBQ2pCO0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIsYUFBYTtFQUNiLGFBQWE7QUFDZjtBQUlBO0VBQ0UsVUFBVTtFQUNWLDRDQUFvQztFQUFwQyxvQ0FBb0M7QUFDdEM7QUFFQTtFQUNFLFlBQVk7QUFDZDtBQUVBO0VBQ0UsVUFBVTtBQUNaIiwiZmlsZSI6InNyYy9hcHAvY2FyZC9jYXJkLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjbWFpbl9yb3d7XG4gICAgcGFkZGluZzogNXB4O1xufVxuI21vZGVsX25hbWUge1xuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgZm9udC1zaXplOiA0MHB4O1xufVxuI21vZGVsX25hbWVfcntcbiAgICBwYWRkaW5nLXRvcDogMHB4O1xufVxubGl7XG4gIGxpc3Qtc3R5bGU6IG5vbmU7XG59XG4jaW1hZ2Uge1xuICAgIGhlaWdodDogMTAwcHg7XG4gICAgd2lkdGg6IDIwMHB4O1xufVxuI2NhcmQge1xuICAgIGJhY2tncm91bmQ6IHJnYigyNTUsIDI1NSwgMjU1KTtcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgIGJvcmRlcjoxcHggc29saWQgI2VlZTtcbiAgICBib3gtc2hhZG93OiAwIDAgNXB4IHJnYmEoMCwwLDAsLjEpXG59XG5cbiNjb2xfciB7XG4gICAgbWFyZ2luLXRvcDogMjBweDtcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyNDUsMjQ1LDI0NSk7XG59XG4jcHJpY2VfdGV4dHtcbiAgICBmb250LXNpemU6IDIwcHg7XG59XG4jcGlja3VwdGV4dCB7XG4gICAgY29sb3I6IHJnYigxNTMsMTUzLDE1Myk7XG4gICAgZm9udC1zaXplOiAzMHB4O1xufVxuI2J1dHRvbl9yb3d7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgbWFyZ2luLXRvcDogMzAlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4jY29udGludWVfYnV0dG9uIHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjQzLDExMywzMyk7XG59XG5cbiNtb2RlbF9uYW1lX3J7XG4gICAgcGFkZGluZy1sZWZ0OiAwcHg7XG4gICAgdGV4dC1hbGlnbjogbGVmdDtcbn1cblxubGFiZWwge1xuICAvKiBQcmVzZW50YXRpb24gKi9cbiAgZm9udC1zaXplOiAzMHB4XG59XG5cbi8qIFJlcXVpcmVkIFN0eWxpbmcgKi9cblxubGFiZWwgaW5wdXRbdHlwZT1cImNoZWNrYm94XCJdIHtcbiAgZGlzcGxheTogbm9uZTtcbn1cblxuLmN1c3RvbS1jaGVja2JveCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuXG4uY3VzdG9tLWNoZWNrYm94IC5nbHlwaGljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTowLjA1cHg7XG4gIGxlZnQ6IC0xLjI1ZW07XG59XG5cblxuXG4uY3VzdG9tLWNoZWNrYm94IC5nbHlwaGljb24tc3RhciB7XG4gIG9wYWNpdHk6IDA7XG4gIHRyYW5zaXRpb246IG9wYWNpdHkgMC4ycyBlYXNlLWluLW91dDtcbn1cblxuLmN1c3RvbS1jaGVja2JveDpob3ZlciAuZ2x5cGhpY29uLXN0YXJ7XG4gIG9wYWNpdHk6IDAuNTtcbn1cblxuLmN1c3RvbS1jaGVja2JveCBpbnB1dFt0eXBlPVwiY2hlY2tib3hcIl06Y2hlY2tlZCB+IC5nbHlwaGljb24tc3RhciB7XG4gIG9wYWNpdHk6IDE7XG59XG4iXX0= */"

/***/ }),

/***/ "./src/app/card/card.component.html":
/*!******************************************!*\
  !*** ./src/app/card/card.component.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\" id = 'card'>\n    <div class=\"row\" id = 'main_row' style=\"padding-left: 10px;padding-right: 10px\">\n    <div class=\"col-sm-10 \">\n        <div class=\"row\" id =\"model_name\" *ngIf=\"car.isavailable\">\n        {{car.name}}\n            <!--<label for=\"id-of-input\" class=\"custom-checkbox\">-->\n              <input type=\"checkbox\" id=\"id-of-input\" style=\"margin-top: 21px;margin-left: 15px\" (change)=\"onchange($event)\" [(ngModel)]=\"check\"/>\n          <label style=\"font-size: 1rem;color: #F66500;margin-top: 17px;margin-left: 5px\">Add to Favorite</label>\n              <!--<img class=\"glyphicon glyphicon-star-empty\" src=\"../assets/icons/favorite_border.png\">-->\n              <!--<img class=\"glyphicon glyphicon-star\" src=\"../assets/icons/favorite_black.png\">-->\n            <!--</label>-->\n        </div>\n      <div *ngIf=\"!car.isavailable\"><h3 style=\"color: gold;\">NOT AVAILABLE</h3></div>\n        <div class=\"row\">\n            <div class=\"col-sm-4\" id = 'L_col'>\n                <div class=\"row\" >\n                    <img class = \"img\" mat-card-image src=\"{{car.imageName}}\" id = 'image'>\n                </div>\n                <div class=\"row\">\n                    <div class=\"col-sm\">\n                        <div class=\"row\">\n                        <svg-icon src = \"../assets/icons/Person.svg\"></svg-icon>\n                        </div>\n                        <div class=\"row\">\n                        {{car.passengers}}\n                        </div>\n                    </div>\n                    <div class=\"col-sm\">\n                        <div class=\"row\">\n                        <svg-icon src = \"../assets/icons/luggage.svg\"></svg-icon>\n                        </div>\n                        <div class=\"row\">\n                        {{car.luggage}}\n                        </div>\n                    </div>\n                    <div class=\"col-sm\">\n                        <div class=\"row\">\n                        <svg-icon src = \"../assets/icons/AC.svg\"></svg-icon>\n                        </div>\n                        <div class=\"row\">\n                        {{car.ACsup}}\n                        </div>\n                    </div>\n                    <div class=\"col-sm\">\n                        <div class=\"row\">\n                        <svg-icon src = \"../assets/icons/Auto.svg\" ></svg-icon>\n                        </div>\n                        <div class=\"row\">\n                        {{car.isAuto}}\n                        </div>\n                    </div>\n                </div>\n            </div>\n            <div class=\"col-sm-8\" id = 'R_col'>\n                <div class=\"row\">\n                    <img src=\"https://www.autoescape.com/images-cms/images/SUPPLIERS/TARSIER/65bb10e6e11aeaf4d88f9514491c6801_h25.png\">\n                </div>\n                <div class=\"row\">\n                    <div class=\"col-sm-6\">\n                            <li>Features</li>\n                            <li><img src = \"../assets/icons/check.png\" style =\"width:20px; height :20px;\" >{{car.type}}</li>\n                            <li><img src = \"../assets/icons/check.png\" style =\"width:20px; height :20px;\" >Pay at Pick-Up</li>\n                            <li><img src = \"../assets/icons/check.png\" style =\"width:20px; height :20px;\" >Free cancellation</li>\n                    </div>\n                    <div class=\"col-sm-6\">\n                        <p id= 'pickuptext'><svg-icon src = \"../assets/icons/Airports.svg\"></svg-icon>Pick-up:</p>\n                        <p>{{car.pickupLoc}}</p>\n                    </div>\n                </div>\n\n            </div>\n        </div>\n    </div>\n    <div  class = \"col-sm-2\" id = 'col_r'>\n            <div class=\"row\">\n                <p style=\"margin-left: 10px\">Pay at Pick-Up</p>\n            </div>\n            <li id = \"price_text\">${{car.price}}/day</li>\n\n            <div class=\"row\" id = \"button_row\">\n                <button id = 'continue_button' class = \"btn btn-primary\" style=\"width: 150px;height: 45px\" [disabled]=\"!car.isavailable\" type=\"button\"  (click)=\"btnContinueClick()\"   routerLink=\"/bookingdetail\">CONTINUE</button>\n            </div>\n      <!--(click)=\"btnContinueClick()\"-->\n    </div>\n</div>\n"

/***/ }),

/***/ "./src/app/card/card.component.ts":
/*!****************************************!*\
  !*** ./src/app/card/card.component.ts ***!
  \****************************************/
/*! exports provided: CardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CardComponent", function() { return CardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _class_car__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../class/car */ "./src/app/class/car.ts");
/* harmony import */ var _services_favoritelist_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/favoritelist.service */ "./src/app/services/favoritelist.service.ts");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_bookings_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/bookings.service */ "./src/app/services/bookings.service.ts");
/* harmony import */ var _services_data_bus_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/data-bus.service */ "./src/app/services/data-bus.service.ts");







var CardComponent = /** @class */ (function () {
    function CardComponent(dataBus, favoritelist, auth, bookingservice) {
        this.dataBus = dataBus;
        this.favoritelist = favoritelist;
        this.auth = auth;
        this.bookingservice = bookingservice;
        this.check = false;
        if (this.auth.isLoggedIn()) {
            this.email = this.auth.getUserDetails().email;
        }
    }
    CardComponent.prototype.ngOnInit = function () {
        console.log(this.favorites);
        if (this.favorites != null) {
            for (var _i = 0, _a = this.favorites; _i < _a.length; _i++) {
                var car = _a[_i];
                if (car.carid == this.car._id) {
                    this.check = true;
                    break;
                }
            }
        }
        console.log(this.check);
    };
    CardComponent.prototype.onchange = function (event) {
        this.favorite = {
            email: this.email,
            carid: this.car._id
        };
        console.log(this.car.name);
        if (event.target.checked) {
            console.log("checked");
            this.favoritelist.createFavorite(this.favorite).subscribe(function (data) {
                console.log(data);
            }, function (err) {
                console.log(err);
            });
        }
        else {
            console.log("unchecked");
            this.favoritelist.deleteFavorite(this.favorite).subscribe(function (data) {
                console.log(data);
            }, function (err) {
                console.log(err);
            });
        }
    };
    CardComponent.prototype.onclick = function () {
        // this.booking = new Booking('','','')
        // this.bookingservice.setBooking(this.booking);
        console.log(this.car.name);
    };
    CardComponent.prototype.btnContinueClick = function () {
        this.dataBus.setCarInfo(this.car);
        console.log('car set carinfor to databus');
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _class_car__WEBPACK_IMPORTED_MODULE_2__["Car"])
    ], CardComponent.prototype, "car", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Array)
    ], CardComponent.prototype, "favorites", void 0);
    CardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-card',
            template: __webpack_require__(/*! ./card.component.html */ "./src/app/card/card.component.html"),
            styles: [__webpack_require__(/*! ./card.component.css */ "./src/app/card/card.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_data_bus_service__WEBPACK_IMPORTED_MODULE_6__["DataBusService"], _services_favoritelist_service__WEBPACK_IMPORTED_MODULE_3__["FavoritelistService"], _services_authentication_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"], _services_bookings_service__WEBPACK_IMPORTED_MODULE_5__["BookingsService"]])
    ], CardComponent);
    return CardComponent;
}());



/***/ }),

/***/ "./src/app/carlists/carlists.component.css":
/*!*************************************************!*\
  !*** ./src/app/carlists/carlists.component.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".layout{\n    /*height:500px;*/\n}\nul{\n  list-style-type: none;\n}\nli{\n  position:relative;\n}\n/*.img{*/\n/*transition: transform 0.25s ease;;*/\n/*}*/\n.highlight{\n  -webkit-transform: scale(1.05);\n          transform: scale(1.05);\n  color:orange;\n  font-family:'STKaiti';\n  /*-ms-transform: scale(1.1);*/\n  /*-webkit-transform: scale(1.1);*/\n  /*-moz-transform: scale(1.1);*/\n  background: skyblue;\n\n}\n.not-highlight{\n  background: #fbeafc;\n}\n.adminpanel{\n\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2FybGlzdHMvY2FybGlzdHMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGdCQUFnQjtBQUNwQjtBQUNBO0VBQ0UscUJBQXFCO0FBQ3ZCO0FBRUE7RUFDRSxpQkFBaUI7QUFDbkI7QUFFQSxRQUFRO0FBQ04scUNBQXFDO0FBQ3ZDLElBQUk7QUFDSjtFQUNFLDhCQUFzQjtVQUF0QixzQkFBc0I7RUFDdEIsWUFBWTtFQUNaLHFCQUFxQjtFQUNyQiw2QkFBNkI7RUFDN0IsaUNBQWlDO0VBQ2pDLDhCQUE4QjtFQUM5QixtQkFBbUI7O0FBRXJCO0FBRUE7RUFDRSxtQkFBbUI7QUFDckI7QUFFQTs7QUFFQSIsImZpbGUiOiJzcmMvYXBwL2Nhcmxpc3RzL2Nhcmxpc3RzLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubGF5b3V0e1xuICAgIC8qaGVpZ2h0OjUwMHB4OyovXG59XG51bHtcbiAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xufVxuXG5saXtcbiAgcG9zaXRpb246cmVsYXRpdmU7XG59XG5cbi8qLmltZ3sqL1xuICAvKnRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjI1cyBlYXNlOzsqL1xuLyp9Ki9cbi5oaWdobGlnaHR7XG4gIHRyYW5zZm9ybTogc2NhbGUoMS4wNSk7XG4gIGNvbG9yOm9yYW5nZTtcbiAgZm9udC1mYW1pbHk6J1NUS2FpdGknO1xuICAvKi1tcy10cmFuc2Zvcm06IHNjYWxlKDEuMSk7Ki9cbiAgLyotd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoMS4xKTsqL1xuICAvKi1tb3otdHJhbnNmb3JtOiBzY2FsZSgxLjEpOyovXG4gIGJhY2tncm91bmQ6IHNreWJsdWU7XG5cbn1cblxuLm5vdC1oaWdobGlnaHR7XG4gIGJhY2tncm91bmQ6ICNmYmVhZmM7XG59XG5cbi5hZG1pbnBhbmVse1xuXG59XG4iXX0= */"

/***/ }),

/***/ "./src/app/carlists/carlists.component.html":
/*!**************************************************!*\
  !*** ./src/app/carlists/carlists.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class = \"layout\">\n    <!-- Content here -->\n  <!--<p>Car Information</p>-->\n  <!--<button (click)=\"getCarlists()\" >REQ</button>-->\n  <!--<button (click)=\"postCarInfo()\" >post</button>-->\n  <div class=\"adminpanel\">\n  <br>\n  <app-admincontrolpanel *ngIf=\"isAdmin\" (getAll)=\"getCarlists()\" [seletedCar]=\"selectedCar_p\"></app-admincontrolpanel>\n  <br>\n  </div>\n  <div *ngIf=\"showCards\">\n    <!--<p>Car Lists DATA:</p>-->\n    <ul *ngFor=\"let car of showinglist, let i = index\">\n      <li [ngClass]=\"{'highlight' : selected == i, 'not-highlight' : selected!=i}\"\n          (click)=\"car.isavailable &&  onSelect(i)\" > <app-card [car]=\"car\" [favorites]=\"favorites\"> </app-card> </li>\n    </ul>\n  </div>\n\n  <app-pagination\n    (goPage)=\"goToPage($event)\"\n    (goNext)=\"onNext()\"\n    (goPrev)=\"onPrev()\"\n    [pagesToShow]=\"8\"\n    [page]=\"page\"\n    [perPage]=\"limit\"\n    [count]=\"total\"></app-pagination>\n\n  </div>\n\n"

/***/ }),

/***/ "./src/app/carlists/carlists.component.ts":
/*!************************************************!*\
  !*** ./src/app/carlists/carlists.component.ts ***!
  \************************************************/
/*! exports provided: CarlistsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CarlistsComponent", function() { return CarlistsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/product.service */ "./src/app/services/product.service.ts");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_favoritelist_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/favoritelist.service */ "./src/app/services/favoritelist.service.ts");





var CarlistsComponent = /** @class */ (function () {
    function CarlistsComponent(carService, favoriteservice, auth) {
        var _this = this;
        this.carService = carService;
        this.favoriteservice = favoriteservice;
        this.auth = auth;
        this.selected = -1; //the selected card index;
        this.isAdmin = true; // true:if user is admin;
        this.showCards = true;
        //****for paginate
        this.loading = false;
        this.total = 0;
        this.page = 1;
        this.limit = 4;
        if (this.auth.isLoggedIn()) {
            this.favoriteservice.getFavoritesByEmail(this.auth.getUserDetails().email).subscribe(function (data) {
                _this.favorites = data;
            }, function (err) {
                console.log(err);
            });
        }
    }
    CarlistsComponent.prototype.ngOnInit = function () {
        console.log("==> NgInit - CarList");
        this.searchCarlists();
        this.isAdmin = this.auth.Ifadmin();
    };
    CarlistsComponent.prototype.footerRunLoc = function (pickplace) {
        this.pickPlace = pickplace;
        //console.log("carlist run");
        this.searchCarlists();
    };
    CarlistsComponent.prototype.footerRunAll = function () {
        this.getCarlists();
    };
    CarlistsComponent.prototype.footerRunFilter = function (new_options) {
        this.newOptions = new_options;
        //console.log("footer run filter");
        //console.log(this.newOptions);
        this.searchCarFilter();
    };
    CarlistsComponent.prototype.searchCarFilter = function () {
        var _this = this;
        this.loading = true;
        console.log(this.newOptions);
        this.carService.searchCarwithFilter(this.newOptions).subscribe(function (res) {
            _this.cars = res;
            _this.total = res.length;
            _this.showinglist = _this.cars.slice(0, _this.limit);
            _this.page = 1;
            //init the selected status and seleted Car info for adminControl
            _this.selected = -1;
            _this.selectedCar_p = null;
            _this.loading = false;
        }, function (error1) {
            "search error!!!!!!";
        });
    };
    CarlistsComponent.prototype.searchCarlists = function () {
        var _this = this;
        this.loading = true;
        this.carService.searchCarProduct(this.pickPlace).subscribe(function (res) {
            _this.cars = res;
            //console.log(res("isavalible"));
            _this.total = res.length;
            _this.showinglist = _this.cars.slice(0, _this.limit);
            _this.page = 1;
            //init the selected status and seleted Car info for adminControl
            _this.selected = -1;
            _this.selectedCar_p = null;
            _this.loading = false;
        }, function (error1) {
            "search error!!!!!!";
        });
    };
    // getMessages(): void {
    CarlistsComponent.prototype.getCarlists = function () {
        var _this = this;
        console.log('--get all cars-');
        this.loading = true;
        this.carService.getAllProduct().subscribe(function (res) {
            _this.cars = res;
            _this.total = res.length;
            _this.showinglist = _this.cars.slice(0, _this.limit);
            _this.page = 1;
            //init the selected status and seleted Car info for adminControl
            _this.selected = -1;
            _this.selectedCar_p = null;
            _this.loading = false;
        });
    };
    // postCarInfo(){
    //   let car1:Car = new Car("new car1111","new type",
    // 5, 23.11, 3, true, true,  'Dallas love field',
    // 15, "/assets/carimages/chevrolet_tahoe_suv_brl_287x164.jpg", true);
    //   this.carService.postCar(car1);
    //   console.log('postCarInfo finish - in carlist');
    //
    // }
    CarlistsComponent.prototype.onSelect = function (e) {
        if (e != this.selected) {
            this.selected = e;
            this.selectedCar_p = this.showinglist[e];
            console.log("index:" + e + " _id:" + this.showinglist[e]._id);
        }
        else {
            this.selected = -1;
            this.selectedCar_p = null;
        }
    };
    CarlistsComponent.prototype.getFrom = function () {
        return ((this.limit * this.page) - this.limit);
    };
    CarlistsComponent.prototype.getTo = function () {
        var max = this.limit * this.page;
        if (max > this.total) {
            max = this.total;
        }
        return max;
    };
    CarlistsComponent.prototype.goToPage = function (n) {
        if (this.page != n) {
            this.selected = -1;
            this.selectedCar_p = null;
            this.page = n;
            this.showinglist = this.cars.slice(this.getFrom(), this.getTo());
        }
    };
    CarlistsComponent.prototype.onNext = function () {
        this.page++;
        this.selected = -1;
        this.selectedCar_p = null;
        this.showinglist = this.cars.slice(this.getFrom(), this.getTo());
    };
    CarlistsComponent.prototype.onPrev = function () {
        this.page--;
        this.selected = -1;
        this.selectedCar_p = null;
        this.showinglist = this.cars.slice(this.getFrom(), this.getTo());
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", String)
    ], CarlistsComponent.prototype, "pickPlace", void 0);
    CarlistsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-carlists',
            template: __webpack_require__(/*! ./carlists.component.html */ "./src/app/carlists/carlists.component.html"),
            styles: [__webpack_require__(/*! ./carlists.component.css */ "./src/app/carlists/carlists.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_product_service__WEBPACK_IMPORTED_MODULE_2__["ProductService"], _services_favoritelist_service__WEBPACK_IMPORTED_MODULE_4__["FavoritelistService"], _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"]])
    ], CarlistsComponent);
    return CarlistsComponent;
}());



/***/ }),

/***/ "./src/app/class/car.ts":
/*!******************************!*\
  !*** ./src/app/class/car.ts ***!
  \******************************/
/*! exports provided: Car, Boooking */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Car", function() { return Car; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Boooking", function() { return Boooking; });
var Car = /** @class */ (function () {
    function Car(name, type, passengers, price, luggage, isAuto, ACsup, pickupLoc, insurance, imageName, isavailable, _id) {
        this.name = name;
        this.type = type;
        this.passengers = passengers;
        this.price = price;
        this.luggage = luggage;
        this.isAuto = isAuto;
        this.ACsup = ACsup;
        this.pickupLoc = pickupLoc;
        this.insurance = insurance;
        this.imageName = imageName;
        this.isavailable = isavailable;
        this._id = _id;
    }
    return Car;
}());

var Boooking = /** @class */ (function () {
    // public _id:string;
    function Boooking(car_ID, startDate, finishDate, pickupLocation, returnLocation) {
        this.car_ID = car_ID;
        this.startDate = startDate;
        this.finishDate = finishDate;
        this.pickupLocation = pickupLocation;
        this.returnLocation = returnLocation;
    }
    return Boooking;
}());

// export const CARS = [
//   {
//     name: 'Nissan Altima',
//     type: 'Standard',
//     imageName: '/assets/carimages/nissan_altima_standard_brl_287x164.jpg',
//     passengers: 5,
//     luggage: 2,
//     price: 40.00,
//     ACsup:true,
//     isAuto: true,
//     pickupLoc: 'DALLAS LOVE FIELD - Dallas Love Field',
//     isavailable:true,
//     insurance:10.00
//   },
//   {
//     name: 'Chevrolet Sonica',
//     type: 'Economy',
//     imageName: '/assets/carimages/chevrolet_sonic_economy_brl_287x164.jpg',
//     passengers: 5,
//     luggage: 2,
//     price: 40.00,
//     ACsup:true,
//     isAuto: true,
//     pickupLoc: 'Plano high school',
//     isavailable:true,
//     insurance:10.00
//   }
// ];


/***/ }),

/***/ "./src/app/deletedialog/deletedialog.component.css":
/*!*********************************************************!*\
  !*** ./src/app/deletedialog/deletedialog.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".overlay {\n  position: fixed;\n  top: 0;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  background-color: rgba(0, 0, 0, 0.5);\n  z-index: 999;\n}\n\n.dialog {\n  z-index: 1000;\n  position: fixed;\n  right: 0;\n  left: 0;\n  top: 20px;\n  margin-right: auto;\n  margin-left: auto;\n  min-height: 200px;\n  width: 90%;\n  max-width: 750px;\n  background-color: #fff;\n  padding: 12px;\n  box-shadow: 0 7px 8px -4px rgba(0, 0, 0, 0.2), 0 13px 19px 2px rgba(0, 0, 0, 0.14), 0 5px 24px 4px rgba(0, 0, 0, 0.12);\n}\n\n.content{\n  padding-top: 30px;\n  color: blue;\n}\n\n@media (min-width: 768px) {\n  .dialog {\n    top: 30px;\n  }\n}\n\n.dialog__close-btn {\n  border: 0;\n  background: none;\n  color: #2d2d2d;\n  position: absolute;\n  top: 8px;\n  right: 8px;\n  font-size: 1.2em;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGVsZXRlZGlhbG9nL2RlbGV0ZWRpYWxvZy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBZTtFQUNmLE1BQU07RUFDTixTQUFTO0VBQ1QsT0FBTztFQUNQLFFBQVE7RUFDUixvQ0FBb0M7RUFDcEMsWUFBWTtBQUNkOztBQUVBO0VBQ0UsYUFBYTtFQUNiLGVBQWU7RUFDZixRQUFRO0VBQ1IsT0FBTztFQUNQLFNBQVM7RUFDVCxrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLGlCQUFpQjtFQUNqQixVQUFVO0VBQ1YsZ0JBQWdCO0VBQ2hCLHNCQUFzQjtFQUN0QixhQUFhO0VBQ2Isc0hBQXNIO0FBQ3hIOztBQUVBO0VBQ0UsaUJBQWlCO0VBQ2pCLFdBQVc7QUFDYjs7QUFFQTtFQUNFO0lBQ0UsU0FBUztFQUNYO0FBQ0Y7O0FBRUE7RUFDRSxTQUFTO0VBQ1QsZ0JBQWdCO0VBQ2hCLGNBQWM7RUFDZCxrQkFBa0I7RUFDbEIsUUFBUTtFQUNSLFVBQVU7RUFDVixnQkFBZ0I7QUFDbEIiLCJmaWxlIjoic3JjL2FwcC9kZWxldGVkaWFsb2cvZGVsZXRlZGlhbG9nLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIub3ZlcmxheSB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgdG9wOiAwO1xuICBib3R0b206IDA7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNSk7XG4gIHotaW5kZXg6IDk5OTtcbn1cblxuLmRpYWxvZyB7XG4gIHotaW5kZXg6IDEwMDA7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgcmlnaHQ6IDA7XG4gIGxlZnQ6IDA7XG4gIHRvcDogMjBweDtcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgbWluLWhlaWdodDogMjAwcHg7XG4gIHdpZHRoOiA5MCU7XG4gIG1heC13aWR0aDogNzUwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIHBhZGRpbmc6IDEycHg7XG4gIGJveC1zaGFkb3c6IDAgN3B4IDhweCAtNHB4IHJnYmEoMCwgMCwgMCwgMC4yKSwgMCAxM3B4IDE5cHggMnB4IHJnYmEoMCwgMCwgMCwgMC4xNCksIDAgNXB4IDI0cHggNHB4IHJnYmEoMCwgMCwgMCwgMC4xMik7XG59XG5cbi5jb250ZW50e1xuICBwYWRkaW5nLXRvcDogMzBweDtcbiAgY29sb3I6IGJsdWU7XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiA3NjhweCkge1xuICAuZGlhbG9nIHtcbiAgICB0b3A6IDMwcHg7XG4gIH1cbn1cblxuLmRpYWxvZ19fY2xvc2UtYnRuIHtcbiAgYm9yZGVyOiAwO1xuICBiYWNrZ3JvdW5kOiBub25lO1xuICBjb2xvcjogIzJkMmQyZDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDhweDtcbiAgcmlnaHQ6IDhweDtcbiAgZm9udC1zaXplOiAxLjJlbTtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/deletedialog/deletedialog.component.html":
/*!**********************************************************!*\
  !*** ./src/app/deletedialog/deletedialog.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div [@dialog] *ngIf=\"visible\" class=\"dialog\">\n  <div class = 'content'>\n    <ng-content ></ng-content>\n  </div>\n  <button *ngIf=\"closable\" (click)=\"close()\" aria-label=\"Close\" class=\"dialog__close-btn\">X</button>\n</div>\n<div *ngIf=\"visible\" class=\"overlay\" (click)=\"close()\"></div>\n\n\n"

/***/ }),

/***/ "./src/app/deletedialog/deletedialog.component.ts":
/*!********************************************************!*\
  !*** ./src/app/deletedialog/deletedialog.component.ts ***!
  \********************************************************/
/*! exports provided: DeletedialogComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DeletedialogComponent", function() { return DeletedialogComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/esm5/animations.js");



var DeletedialogComponent = /** @class */ (function () {
    function DeletedialogComponent() {
        this.closable = true;
        this.visibleChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    DeletedialogComponent.prototype.ngOnInit = function () { };
    DeletedialogComponent.prototype.close = function () {
        this.visible = false;
        this.visibleChange.emit(this.visible);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DeletedialogComponent.prototype, "closable", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], DeletedialogComponent.prototype, "visible", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], DeletedialogComponent.prototype, "visibleChange", void 0);
    DeletedialogComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-deletedialog',
            template: __webpack_require__(/*! ./deletedialog.component.html */ "./src/app/deletedialog/deletedialog.component.html"),
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_2__["trigger"])('dialog', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_2__["transition"])('void => *', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_2__["style"])({ transform: 'scale3d(.3, .3, .3)' }),
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_2__["animate"])(100)
                    ]),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_2__["transition"])('* => void', [
                        Object(_angular_animations__WEBPACK_IMPORTED_MODULE_2__["animate"])(100, Object(_angular_animations__WEBPACK_IMPORTED_MODULE_2__["style"])({ transform: 'scale3d(.0, .0, .0)' }))
                    ])
                ])
            ],
            styles: [__webpack_require__(/*! ./deletedialog.component.css */ "./src/app/deletedialog/deletedialog.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], DeletedialogComponent);
    return DeletedialogComponent;
}());



/***/ }),

/***/ "./src/app/favoritelist/favoritelist.component.css":
/*!*********************************************************!*\
  !*** ./src/app/favoritelist/favoritelist.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".layout{\n  /*height:500px;*/\n}\nul{\n  list-style-type: none;\n}\nli{\n  position:relative;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZmF2b3JpdGVsaXN0L2Zhdm9yaXRlbGlzdC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxxQkFBcUI7QUFDdkI7QUFFQTtFQUNFLGlCQUFpQjtBQUNuQiIsImZpbGUiOiJzcmMvYXBwL2Zhdm9yaXRlbGlzdC9mYXZvcml0ZWxpc3QuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sYXlvdXR7XG4gIC8qaGVpZ2h0OjUwMHB4OyovXG59XG51bHtcbiAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xufVxuXG5saXtcbiAgcG9zaXRpb246cmVsYXRpdmU7XG59XG4iXX0= */"

/***/ }),

/***/ "./src/app/favoritelist/favoritelist.component.html":
/*!**********************************************************!*\
  !*** ./src/app/favoritelist/favoritelist.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class = \"layout\">\n  <!-- Content here -->\n  <div>\n    <p>Car Lists DATA:</p>\n    <ul *ngFor=\"let car of showinglist\">\n      <li> <app-card [car]=\"car\" [favorites]=\"favorites\"> </app-card> </li>\n    </ul>\n  </div>\n\n  <app-pagination\n    (goPage)=\"goToPage($event)\"\n    (goNext)=\"onNext()\"\n    (goPrev)=\"onPrev()\"\n    [pagesToShow]=\"8\"\n    [page]=\"page\"\n    [perPage]=\"limit\"\n    [count]=\"total\"></app-pagination>\n\n</div>\n"

/***/ }),

/***/ "./src/app/favoritelist/favoritelist.component.ts":
/*!********************************************************!*\
  !*** ./src/app/favoritelist/favoritelist.component.ts ***!
  \********************************************************/
/*! exports provided: FavoritelistComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FavoritelistComponent", function() { return FavoritelistComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/product.service */ "./src/app/services/product.service.ts");
/* harmony import */ var _services_favoritelist_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/favoritelist.service */ "./src/app/services/favoritelist.service.ts");





var FavoritelistComponent = /** @class */ (function () {
    function FavoritelistComponent(routerIonfo, carService, favoriteserivce) {
        this.routerIonfo = routerIonfo;
        this.carService = carService;
        this.favoriteserivce = favoriteserivce;
        this.showinglist = [];
        this.loading = false;
        this.email = this.routerIonfo.snapshot.queryParams["email"];
    }
    FavoritelistComponent.prototype.ngOnInit = function () {
        this.getCarlists();
    };
    FavoritelistComponent.prototype.getCarlists = function () {
        var _this = this;
        this.loading = true;
        this.carService.getAllProduct().subscribe(function (res) {
            console.log(res);
            _this.favoriteserivce.getFavoritesByEmail(_this.email).subscribe(function (data) {
                _this.favorites = data;
                var set = new Set();
                for (var _i = 0, res_1 = res; _i < res_1.length; _i++) {
                    var car = res_1[_i];
                    for (var _a = 0, _b = _this.favorites; _a < _b.length; _a++) {
                        var favorite = _b[_a];
                        if (car._id == favorite.carid && !set.has(car._id)) {
                            _this.showinglist.push(car);
                            set.add(car._id);
                        }
                    }
                }
            }, function (err) {
                console.log(err);
            });
            _this.loading = false;
        });
    };
    FavoritelistComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-favoritelist',
            template: __webpack_require__(/*! ./favoritelist.component.html */ "./src/app/favoritelist/favoritelist.component.html"),
            styles: [__webpack_require__(/*! ./favoritelist.component.css */ "./src/app/favoritelist/favoritelist.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_product_service__WEBPACK_IMPORTED_MODULE_3__["ProductService"], _services_favoritelist_service__WEBPACK_IMPORTED_MODULE_4__["FavoritelistService"]])
    ], FavoritelistComponent);
    return FavoritelistComponent;
}());



/***/ }),

/***/ "./src/app/filter/filter.component.css":
/*!*********************************************!*\
  !*** ./src/app/filter/filter.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".filter{\n    height: 500px;\n    background-color: burlywood;\n}\np{\n  color: #3162ff;\n}\nform{\n  margin-left:50px;\n}\n.btn{\n  float:right;\n}\n.slider {\n  -webkit-appearance: none;\n  width: 100%;\n  height: 15px;\n  border-radius: 5px;\n  background: #d3d3d3;\n  outline: none;\n  opacity: 0.7;\n  -webkit-transition: .2s;\n  -webkit-transition: opacity .2s;\n  transition: opacity .2s;\n\n}\n.slider::-webkit-slider-thumb {\n  -webkit-appearance: none;\n  width: 25px;\n  height: 25px;\n  border-radius: 50%;\n  background: #4CAF50;\n  cursor: pointer;\n}\n.slider::-moz-range-thumb {\n  width: 25px;\n  height: 25px;\n  border-radius: 50%;\n  background: #4CAF50;\n  cursor: pointer;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZmlsdGVyL2ZpbHRlci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksYUFBYTtJQUNiLDJCQUEyQjtBQUMvQjtBQUNBO0VBQ0UsY0FBYztBQUNoQjtBQUNBO0VBQ0UsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxXQUFXO0FBQ2I7QUFDQTtFQUNFLHdCQUF3QjtFQUN4QixXQUFXO0VBQ1gsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsYUFBYTtFQUNiLFlBQVk7RUFDWix1QkFBdUI7RUFDdkIsK0JBQXVCO0VBQXZCLHVCQUF1Qjs7QUFFekI7QUFFQTtFQUNFLHdCQUF3QjtFQUN4QixXQUFXO0VBQ1gsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixtQkFBbUI7RUFDbkIsZUFBZTtBQUNqQjtBQUVBO0VBQ0UsV0FBVztFQUNYLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLGVBQWU7QUFDakIiLCJmaWxlIjoic3JjL2FwcC9maWx0ZXIvZmlsdGVyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZmlsdGVye1xuICAgIGhlaWdodDogNTAwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogYnVybHl3b29kO1xufVxucHtcbiAgY29sb3I6ICMzMTYyZmY7XG59XG5mb3Jte1xuICBtYXJnaW4tbGVmdDo1MHB4O1xufVxuLmJ0bntcbiAgZmxvYXQ6cmlnaHQ7XG59XG4uc2xpZGVyIHtcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxNXB4O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIGJhY2tncm91bmQ6ICNkM2QzZDM7XG4gIG91dGxpbmU6IG5vbmU7XG4gIG9wYWNpdHk6IDAuNztcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiAuMnM7XG4gIHRyYW5zaXRpb246IG9wYWNpdHkgLjJzO1xuXG59XG5cbi5zbGlkZXI6Oi13ZWJraXQtc2xpZGVyLXRodW1iIHtcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xuICB3aWR0aDogMjVweDtcbiAgaGVpZ2h0OiAyNXB4O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGJhY2tncm91bmQ6ICM0Q0FGNTA7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLnNsaWRlcjo6LW1vei1yYW5nZS10aHVtYiB7XG4gIHdpZHRoOiAyNXB4O1xuICBoZWlnaHQ6IDI1cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYmFja2dyb3VuZDogIzRDQUY1MDtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuIl19 */"

/***/ }),

/***/ "./src/app/filter/filter.component.html":
/*!**********************************************!*\
  !*** ./src/app/filter/filter.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<aside class=\"control-sidebar control-sidebar-dark\" style=\"margin-top: 40px\">\n<form [formGroup]=\"formModel\">\n  <p>PRICE SCOPE (1 day)   </p>\n  <!--<select id=\"pricelist\" class=\"form-control\">-->\n    <!--<option value=\"all\">-ALL-</option>-->\n    <!--<option value=\"one\">Under 50$</option>-->\n    <!--<option value=\"two\">50$ - 100$</option>-->\n    <!--<option value=\"three\">100$ - 150$</option>-->\n    <!--<option value=\"four\">150$ - 200$</option>-->\n    <!--<option value=\"five\">Above 200$</option>-->\n  <!--</select>-->\n\n  <select formControlName=\"price\" class=\"form-control\">\n    <option *ngFor=\"let price of pricelist\" value=\"{{price.id}}\">{{price.text}}</option>\n  </select>\n\n  <br><br>\n  <div>\n    <p>CAR TYPE</p>\n    <!--<label><input type=\"checkbox\"  id=\"alltypes\" [checked]=\"isAllChecked()\" (change)=\"typecheckAll($event)\">Select All Type</label>-->\n    <!--<div formArrayName=\"type\" *ngFor=\"let op of options; let i = index\" class=\"form-check\" >-->\n      <!--<input type=\"checkbox\" [formControlName]=\"i\"  [(ngModel)]=\"op.state\"   value=\"{{op.id}}\"/>{{op.text}}-->\n      <!--&lt;!&ndash;[id]=\"op.id\"&ndash;&gt;-->\n      <!--&lt;!&ndash;(change)=\"onTpyeChange(op, $event.target.checked)\"&ndash;&gt;-->\n    <!--</div>-->\n    <label *ngIf=\"false\"><input type=\"checkbox\"  id=\"alltypes\" [checked]=\"isAllChecked()\" (change)=\"typecheckAll($event)\">Select All Type</label>\n    <div formArrayName=\"type\" *ngFor=\"let op of options; let i = index\" class=\"form-check\" style=\"padding-left: 0px\">\n      <label><input type=\"checkbox\" [formControlName]=\"i\"  [(ngModel)]=\"op.state\"   value=\"{{op.id}}\"/> {{op.text}}</label>\n    </div>\n  </div>\n\n  <!--<div *ngFor=\"let data of emails\">-->\n    <!--<input type=\"checkbox\" (change)=\"onChange(data.email, $event.target.checked)\"> {{data.email}}<br>-->\n  <!--</div>-->\n\n  <br><br>\n  <p>PASSENGER NUMBER: {{psgervalue}}</p>\n  <div  class=\"passenger\">\n    <!--<input  type=\"range\" min=\"2\" max=\"7\" formControlName=\"paserNum\" value=\"{{psgervalue}}\" [(ngModel)]=\"psgervalue\" class=\"slider\" id=\"myRange\" [ngModelOptions]=\"{standalone: true}\"/>-->\n    <input  type=\"range\" min=\"2\" max=\"7\" formControlName=\"paserNum\" value=\"{{psgervalue}}\" [(ngModel)]=\"psgervalue\" class=\"slider\" id=\"myRange\" />\n  </div>\n\n  <br><br>\n  <p>DRIVER'S AGE</p>\n  <div>\n    <div class=\"passenger\" >\n    <input checked formControlName=\"age\" type=\"radio\" name=\"age\" value=\"larger18\" > ADULT<br>\n    <input formControlName=\"age\" type=\"radio\" name=\"age\" value=\"less18\"> Under 18<br>\n    </div>\n  </div>\n  <!--<input (change)=\"changeDS()\" [(ngModel)]=\"testvalue\" [ngModelOptions]=\"{standalone: true}\"/>-->\n  <!--{{testvalue}}-->\n</form>\n  <!--<div>-->\n    <!--{{myForm.value | json }}-->\n  <!--</div>-->\n</aside>\n"

/***/ }),

/***/ "./src/app/filter/filter.component.ts":
/*!********************************************!*\
  !*** ./src/app/filter/filter.component.ts ***!
  \********************************************/
/*! exports provided: FilterComponent, FilterOptions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilterComponent", function() { return FilterComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilterOptions", function() { return FilterOptions; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/esm5/forms.js");



// import * as $ from 'jquery';
var FilterComponent = /** @class */ (function () {
    function FilterComponent() {
        // flag:boolean;
        this.pricelist = [];
        this.options = []; // object: {id, text} or array: []
        this.formModel = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            price: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](),
            type: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormArray"]([
                new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("eco"),
                new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("cmpt"),
                new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("std"),
                new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("suv"),
                new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("lux")
            ]),
            paserNum: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](),
            age: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]()
        });
        this.carFilter = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    FilterComponent.prototype.ngOnInit = function () {
        // this.flag = false;
        this.psgervalue = 7;
        // this.formModel.get('price').controls.price.value = 0;
        this.formModel.setControl('age', new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("larger18"));
        this.formModel.setControl('price', new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]("0"));
        // this.formModel.value.age.value="larger18" ;
        this.options = [
            { id: 'eco', text: 'Economy' },
            { id: 'cmpt', text: 'Compact' },
            { id: 'std', text: 'Standard' },
            { id: 'suv', text: 'SUV' },
            { id: 'lux', text: 'Luxury' }
        ];
        this.pricelist = [
            { id: '0', text: '--ALL--' },
            { id: '1', text: 'Under 50$' },
            { id: '2', text: '50$ - 100$' },
            { id: '3', text: '100$ - 150$' },
            { id: '4', text: '150$ - 200$' },
            { id: '5', text: 'Above 200$' }
        ];
        this.options.forEach(function (x) { return x.state = true; });
    };
    FilterComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        console.log("--filter:ngAfterViewInit--");
        this.formModel.valueChanges.subscribe(function (value) {
            _this.onSubmit(value);
        });
        this.onSubmit(this.formModel.value);
    };
    FilterComponent.prototype.typecheckAll = function (ev) {
        this.options.forEach(function (x) { return x.state = ev.target.checked; });
    };
    FilterComponent.prototype.isAllChecked = function () {
        return this.options.every(function (_) { return _.state; });
    };
    FilterComponent.prototype.getMinPrice = function (index) {
        switch (index) {
            case '0':
            case '1':
                return 0;
            case '2':
                return 50;
            case '3':
                return 100;
            case '4':
                return 150;
            case '5':
                return 200;
            default:
                return 0;
        }
    };
    FilterComponent.prototype.getMaxPrice = function (index) {
        if (index == '0') {
            return 5000;
        }
        else if (index == '1') {
            return 50;
        }
        else {
            return this.getMinPrice(index) + 50;
        }
    };
    FilterComponent.prototype.getTypes = function (index) {
        var types = new Array();
        for (var i in index) {
            if (index[i]) {
                if (this.options[i].text == 'Luxury' && this.formModel.value.age != 'larger18') {
                    continue;
                }
                types.push(this.options[i].text);
            }
        }
        return types;
    };
    FilterComponent.prototype.onSubmit = function (value) {
        console.log("my submit -----");
        var values = this.formModel.value;
        var min = this.getMinPrice(values.price);
        var max = this.getMaxPrice(values.price);
        var cartypes = this.getTypes(values.type);
        var max_pasgerNum = values.paserNum;
        var isAdult = ((values.age == 'larger18') ? true : false);
        this.carFilter.emit(new FilterOptions(min, max, cartypes, max_pasgerNum, isAdult));
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], FilterComponent.prototype, "carFilter", void 0);
    FilterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-filter',
            template: __webpack_require__(/*! ./filter.component.html */ "./src/app/filter/filter.component.html"),
            styles: [__webpack_require__(/*! ./filter.component.css */ "./src/app/filter/filter.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], FilterComponent);
    return FilterComponent;
}());

var FilterOptions = /** @class */ (function () {
    function FilterOptions(price_min, price_max, carType, pasgerNum_max, isAdult) {
        this.price_min = price_min;
        this.price_max = price_max;
        this.carType = carType;
        this.pasgerNum_max = pasgerNum_max;
        this.isAdult = isAdult;
    }
    return FilterOptions;
}());



/***/ }),

/***/ "./src/app/footer/footer.component.css":
/*!*********************************************!*\
  !*** ./src/app/footer/footer.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/footer/footer.component.html":
/*!**********************************************!*\
  !*** ./src/app/footer/footer.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "  <!-- Footer Area Start -->\n  <footer class=\"gauto-footer-area\">\n      <div class=\"footer-top-area\">\n         <div class=\"container\">\n            <div class=\"row\">\n               <div class=\"col-lg-4\">\n                  <div class=\"single-footer\">\n                     <div class=\"footer-address\">\n                        <h3>Opening Hours</h3>\n                        <div class=\"about-hours\">\n                            <ul>\n                               <li><i class=\"fa fa-check\"></i>Mon-Fri\t09:00 - 22:00</li>\n                               <li><i class=\"fa fa-check\"></i>Sat- SUb\t09:00 - 21:00</li>\n                               <li><i class=\"fa fa-check\"></i>Sun\t09:00 - 21:00 </li>\n                            </ul>\n                         </div>\n                     </div>\n                       <div class=\"footer-address\">\n                        <h3>Main office</h3>\n                        <ul>\n                           <li><i class=\"fa fa-map-marker\"></i> Pigadia Karpathos <span>85700 Greece</span> </li>\n                           <li><i class=\"fa fa-phone\"></i> 030-22450-29167 </li>\n                           <li><i class=\"fa fa-mobile\"></i> 30 6972 159007 </li>\n                           <li><i class=\"fa fa-envelope-o\"></i> autolandkarpathos@yahoo.gr</li>\n                        </ul>\n                     </div>\n                  </div>\n               </div>\n               <div class=\"col-lg-4\">\n                  <div class=\"single-footer quick_links\">\n                     <h3>Quick Links</h3>\n                     <ul class=\"quick-links\">\n                        <li><a href=\"#\">About us</a></li>\n                        <li><a href=\"#\">Our Fleet</a></li>\n                        <li><a href=\"#\">Our Benefitcs</a></li>\n                        <li><a href=\"#\">Our Island</a></li>\n                     </ul>\n                     <ul class=\"quick-links\">\n                        <li><a href=\"#\">My Booking</a></li>\n                        <li><a href=\"#\">Cancellations</a></li>\n                        <li><a href=\"#\">Special Inquiries</a></li>\n                     </ul>\n                  </div>\n                  <div class=\"single-footer newsletter_box\">\n                     <h3>newsletter</h3>\n                     <form>\n                        <input type=\"email\" placeholder=\"Email Address\" />\n                        <button type=\"submit\"><i class=\"fa fa-paper-plane\"></i></button>\n                     </form>\n                  </div>\n               </div>\n               <div class=\"col-lg-4\">\n                  <div class=\"single-footer\">\n                     <h3>Find Us on the Map</h3>\n                     <div class=\"row\">\n                      <div class=\"col-sm-3\">\n                     <div class=\"ci-map-wrap\"><iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3247.8451182084323!2d27.210234815716248!3d35.50810779880249!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14940229188a3459%3A0x8304c3b5ebe017bc!2zVW5uYW1lZCBSZCwgzprOrM-Bz4DOsc64zr_PgiA4NTcgMDAsIM6VzrvOu86szrTOsQ!5e0!3m2!1sel!2sgr!4v1466623396707\" width=\"300\" height=\"300\" frameborder=\"0\" style=\"border:0\" allowfullscreen=\"\"></iframe></div>\n                      </div>\n                     </div>\n                     <!--  <ul>\n                        <li>\n                           <div class=\"single-footer-post\">\n                              <div class=\"footer-post-image\">\n                                 <a href=\"#\">\n                                 <img src=\"assets/img/post-thumb-3.jpg\" alt=\"footer post\" />\n                                 </a>\n                              </div>\n                              <div class=\"footer-post-text\">\n                                 <h3>\n                                    <a href=\"#\">\n                                    Revealed: How to set goals for you and your team\n                                    </a>\n                                 </h3>\n                                 <p>Posted on: Jan 12, 2019</p>\n                              </div>\n                           </div>\n                        </li>\n                        <li>\n                           <div class=\"single-footer-post\">\n                              <div class=\"footer-post-image\">\n                                 <a href=\"#\">\n                                 <img src=\"assets/img/post-thumb-2.jpg\" alt=\"footer post\" />\n                                 </a>\n                              </div>\n                              <div class=\"footer-post-text\">\n                                 <h3>\n                                    <a href=\"#\">\n                                    Revealed: How to set goals for you and your team\n                                    </a>\n                                 </h3>\n                                 <p>Posted on: Jan 12, 2019</p>\n                              </div>\n                           </div>\n                        </li>\n                        <li>\n                           <div class=\"single-footer-post\">\n                              <div class=\"footer-post-image\">\n                                 <a href=\"#\">\n                                 <img src=\"assets/img/post-thumb-1.jpg\" alt=\"footer post\" />\n                                 </a>\n                              </div>\n                              <div class=\"footer-post-text\">\n                                 <h3>\n                                    <a href=\"#\">\n                                    apartment in the sky love three boys of his own.\n                                    </a>\n                                 </h3>\n                                 <p>Posted on: Jan 12, 2019</p>\n                              </div>\n                           </div>\n                        </li>\n                     </ul> -->\n                  </div>\n               </div>\n            </div>\n         </div>\n      </div>\n      <div class=\"footer-bottom-area\">\n         <div class=\"container\">\n            <div class=\"row\">\n               <div class=\"col-md-6\">\n                  <div class=\"copyright\">\n                     <p>AUTOLAND KARPATHOS ISLAND RENT A CAR - 2020</p>\n                  </div>\n               </div>\n               <div class=\"col-md-6\">\n                  <div class=\"footer-social\">\n                     <ul>\n                        <li><a href=\"#\"><i class=\"fa fa-facebook\"></i></a></li>\n                        <li><a href=\"#\"><i class=\"fa fa-twitter\"></i></a></li>\n                        <li><a href=\"#\"><i class=\"fa fa-linkedin\"></i></a></li>\n                        <li><a href=\"#\"><i class=\"fa fa-skype\"></i></a></li>\n                     </ul>\n                  </div>\n               </div>\n            </div>\n         </div>\n      </div>\n   </footer>\n   <!-- Footer Area End -->\n"

/***/ }),

/***/ "./src/app/footer/footer.component.ts":
/*!********************************************!*\
  !*** ./src/app/footer/footer.component.ts ***!
  \********************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");


var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent.prototype.ngOnInit = function () {
    };
    FooterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-footer',
            template: __webpack_require__(/*! ./footer.component.html */ "./src/app/footer/footer.component.html"),
            styles: [__webpack_require__(/*! ./footer.component.css */ "./src/app/footer/footer.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/header/header.component.css":
/*!*********************************************!*\
  !*** ./src/app/header/header.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2hlYWRlci9oZWFkZXIuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/header/header.component.html":
/*!**********************************************!*\
  !*** ./src/app/header/header.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- Header Top Area Start -->\n<section class=\"gauto-header-top-area\">\n  <div class=\"container\">\n    <div class=\"row\">\n      <div class=\"col-md-6\">\n        <div class=\"header-top-left\">\n            <p>KARPATHOS ISLAND RENTAL</p>\n        </div>\n      </div>\n      <div class=\"col-md-6\">\n\n      <div class=\"header-top-right\">\n           <p>Need Help?: <i class=\"fa fa-phone\"></i> Call: +030-22450-29167</p>\n           <!-- <a href=\"#\">\n            <i class=\"fa fa-key\"></i>\n            login\n          </a>\n          <a href=\"#\">\n            <i class=\"fa fa-user\"></i>\n            register\n          </a>\n          <div class=\"dropdown\">\n            <button\n              class=\"btn-dropdown dropdown-toggle\"\n              type=\"button\"\n              id=\"dropdownlang\"\n              data-toggle=\"dropdown\"\n              aria-haspopup=\"true\"\n            >\n              <img src=\"assets/img/en.png\" alt=\"lang\" /> English\n            </button>\n            <ul class=\"dropdown-menu\" aria-labelledby=\"dropdownlang\">\n              <li><img src=\"assets/img/ca.png\" alt=\"lang\" /> Canada</li>\n              <li><img src=\"assets/img/fa.png\" alt=\"lang\" /> French</li>\n              <li><img src=\"assets/img/ja.png\" alt=\"lang\" /> Japanese</li>\n            </ul>\n          </div>-->\n        </div>\n      </div>\n    </div>\n  </div>\n</section>\n<!-- Header Top Area End -->\n\n<!-- Main Header Area Start -->\n<header class=\"gauto-main-header-area\">\n  <div class=\"container\">\n    <div class=\"row\">\n      <div class=\"col-md-3\">\n        <div class=\"site-logo\">\n          <a href=\"index.html\">\n            <img\n              src=\"assets/img/autoland-logo.png\"\n              alt=\"Autoland Rent a car - Karpathos Island\"\n            />\n          </a>\n        </div>\n      </div>\n      <div class=\"col-lg-6 col-sm-9\">\n          <div class=\"mainmenu\">\n              <nav>\n                <ul id=\"gauto_navigation\">\n                  <li class=\"active\"><a href=\"index.html\">home</a></li>\n                  <li>\n                    <a href=\"#\">About</a>\n                    <ul>\n                      <li><a href=\"service.html\">Our Rental</a></li>\n                      <li><a href=\"single-service.html\">Our Benefits</a></li>\n                    </ul>\n                  </li>\n                  <li>\n                    <a href=\"#\">cars</a>\n                    <ul>\n                      <li><a href=\"car-listing.html\">Our Fleet</a></li>\n                      <li><a href=\"car-booking.html\">Our Offers</a></li>\n                    </ul>\n                  </li>\n                  <li><a href=\"gallery.html\">Karpathos Island</a></li>\n                  <li><a href=\"contact.html\">contact</a></li>\n                </ul>\n              </nav>\n            </div>\n      <!--   <div class=\"header-promo\">\n          <div class=\"single-header-promo\">\n            <div class=\"header-promo-icon\">\n              <img src=\"assets/img/globe.png\" alt=\"globe\" />\n            </div>\n            <div class=\"header-promo-info\">\n              <h3>Newyork, USA</h3>\n              <p>Melbourne City, Austalia</p>\n            </div>\n          </div>\n          <div class=\"single-header-promo\">\n            <div class=\"header-promo-icon\">\n              <img src=\"assets/img/clock.png\" alt=\"clock\" />\n            </div>\n            <div class=\"header-promo-info\">\n              <h3>Monday to Friday</h3>\n              <p>9:00am - 6:00pm</p>\n            </div>\n          </div>\n        </div> -->\n      </div>\n      <div class=\"col-lg-3\">\n        <div class=\"header-action\">\n          <a href=\"#\"><i class=\"fa fa-phone\"></i> Request a call</a>\n        </div>\n      </div>\n    </div>\n  </div>\n</header>\n<!-- Main Header Area End -->\n\n<!-- Mainmenu Area Start -->\n<section class=\"gauto-mainmenu-area\">\n  <div class=\"container\">\n    <div class=\"row\">\n    <!--  <div class=\"col-lg-9\">\n        <div class=\"mainmenu\">\n          <nav>\n            <ul id=\"gauto_navigation\">\n              <li class=\"active\"><a href=\"index.html\">home</a></li>\n              <li>\n                <a href=\"#\">About</a>\n                <ul>\n                  <li><a href=\"service.html\">Our Rental</a></li>\n                  <li><a href=\"single-service.html\">Our Benefits</a></li>\n                </ul>\n              </li>\n              <li>\n                <a href=\"#\">cars</a>\n                <ul>\n                  <li><a href=\"car-listing.html\">Our Fleet</a></li>\n                  <li><a href=\"car-booking.html\">Our Offers</a></li>\n                </ul>\n              </li>\n              <li><a href=\"gallery.html\">Karpathos Island</a></li>\n              <li><a href=\"contact.html\">contact</a></li>\n            </ul>\n          </nav>\n        </div>\n      </div>\n      <div class=\"col-lg-3 col-sm-12\">\n        <div class=\"main-search-right\">\n\n          <div class=\"gauto-responsive-menu\"></div>\n\n          <div class=\"header-cart-box\">\n            <div class=\"login dropdown\">\n              <button\n                class=\"dropdown-toggle cart-icon\"\n                type=\"button\"\n                id=\"dropdownMenu1\"\n                data-toggle=\"dropdown\"\n                aria-haspopup=\"true\"\n                aria-expanded=\"false\"\n              >\n                <span>2</span>\n              </button>\n              <div\n                class=\"dropdown-menu cart-dropdown\"\n                aria-labelledby=\"dropdownMenu1\"\n              >\n                <ul class=\"product_list\">\n                  <li>\n                    <div class=\"cart-btn-product\">\n                      <a class=\"product-remove\" href=\"#\">\n                        <i class=\"fa fa-times\"></i>\n                      </a>\n                      <div class=\"cart-btn-pro-img\">\n                        <a href=\"#\">\n                          <img src=\"assets/img/cart-1.png\" alt=\"product\" />\n                        </a>\n                      </div>\n                      <div class=\"cart-btn-pro-cont\">\n                        <h4><a href=\"#\">CAR SPOILERS</a></h4>\n                        <p>Quantity 2</p>\n                        <span class=\"price\">\n                          $29.99\n                        </span>\n                      </div>\n                    </div>\n                  </li>\n                  <li>\n                    <div class=\"cart-btn-product\">\n                      <a class=\"product-remove\" href=\"#\">\n                        <i class=\"fa fa-times\"></i>\n                      </a>\n                      <div class=\"cart-btn-pro-img\">\n                        <a href=\"#\">\n                          <img src=\"assets/img/cart-2.jpg\" alt=\"product\" />\n                        </a>\n                      </div>\n                      <div class=\"cart-btn-pro-cont\">\n                        <h4><a href=\"#\">CAR SPOILERS</a></h4>\n                        <p>Quantity 2</p>\n                        <span class=\"price\">\n                          $29.99\n                        </span>\n                      </div>\n                    </div>\n                  </li>\n                </ul>\n                <div class=\"cart-subtotal\">\n                  <p>\n                    Subtotal :\n                    <span class=\"drop-total\">$59.98</span>\n                  </p>\n                </div>\n                <div class=\"cart-btn\">\n                  <a href=\"#\" class=\"cart-btn-1\">View Cart</a>\n                  <a href=\"#\" class=\"cart-btn-2\">Checkout</a>\n                </div>\n              </div>\n            </div>\n          </div>\n\n          <div class=\"search-box\">\n            <form>\n              <input type=\"search\" placeholder=\"Search\" />\n              <button type=\"submit\"><i class=\"fa fa-search\"></i></button>\n            </form>\n          </div>\n\n        </div>\n      </div> -->\n    </div>\n  </div>\n</section>\n<!-- Mainmenu Area End -->\n<!--<nav class=\"navbar navbar-light bg-light\">\n  <a class=\"navbar-brand\" style = \"margin-left : 50px ;margin-right : 15%\" href=\"/\">\n    <img  [class.show]=\"!booleanFromComponentClass\" class=\"step\" (mouseenter) = \"changeImg()\" (mouseleave) =\"changeImg()\" [src]=\"imgSrc\" width = \"15%\" height = \"15%\" alt=\"\">\n    <img  [@visibilityChanged]=\"visiblityState\" (mouseenter) = \"changeImg()\" (mouseleave) =\"resetImg()\"[src]=\"imgSrc\" width = \"15%\" height = \"15%\" alt=\"\">\n  </a>\n    <button *ngIf=\"!auth.isLoggedIn()\" type=\"button\" class=\"btn btn-outline-primary\" routerLink=\"/register\">Register</button>\n    <p *ngIf=\"!auth.isLoggedIn()\">or</p>\n    <button *ngIf=\"!auth.isLoggedIn()\" type=\"button\" class=\"btn btn-outline-primary\" routerLink=\"/login\">Sign in</button>\n  <a *ngIf=\"auth.isLoggedIn()\" routerLink=\"/profile/bookings\" [queryParams]=\"{email:details?.email}\">Hi, {{details?.name}}</a>\n  <button *ngIf=\"auth.isLoggedIn()\" type=\"button\" class=\"btn btn-outline-primary\" (click)=\"auth.logout()\">Log out</button>\n</nav>-->\n"

/***/ }),

/***/ "./src/app/header/header.component.ts":
/*!********************************************!*\
  !*** ./src/app/header/header.component.ts ***!
  \********************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/animations */ "./node_modules/@angular/animations/esm5/animations.js");




var HeaderComponent = /** @class */ (function () {
    function HeaderComponent(auth) {
        this.auth = auth;
        this.imgSrc = "/assets/XXAR_800x400.png";
        this.imgs = ["/assets/XXAR_800x400.png", '/assets/carcool.png'];
        this.i = 0;
        this.visiblityState = 'shown';
    }
    HeaderComponent.prototype.ngOnInit = function () {
        // this.auth.profile().subscribe(user => {
        //   this.details = user;
        // }, (err) => {
        //   console.error(err);
        // });
        //this.resetImg();
    };
    // changeImg(){
    //   this.i = (this.i + 1)%2;
    //   this.imgSrc = this.imgs[this.i];
    // }
    HeaderComponent.prototype.changeImg = function () {
        var _this = this;
        this.i = (this.i + 1) % 2;
        if (this.visiblityState === 'hidden')
            this.visiblityState = 'shown';
        else
            this.visiblityState = 'hidden';
        setTimeout(function () { _this.imgSrc = _this.imgs[_this.i]; _this.visiblityState = 'shown'; }, 1000);
    };
    HeaderComponent.prototype.resetImg = function () {
        this.imgSrc = this.imgs[0];
        this.i = 0;
        this.visiblityState = 'shown';
    };
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/header/header.component.html"),
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["trigger"])('visibilityChanged', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["state"])('shown', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["style"])({ opacity: 1 })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["state"])('hidden', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["style"])({ opacity: 0 })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["transition"])('shown => hidden', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["animate"])('1000ms')),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["transition"])('hidden => shown', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["animate"])('1500ms')),
                ])
            ],
            styles: [__webpack_require__(/*! ./header.component.css */ "./src/app/header/header.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/home/home.component.css":
/*!*****************************************!*\
  !*** ./src/app/home/home.component.css ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".col-md-3 {\n    -webkit-box-flex: 0;\n    flex: 0 0 25%;\n    max-width: 24%;\n    padding-left:0px;\n  }\n.row{\n    margin-left:15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9ob21lLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxtQkFBbUI7SUFFbkIsYUFBYTtJQUNiLGNBQWM7SUFDZCxnQkFBZ0I7RUFDbEI7QUFDRjtJQUNJLGdCQUFnQjtBQUNwQiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbC1tZC0zIHtcbiAgICAtd2Via2l0LWJveC1mbGV4OiAwO1xuICAgIC1tcy1mbGV4OiAwIDAgMjUlO1xuICAgIGZsZXg6IDAgMCAyNSU7XG4gICAgbWF4LXdpZHRoOiAyNCU7XG4gICAgcGFkZGluZy1sZWZ0OjBweDtcbiAgfVxuLnJvd3tcbiAgICBtYXJnaW4tbGVmdDoxNXB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/home/home.component.html":
/*!******************************************!*\
  !*** ./src/app/home/home.component.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\n\n\n\n\n<!-- <app-search #search [dataset]=\"dataset\" (searchCar)=\"runParent($event)\"></app-search>\n\n  <div class=\"row\">\n  <div class = \"col-md-1\"></div>\n    <app-filter #filter (carFilter)=\"getFilter($event)\" class = \"col-md-3\"></app-filter>\n    <app-carlists #carlists [pickPlace]=\"pickplace\" class = \"col-md-8\"></app-carlists>\n  <div class = \"col-md-1\"></div>\n</div> -->\n\n<app-footer></app-footer>\n"

/***/ }),

/***/ "./src/app/home/home.component.ts":
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/*! exports provided: HomeComponent, NewFilterOptions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewFilterOptions", function() { return NewFilterOptions; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/product.service */ "./src/app/services/product.service.ts");
/* harmony import */ var _services_data_bus_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/data-bus.service */ "./src/app/services/data-bus.service.ts");





var HomeComponent = /** @class */ (function () {
    function HomeComponent(dataBus, routerIonfo, carService) {
        this.dataBus = dataBus;
        this.routerIonfo = routerIonfo;
        this.carService = carService;
    }
    HomeComponent.prototype.ngOnInit = function () {
        console.log('--> nginit');
        this.picktime = this.routerIonfo.snapshot.queryParams['pickup_time'];
        this.droptime = this.routerIonfo.snapshot.queryParams['dropoff_time'];
        this.pickplace = this.routerIonfo.snapshot.queryParams['pickup_place'];
        this.dropplace = this.routerIonfo.snapshot.queryParams['dropoff_place'];
        this.pickdate = this.routerIonfo.snapshot.queryParams['pickup_date'];
        this.dropdate = this.routerIonfo.snapshot.queryParams['dropoff_date'];
        this.dataset = [this.pickplace, this.dropplace, this.pickdate, this.picktime, this.dropdate, this.droptime];
        // this.searchCarlists();
        // console.log(this.dataset);
        // console.log(this.pickplace);
        this.dataBus.setSearchCondi(this.dataset);
        console.log(this.pickplace);
        if ((typeof this.pickplace === 'undefined') || (this.pickplace === '')) {
            // this.run(this.pickplace);
            console.log('--> nginit Run All');
            this.runAll();
        }
        else {
            console.log('--> nginit Run Place');
            this.run(this.pickplace);
        }
    };
    HomeComponent.prototype.ngAfterViewInit = function () {
        console.log('---> filter:ngAfterViewInit');
        this.picktime = this.routerIonfo.snapshot.queryParams['pickup_time'];
        this.droptime = this.routerIonfo.snapshot.queryParams['dropoff_time'];
        this.pickplace = this.routerIonfo.snapshot.queryParams['pickup_place'];
        this.dropplace = this.routerIonfo.snapshot.queryParams['dropoff_place'];
        this.pickdate = this.routerIonfo.snapshot.queryParams['pickup_date'];
        this.dropdate = this.routerIonfo.snapshot.queryParams['dropoff_date'];
        this.dataset = [this.pickplace, this.dropplace, this.pickdate, this.picktime, this.dropdate, this.droptime];
        // console.log(this.pickplace);
        this.dataBus.setSearchCondi(this.dataset);
        // this.searchCarlists();
        // console.log(this.dataset);
        console.log(this.pickplace);
        if ((typeof this.pickplace === 'undefined') || (this.pickplace == '')) {
            // this.run(this.pickplace);
            this.runAll();
        }
        else {
            this.run(this.pickplace);
        }
    };
    HomeComponent.prototype.run = function (pickplace) {
        console.log('--> Run Location.');
        this.footer.footerRunLoc(pickplace);
    };
    HomeComponent.prototype.runAll = function () {
        console.log('--> Run all');
        this.footer.footerRunAll();
    };
    HomeComponent.prototype.runFilter = function (newoptions) {
        this.footer.footerRunFilter(newoptions);
    };
    HomeComponent.prototype.runParent = function (msg) {
        this.pickplace = msg[0];
        this.dropplace = msg[1];
        this.pickdate = msg[2];
        this.picktime = msg[3];
        this.dropdate = msg[4];
        this.droptime = msg[5];
        this.dataset = [this.pickplace, this.dropplace, this.pickdate, this.picktime, this.dropdate, this.droptime];
        this.dataBus.setSearchCondi(this.dataset);
        console.log(this.pickplace);
        this.runFilter(new NewFilterOptions(this.pickplace, this.priceMax, this.priceMin, this.carTypes, this.passengerNum, this.ifAdult));
    };
    HomeComponent.prototype.getFilter = function (options) {
        console.log('---home get filter value from filter--');
        console.log(options);
        this.carTypes = options.carType;
        this.passengerNum = options.pasgerNum_max;
        this.priceMax = options.price_max;
        this.priceMin = options.price_min;
        this.ifAdult = options.isAdult;
        if ((typeof this.carTypes[0] === 'undefined')) {
            this.carTypes = ['NoCarTypes'];
        }
        if ((typeof this.pickplace === 'undefined')) {
            this.pickplace = 'AllTypes';
        }
        var newOptions = new NewFilterOptions(this.pickplace, this.priceMax, this.priceMin, this.carTypes, this.passengerNum, this.ifAdult);
        // if((typeof this.pickplace === 'undefined')||(this.pickplace=='')){
        //   //this.run(this.pickplace);
        //   this.runAll();
        // }
        // else{
        //   this.runFilter(newOptions);
        //}
        this.runFilter(newOptions);
        console.log(newOptions);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('carlists'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], HomeComponent.prototype, "footer", void 0);
    HomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.component.html */ "./src/app/home/home.component.html"),
            styles: [__webpack_require__(/*! ./home.component.css */ "./src/app/home/home.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_data_bus_service__WEBPACK_IMPORTED_MODULE_4__["DataBusService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_product_service__WEBPACK_IMPORTED_MODULE_3__["ProductService"]])
    ], HomeComponent);
    return HomeComponent;
}());

var NewFilterOptions = /** @class */ (function () {
    function NewFilterOptions(pickLocation, priceMax, priceMin, carType, passengerNumMax, ifAdult) {
        this.pickLocation = pickLocation;
        this.priceMax = priceMax;
        this.priceMin = priceMin;
        this.carType = carType;
        this.passengerNumMax = passengerNumMax;
        this.ifAdult = ifAdult;
    }
    return NewFilterOptions;
}());



/***/ }),

/***/ "./src/app/login/login.component.css":
/*!*******************************************!*\
  !*** ./src/app/login/login.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".form-signin {\n  max-width: 330px;\n  padding: 15px;\n  margin: 0 auto;\n}\n.form-signin .form-signin-heading,\n.form-signin .checkbox {\n  margin-bottom: 10px;\n}\n.form-signin .checkbox {\n  font-weight: normal;\n}\n.form-signin .form-control {\n  position: relative;\n  height: auto;\n  box-sizing: border-box;\n  padding: 10px;\n  font-size: 16px;\n}\n.form-signin .form-control:focus {\n  z-index: 2;\n}\n.form-signin input[type=\"email\"] {\n  margin-bottom: -1px;\n  border-bottom-right-radius: 0;\n  border-bottom-left-radius: 0;\n}\n.form-signin input[type=\"password\"] {\n  margin-bottom: 10px;\n  border-top-left-radius: 0;\n  border-top-right-radius: 0;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFnQjtFQUNoQixhQUFhO0VBQ2IsY0FBYztBQUNoQjtBQUNBOztFQUVFLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0UsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsWUFBWTtFQUVaLHNCQUFzQjtFQUN0QixhQUFhO0VBQ2IsZUFBZTtBQUNqQjtBQUNBO0VBQ0UsVUFBVTtBQUNaO0FBQ0E7RUFDRSxtQkFBbUI7RUFDbkIsNkJBQTZCO0VBQzdCLDRCQUE0QjtBQUM5QjtBQUNBO0VBQ0UsbUJBQW1CO0VBQ25CLHlCQUF5QjtFQUN6QiwwQkFBMEI7QUFDNUIiLCJmaWxlIjoic3JjL2FwcC9sb2dpbi9sb2dpbi5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZvcm0tc2lnbmluIHtcbiAgbWF4LXdpZHRoOiAzMzBweDtcbiAgcGFkZGluZzogMTVweDtcbiAgbWFyZ2luOiAwIGF1dG87XG59XG4uZm9ybS1zaWduaW4gLmZvcm0tc2lnbmluLWhlYWRpbmcsXG4uZm9ybS1zaWduaW4gLmNoZWNrYm94IHtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cbi5mb3JtLXNpZ25pbiAuY2hlY2tib3gge1xuICBmb250LXdlaWdodDogbm9ybWFsO1xufVxuLmZvcm0tc2lnbmluIC5mb3JtLWNvbnRyb2wge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGhlaWdodDogYXV0bztcbiAgLXdlYmtpdC1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBwYWRkaW5nOiAxMHB4O1xuICBmb250LXNpemU6IDE2cHg7XG59XG4uZm9ybS1zaWduaW4gLmZvcm0tY29udHJvbDpmb2N1cyB7XG4gIHotaW5kZXg6IDI7XG59XG4uZm9ybS1zaWduaW4gaW5wdXRbdHlwZT1cImVtYWlsXCJdIHtcbiAgbWFyZ2luLWJvdHRvbTogLTFweDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDA7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDA7XG59XG4uZm9ybS1zaWduaW4gaW5wdXRbdHlwZT1cInBhc3N3b3JkXCJdIHtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMDtcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDA7XG59XG4iXX0= */"

/***/ }),

/***/ "./src/app/login/login.component.html":
/*!********************************************!*\
  !*** ./src/app/login/login.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--<div class=\"container\">-->\n  <!--<div class=\"row\">-->\n    <!--<div class=\"col-md-4 col-md-offset-4\">-->\n      <!--<h2>Login</h2>-->\n      <!--<form name=\"form\" (ngSubmit)=\"login()\" #f=\"ngForm\" novalidate>-->\n        <!--<div class=\"form-group\">-->\n          <!--<label>Email</label>-->\n          <!--<input type=\"text\" class=\"form-control\" name=\"emailaddress\" [(ngModel)]=\"email\" #emailaddress=\"ngModel\" required />-->\n        <!--</div>-->\n        <!--<div class=\"form-group\">-->\n          <!--<label>Username</label>-->\n          <!--<input type=\"text\" class=\"form-control\" name=\"name\" [(ngModel)]=\"username\" #name=\"ngModel\" required />-->\n        <!--</div>-->\n        <!--<div class=\"form-group\">-->\n          <!--<label>Password</label>-->\n          <!--<input type=\"password\" class=\"form-control\" name=\"pwd\" [(ngModel)]=\"password\" #pwd=\"ngModel\" required />-->\n        <!--</div>-->\n        <!--<div class=\"form-group\">-->\n          <!--<button class=\"btn btn-primary\">Login</button>-->\n        <!--</div>-->\n      <!--</form>-->\n    <!--</div>-->\n  <!--</div>-->\n<!--</div>-->\n<div class=\"container\">\n\n  <div class=\"row\">\n\n    <div class=\"col-md-6\">\n\n      <h1 class=\"form-signin-heading\">Sign in</h1>\n      <p class=\"lead\">Not a member? Please <a routerLink=\"/register\">register</a> instead.</p>\n\n      <form (submit)=\"login()\">\n        <div class=\"form-group\">\n          <label for=\"email\">Email address</label>\n          <input type=\"email\" class=\"form-control\" name=\"email\" placeholder=\"Enter email\" [(ngModel)]=\"credentials.email\">\n        </div>\n        <div class=\"form-group\">\n          <label for=\"password\">Password</label>\n          <input type=\"password\" class=\"form-control\" name=\"password\" placeholder=\"Password\" [(ngModel)]=\"credentials.password\">\n        </div>\n        <button type=\"submit\" class=\"btn btn-primary\">Sign in!</button>\n      </form>\n\n    </div>\n  </div>\n\n</div>\n"

/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");




var LoginComponent = /** @class */ (function () {
    function LoginComponent(auth, router) {
        this.auth = auth;
        this.router = router;
        this.credentials = {
            email: '',
            password: ''
        };
    }
    LoginComponent.prototype.login = function () {
        var _this = this;
        this.auth.login(this.credentials).subscribe(function () {
            if (_this.auth.Ifadmin()) {
                _this.router.navigateByUrl('/home');
            }
            else
                _this.router.navigateByUrl('/');
        }, function (err) {
            console.error(err);
        });
    };
    LoginComponent.prototype.ngOnInit = function () {
        // reset login status
        //this.authenticationService.logout();
        // get return url from route parameters or default to '/'
        //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    };
    LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/login/login.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/pagination/pagination.component.css":
/*!*****************************************************!*\
  !*** ./src/app/pagination/pagination.component.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".numbers {\n  /*display: block;*/\n  text-align: center;\n  -webkit-box-flex: 1;\n          flex: 1;\n}\n\n.active{\n  background-color: #00B7FF;\n}\n\n.btn-secondary{\n  color:blue;\n  background-color: white;\n}\n\n.disabled{\n  color:grey;\n  /*background-color: #BABABA;*/\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnaW5hdGlvbi9wYWdpbmF0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBa0I7RUFDbEIsa0JBQWtCO0VBQ2xCLG1CQUFPO1VBQVAsT0FBTztBQUNUOztBQUVBO0VBQ0UseUJBQXlCO0FBQzNCOztBQUVBO0VBQ0UsVUFBVTtFQUNWLHVCQUF1QjtBQUN6Qjs7QUFHQTtFQUNFLFVBQVU7RUFDViw2QkFBNkI7QUFDL0IiLCJmaWxlIjoic3JjL2FwcC9wYWdpbmF0aW9uL3BhZ2luYXRpb24uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5udW1iZXJzIHtcbiAgLypkaXNwbGF5OiBibG9jazsqL1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZsZXg6IDE7XG59XG5cbi5hY3RpdmV7XG4gIGJhY2tncm91bmQtY29sb3I6ICMwMEI3RkY7XG59XG5cbi5idG4tc2Vjb25kYXJ5e1xuICBjb2xvcjpibHVlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbn1cblxuXG4uZGlzYWJsZWR7XG4gIGNvbG9yOmdyZXk7XG4gIC8qYmFja2dyb3VuZC1jb2xvcjogI0JBQkFCQTsqL1xufVxuIl19 */"

/***/ }),

/***/ "./src/app/pagination/pagination.component.html":
/*!******************************************************!*\
  !*** ./src/app/pagination/pagination.component.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<div class=\"pagination\" *ngIf=\"count > 0\">\n\n  <div  class=\"numbers btn-group btn-group-toggle \" style=\"padding-left: 280px\">\n    <button class=\"btn btn-secondary\" (click)=\"onPrev()\" [disabled]=\"page === 1 || loading\" [ngClass]=\"{ 'disabled': page === 1 || loading }\">&lt; Previous</button>\n\n    <button class=\"btn btn-secondary\"\n      *ngFor=\"let pageNum of getPages()\"\n      (click)=\"onPage(pageNum)\"\n      [ngClass]=\"{'active': pageNum === page, 'disabled': loading}\">{{ pageNum }}</button>\n\n    <button class=\"btn btn-secondary\" (click)=\"onNext(true)\" [disabled]=\"lastPage() || loading\" [ngClass]=\"{ 'disabled': lastPage() || loading }\">Next &gt;</button>\n  </div>\n  <br>\n  <div class=\"description\" style=\"padding-top: 5px\">\n    <span class=\"page-counts\">{{ getMin() }} - {{ getMax() }} of {{ count }}</span>\n    <!--<span class=\"page-totals\">in {{ totalPages() }} pages</span>-->\n  </div>\n</div>\n"

/***/ }),

/***/ "./src/app/pagination/pagination.component.ts":
/*!****************************************************!*\
  !*** ./src/app/pagination/pagination.component.ts ***!
  \****************************************************/
/*! exports provided: PaginationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaginationComponent", function() { return PaginationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");


var PaginationComponent = /** @class */ (function () {
    function PaginationComponent() {
        this.goPrev = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.goNext = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.goPage = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    PaginationComponent.prototype.ngOnInit = function () {
    };
    PaginationComponent.prototype.getMin = function () {
        return ((this.perPage * this.page) - this.perPage) + 1;
    };
    PaginationComponent.prototype.getMax = function () {
        var max = this.perPage * this.page;
        if (max > this.count) {
            max = this.count;
        }
        return max;
    };
    PaginationComponent.prototype.onPage = function (n) {
        this.goPage.emit(n);
    };
    PaginationComponent.prototype.onPrev = function () {
        this.goPrev.emit(true);
    };
    PaginationComponent.prototype.onNext = function (next) {
        this.goNext.emit(next);
    };
    PaginationComponent.prototype.totalPages = function () {
        return Math.ceil(this.count / this.perPage) || 0;
    };
    PaginationComponent.prototype.lastPage = function () {
        // console.log(this.perPage);
        // console.log(this.page);
        return this.perPage * this.page >= this.count;
    };
    PaginationComponent.prototype.getPages = function () {
        var c = Math.ceil(this.count / this.perPage);
        var p = this.page || 1;
        var pagesToShow = this.pagesToShow || 9;
        var pages = [];
        pages.push(p);
        var times = pagesToShow - 1;
        for (var i = 0; i < times; i++) {
            if (pages.length < pagesToShow) {
                if (Math.min.apply(null, pages) > 1) {
                    pages.push(Math.min.apply(null, pages) - 1);
                }
            }
            if (pages.length < pagesToShow) {
                if (Math.max.apply(null, pages) < c) {
                    pages.push(Math.max.apply(null, pages) + 1);
                }
            }
        }
        pages.sort(function (a, b) { return a - b; });
        return pages;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], PaginationComponent.prototype, "page", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], PaginationComponent.prototype, "count", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], PaginationComponent.prototype, "perPage", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], PaginationComponent.prototype, "pagesToShow", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], PaginationComponent.prototype, "loading", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], PaginationComponent.prototype, "goPrev", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], PaginationComponent.prototype, "goNext", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], PaginationComponent.prototype, "goPage", void 0);
    PaginationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-pagination',
            template: __webpack_require__(/*! ./pagination.component.html */ "./src/app/pagination/pagination.component.html"),
            styles: [__webpack_require__(/*! ./pagination.component.css */ "./src/app/pagination/pagination.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], PaginationComponent);
    return PaginationComponent;
}());



/***/ }),

/***/ "./src/app/profile/profile.component.css":
/*!***********************************************!*\
  !*** ./src/app/profile/profile.component.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#ex1Slider .slider-selection {\n  background: #BABABA;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZmlsZS9wcm9maWxlLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxtQkFBbUI7QUFDckIiLCJmaWxlIjoic3JjL2FwcC9wcm9maWxlL3Byb2ZpbGUuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIiNleDFTbGlkZXIgLnNsaWRlci1zZWxlY3Rpb24ge1xuICBiYWNrZ3JvdW5kOiAjQkFCQUJBO1xufVxuIl19 */"

/***/ }),

/***/ "./src/app/profile/profile.component.html":
/*!************************************************!*\
  !*** ./src/app/profile/profile.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\n<!--<div class=\"container\">-->\n  <!--<div class=\"row\">-->\n    <!--<div class=\"col-md-6\">-->\n      <!--<h1 class=\"form-signin-heading\">Your profile</h1>-->\n      <!--<div class=\"form-horizontal\">-->\n        <!--<div class=\"form-group\">-->\n          <!--<label class=\"col-sm-3 control-label\">Full name</label>-->\n          <!--<p class=\"form-control-static\">{{ details?.name }}</p>-->\n        <!--</div>-->\n        <!--<div class=\"form-group\">-->\n          <!--<label class=\"col-sm-3 control-label\">Email</label>-->\n          <!--<p class=\"form-control-static\">{{ details?.email }}</p>-->\n        <!--</div>-->\n      <!--</div>-->\n    <!--</div>-->\n\n  <!--</div>-->\n<!--</div>-->\n<div class=\"container\">\n  <div class=\"row\" style=\"margin-top: 20px\">\n    <div class=\"col-md-3\">\n      <ul class=\"list-group\">\n        <li class=\"list-group-item active\" (click)=\"onclick($event)\" routerLink=\"/profile/bookings\" [queryParams]=\"{email:details?.email}\">My Booking</li>\n        <li class=\"list-group-item\" (click)=\"onclick($event)\" routerLink=\"/profile/account\" [queryParams]=\"{email:details?.email}\">Account Details</li>\n        <li class=\"list-group-item\" (click)=\"onclick($event)\" routerLink=\"/profile/favoritelist\" [queryParams]=\"{email:details?.email}\">Favorite List</li>\n      </ul>\n    </div>\n    <div class=\"col-md-9\">\n      <router-outlet></router-outlet>\n    </div>\n  </div>\n</div>\n<app-footer></app-footer>\n\n"

/***/ }),

/***/ "./src/app/profile/profile.component.ts":
/*!**********************************************!*\
  !*** ./src/app/profile/profile.component.ts ***!
  \**********************************************/
/*! exports provided: ProfileComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfileComponent", function() { return ProfileComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_3__);




var ProfileComponent = /** @class */ (function () {
    function ProfileComponent(auth) {
        var _this = this;
        this.auth = auth;
        this.auth.profile().subscribe(function (user) {
            _this.details = user;
        }, function (err) {
            console.error(err);
        });
    }
    ProfileComponent.prototype.ngOnInit = function () {
        //console.log(this.auth.Ifadmin());
    };
    ProfileComponent.prototype.onclick = function (event) {
        jquery__WEBPACK_IMPORTED_MODULE_3__('li').removeClass("active");
        event.target.className = 'list-group-item active';
        console.log(event.target);
    };
    ProfileComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-profile',
            template: __webpack_require__(/*! ./profile.component.html */ "./src/app/profile/profile.component.html"),
            styles: [__webpack_require__(/*! ./profile.component.css */ "./src/app/profile/profile.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]])
    ], ProfileComponent);
    return ProfileComponent;
}());



/***/ }),

/***/ "./src/app/register/register.component.css":
/*!*************************************************!*\
  !*** ./src/app/register/register.component.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlZ2lzdGVyL3JlZ2lzdGVyLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/register/register.component.html":
/*!**************************************************!*\
  !*** ./src/app/register/register.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n\n  <div class=\"row\">\n    <div class=\"col-md-6\">\n      <h1>Register</h1>\n      <p class=\"lead\">Already a member? Please <a routerLink=\"/login\">log in</a> instead.</p>\n      <form (submit)=\"register()\">\n        <div class=\"form-group\">\n          <label for=\"name\">Full name</label>\n          <input type=\"text\" class=\"form-control\" name=\"name\" placeholder=\"Enter your name\" [(ngModel)]=\"credentials.name\">\n        </div>\n        <div class=\"form-group\">\n          <label for=\"email\">Email address</label>\n          <input type=\"email\" class=\"form-control\" name=\"email\" placeholder=\"Enter email\" [(ngModel)]=\"credentials.email\">\n        </div>\n        <div class=\"form-group\">\n          <label for=\"password\">Password</label>\n          <input type=\"password\" class=\"form-control\" name=\"password\" placeholder=\"Password\" [(ngModel)]=\"credentials.password\">\n        </div>\n        <button type=\"submit\" class=\"btn btn-default\">Register!</button>\n      </form>\n    </div>\n  </div>\n\n</div>\n"

/***/ }),

/***/ "./src/app/register/register.component.ts":
/*!************************************************!*\
  !*** ./src/app/register/register.component.ts ***!
  \************************************************/
/*! exports provided: RegisterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterComponent", function() { return RegisterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");




var RegisterComponent = /** @class */ (function () {
    function RegisterComponent(auth, router) {
        this.auth = auth;
        this.router = router;
        this.credentials = {
            email: '',
            name: '',
            password: ''
        };
    }
    RegisterComponent.prototype.register = function () {
        var _this = this;
        this.auth.register(this.credentials).subscribe(function () {
            _this.router.navigateByUrl('/profile');
        }, function (err) {
            console.error(err);
        });
    };
    RegisterComponent.prototype.ngOnInit = function () {
    };
    RegisterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-register',
            template: __webpack_require__(/*! ./register.component.html */ "./src/app/register/register.component.html"),
            styles: [__webpack_require__(/*! ./register.component.css */ "./src/app/register/register.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], RegisterComponent);
    return RegisterComponent;
}());



/***/ }),

/***/ "./src/app/search-welcome/search-welcome.component.css":
/*!*************************************************************!*\
  !*** ./src/app/search-welcome/search-welcome.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "input{\n    margin-bottom: 8px;  \n}\n\n.card{\n    opacity:0.8;\n}\n\n.datebar {\n    -webkit-box-flex: 0;\n    flex: 0 0 50%;\n    max-width: 42.5%;\n    margin-left:16px;\n  }\n\n.timebar{\n    margin-left:20px;\n    width :43.6%;\n  }\n\n.tmbtn-width{\n      width:240%;\n  }\n\n.scbtn-width{\n      width:100%;\n  }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VhcmNoLXdlbGNvbWUvc2VhcmNoLXdlbGNvbWUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLFdBQVc7QUFDZjs7QUFFQTtJQUNJLG1CQUFtQjtJQUVuQixhQUFhO0lBQ2IsZ0JBQWdCO0lBQ2hCLGdCQUFnQjtFQUNsQjs7QUFFQTtJQUNFLGdCQUFnQjtJQUNoQixZQUFZO0VBQ2Q7O0FBRUE7TUFDSSxVQUFVO0VBQ2Q7O0FBRUE7TUFDSSxVQUFVO0VBQ2QiLCJmaWxlIjoic3JjL2FwcC9zZWFyY2gtd2VsY29tZS9zZWFyY2gtd2VsY29tZS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW5wdXR7XG4gICAgbWFyZ2luLWJvdHRvbTogOHB4OyAgXG59XG5cbi5jYXJke1xuICAgIG9wYWNpdHk6MC44O1xufVxuXG4uZGF0ZWJhciB7XG4gICAgLXdlYmtpdC1ib3gtZmxleDogMDtcbiAgICAtbXMtZmxleDogMCAwIDUwJTtcbiAgICBmbGV4OiAwIDAgNTAlO1xuICAgIG1heC13aWR0aDogNDIuNSU7XG4gICAgbWFyZ2luLWxlZnQ6MTZweDtcbiAgfVxuICBcbiAgLnRpbWViYXJ7XG4gICAgbWFyZ2luLWxlZnQ6MjBweDtcbiAgICB3aWR0aCA6NDMuNiU7XG4gIH1cblxuICAudG1idG4td2lkdGh7XG4gICAgICB3aWR0aDoyNDAlO1xuICB9XG5cbiAgLnNjYnRuLXdpZHRoe1xuICAgICAgd2lkdGg6MTAwJTtcbiAgfVxuIl19 */"

/***/ }),

/***/ "./src/app/search-welcome/search-welcome.component.html":
/*!**************************************************************!*\
  !*** ./src/app/search-welcome/search-welcome.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form #search=\"ngForm\" action=\"\">\n<div class=\"card\">\n  <div class=\"card-body\">\n    <h5 class=\"card-title\">Search for a car rental</h5>\n    <input [(ngModel)]= \"slt_pickplace\" name=\"pickloc\" type=\"text\" class=\"form-control\" placeholder=\"Pick up location\" required>\n    <input [(ngModel)]= \"slt_dropplace\" name=\"droploc\" type=\"text\" class=\"form-control\" placeholder=\"Drop off location\" required>\n    <div class = \"row\">\n      <input [(ngModel)]= \"slt_pickdate\" name=\"pickdate\" class = \"datebar form-control form-control-sm\" type=\"date\" required/>\n      <select [(ngModel)]=\"slt_picktime\" name=\"picktime\" class = \"form-control form-control-sm timebar\" style = \"height:33px\" required>\n        <option *ngFor=\"let pickuptime of times\" [value]=\"pickuptime.viewValue\">\n          {{ pickuptime.viewValue }}\n        </option>\n      </select>\n    </div>\n\n    <div class = \"row\">\n      <input [(ngModel)]= \"slt_dropdate\" name=\"dropdate\" class = \"datebar form-control form-control-sm\" type=\"date\" required/>\n      <select [(ngModel)]=\"slt_droptime\" name=\"droptime\" class = \"form-control form-control-sm timebar\" style = \"height:33px\" required>\n        <option *ngFor=\"let dropofftime of times\" [value]=\"dropofftime.viewValue\">\n          {{ dropofftime.viewValue }}\n        </option>\n      </select>\n    </div>\n    <button type=\"button\" [disabled]=\"!search.form.valid\" class=\"btn btn-warning scbtn-width\" routerLink=\"/home\" [queryParams]=\"{pickup_place:slt_pickplace,dropoff_place:slt_dropplace,pickup_date:slt_pickdate,pickup_time:slt_picktime,dropoff_date:slt_dropdate,dropoff_time:slt_droptime}\">SEARCH NOW</button>\n    </div>\n</div>\n</form>\n"

/***/ }),

/***/ "./src/app/search-welcome/search-welcome.component.ts":
/*!************************************************************!*\
  !*** ./src/app/search-welcome/search-welcome.component.ts ***!
  \************************************************************/
/*! exports provided: SearchWelcomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchWelcomeComponent", function() { return SearchWelcomeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");


var SearchWelcomeComponent = /** @class */ (function () {
    function SearchWelcomeComponent() {
        this.times = [
            { value: 'time1', viewValue: '00:00' },
            { value: 'time2', viewValue: '01:00' },
            { value: 'time3', viewValue: '02:00' },
            { value: 'time4', viewValue: '03:00' },
            { value: 'time5', viewValue: '04:00' },
            { value: 'time6', viewValue: '05:00' },
            { value: 'time7', viewValue: '06:00' },
            { value: 'time8', viewValue: '07:00' },
            { value: 'time9', viewValue: '08:00' },
            { value: 'time10', viewValue: '09:00' },
            { value: 'time11', viewValue: '10:00' },
            { value: 'time12', viewValue: '11:00' },
            { value: 'time13', viewValue: '12:00' },
            { value: 'time14', viewValue: '13:00' },
            { value: 'time15', viewValue: '14:00' },
            { value: 'time16', viewValue: '15:00' },
            { value: 'time17', viewValue: '16:00' },
            { value: 'time18', viewValue: '17:00' },
            { value: 'time19', viewValue: '18:00' },
            { value: 'time20', viewValue: '19:00' },
            { value: 'time21', viewValue: '20:00' },
            { value: 'time22', viewValue: '21:00' },
            { value: 'time23', viewValue: '22:00' },
            { value: 'time24', viewValue: '23:00' }
        ];
    }
    SearchWelcomeComponent.prototype.ngOnInit = function () {
        this.slt_droptime = this.times[0].viewValue;
        this.slt_picktime = this.times[0].viewValue;
        this.slt_pickplace;
        this.slt_dropplace;
        this.slt_pickpdate;
        this.slt_droppdate;
    };
    SearchWelcomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-search-welcome',
            template: __webpack_require__(/*! ./search-welcome.component.html */ "./src/app/search-welcome/search-welcome.component.html"),
            styles: [__webpack_require__(/*! ./search-welcome.component.css */ "./src/app/search-welcome/search-welcome.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SearchWelcomeComponent);
    return SearchWelcomeComponent;
}());



/***/ }),

/***/ "./src/app/search/search.component.css":
/*!*********************************************!*\
  !*** ./src/app/search/search.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "p{\n    color: dimgrey;\n    padding-left:1px;\n    padding-right:1px;\n    margin-bottom:0px;\n    padding-top: 7px;\n}\na{\n    padding-left:6px;\n    padding-right:5px;\n}\nhr{\n    margin-top:0px; \n    margin-bottom:0px;\n}\n.division {\n    -webkit-box-flex: 0;\n    flex: 0 0 12.3%;\n    max-width: 12.3%;\n    margin-left:8px;\n    margin-right:8px;\n  }\n.place {\n    -webkit-box-flex: 0;\n    flex: 0 0 15%;\n    max-width: 15%;\n    margin-left:8px;\n    margin-right:8px;\n  }\n.scbtn-width{\n    width:100%;\n}\n.search {\n    -webkit-box-flex: 0;\n    flex: 0 0 10%;\n    max-width: 10%;\n    margin-left:10px;\n    margin-right:8px;\n  }\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VhcmNoL3NlYXJjaC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksY0FBYztJQUNkLGdCQUFnQjtJQUNoQixpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLGdCQUFnQjtBQUNwQjtBQUNBO0lBQ0ksZ0JBQWdCO0lBQ2hCLGlCQUFpQjtBQUNyQjtBQUNBO0lBQ0ksY0FBYztJQUNkLGlCQUFpQjtBQUNyQjtBQUVBO0lBQ0ksbUJBQW1CO0lBRW5CLGVBQWU7SUFDZixnQkFBZ0I7SUFDaEIsZUFBZTtJQUNmLGdCQUFnQjtFQUNsQjtBQUNGO0lBQ0ksbUJBQW1CO0lBRW5CLGFBQWE7SUFDYixjQUFjO0lBQ2QsZUFBZTtJQUNmLGdCQUFnQjtFQUNsQjtBQUNBO0lBQ0UsVUFBVTtBQUNkO0FBRUE7SUFDSSxtQkFBbUI7SUFFbkIsYUFBYTtJQUNiLGNBQWM7SUFDZCxnQkFBZ0I7SUFDaEIsZ0JBQWdCO0VBQ2xCIiwiZmlsZSI6InNyYy9hcHAvc2VhcmNoL3NlYXJjaC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsicHtcbiAgICBjb2xvcjogZGltZ3JleTtcbiAgICBwYWRkaW5nLWxlZnQ6MXB4O1xuICAgIHBhZGRpbmctcmlnaHQ6MXB4O1xuICAgIG1hcmdpbi1ib3R0b206MHB4O1xuICAgIHBhZGRpbmctdG9wOiA3cHg7XG59XG5he1xuICAgIHBhZGRpbmctbGVmdDo2cHg7XG4gICAgcGFkZGluZy1yaWdodDo1cHg7XG59XG5ocntcbiAgICBtYXJnaW4tdG9wOjBweDsgXG4gICAgbWFyZ2luLWJvdHRvbTowcHg7XG59XG5cbi5kaXZpc2lvbiB7XG4gICAgLXdlYmtpdC1ib3gtZmxleDogMDtcbiAgICAtbXMtZmxleDogMCAwIDEyLjMlO1xuICAgIGZsZXg6IDAgMCAxMi4zJTtcbiAgICBtYXgtd2lkdGg6IDEyLjMlO1xuICAgIG1hcmdpbi1sZWZ0OjhweDtcbiAgICBtYXJnaW4tcmlnaHQ6OHB4O1xuICB9XG4ucGxhY2Uge1xuICAgIC13ZWJraXQtYm94LWZsZXg6IDA7XG4gICAgLW1zLWZsZXg6IDAgMCAxNSU7XG4gICAgZmxleDogMCAwIDE1JTtcbiAgICBtYXgtd2lkdGg6IDE1JTtcbiAgICBtYXJnaW4tbGVmdDo4cHg7XG4gICAgbWFyZ2luLXJpZ2h0OjhweDtcbiAgfVxuICAuc2NidG4td2lkdGh7XG4gICAgd2lkdGg6MTAwJTtcbn1cblxuLnNlYXJjaCB7XG4gICAgLXdlYmtpdC1ib3gtZmxleDogMDtcbiAgICAtbXMtZmxleDogMCAwIDEwJTtcbiAgICBmbGV4OiAwIDAgMTAlO1xuICAgIG1heC13aWR0aDogMTAlO1xuICAgIG1hcmdpbi1sZWZ0OjEwcHg7XG4gICAgbWFyZ2luLXJpZ2h0OjhweDtcbiAgfSJdfQ== */"

/***/ }),

/***/ "./src/app/search/search.component.html":
/*!**********************************************!*\
  !*** ./src/app/search/search.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<form #search=\"ngForm\" action=\"\">\n  <hr>\n  <nav class=\"navbar navbar-light bg-light\">\n    <div class=\"row\" style = \"width:100%;margin-left:5px\">\n      <input [(ngModel)]=\"pLocation\" name=\"pickloc\" type=\"text\" class=\"place form-control\" style=\"width:180px\" placeholder=\"Pick up location\" required>\n      <p>→</p >\n      <input [(ngModel)]=\"dLocation\"  name=\"droploc\" type=\"text\" class=\"place form-control\" placeholder=\"Drop off location\" required>\n      <input [(ngModel)]=\"pDate\"  name=\"pickdate\" type=\"date\" class = \"division form-control form-control-sm\" required/>\n      <select [(ngModel)]=\"pTime\" name=\"pricktime\" class = \"division form-control form-control-sm\" style = \"height:38px\" required>\n        <option *ngFor=\"let pickuptime of times\" [value]=\"pickuptime.viewValue\">\n          {{pickuptime.viewValue}}\n        </option>\n      </select>\n      <input [(ngModel)]=\"dDate\"  name=\"dropdate\" type=\"date\" class=\"division form-control form-control-sm\" required/>\n      <select [(ngModel)]=\"dTime\"  name=\"droptime\" class = \"division form-control form-control-sm\" style = \"height:38px\" required>\n        <option *ngFor=\"let dropofftime of times\" [value]=\"dropofftime.viewValue\">\n          {{ dropofftime.viewValue }}\n        </option>\n      </select>\n      <button type=\"button\" [disabled]=\"!search.form.valid\" (click)=\"fireEvent()\" class=\"search btn btn-warning scbtn-width\">SEARCH</button>\n    </div>\n\n  </nav>\n</form>\n"

/***/ }),

/***/ "./src/app/search/search.component.ts":
/*!********************************************!*\
  !*** ./src/app/search/search.component.ts ***!
  \********************************************/
/*! exports provided: SearchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchComponent", function() { return SearchComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");



var SearchComponent = /** @class */ (function () {
    function SearchComponent(route) {
        this.route = route;
        this.searchCar = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.times = [
            { value: 'time1', viewValue: '00:00' },
            { value: 'time2', viewValue: '01:00' },
            { value: 'time3', viewValue: '02:00' },
            { value: 'time4', viewValue: '03:00' },
            { value: 'time5', viewValue: '04:00' },
            { value: 'time6', viewValue: '05:00' },
            { value: 'time7', viewValue: '06:00' },
            { value: 'time8', viewValue: '07:00' },
            { value: 'time9', viewValue: '08:00' },
            { value: 'time10', viewValue: '09:00' },
            { value: 'time11', viewValue: '10:00' },
            { value: 'time12', viewValue: '11:00' },
            { value: 'time13', viewValue: '12:00' },
            { value: 'time14', viewValue: '13:00' },
            { value: 'time15', viewValue: '14:00' },
            { value: 'time16', viewValue: '15:00' },
            { value: 'time17', viewValue: '16:00' },
            { value: 'time18', viewValue: '17:00' },
            { value: 'time19', viewValue: '18:00' },
            { value: 'time20', viewValue: '19:00' },
            { value: 'time21', viewValue: '20:00' },
            { value: 'time22', viewValue: '21:00' },
            { value: 'time23', viewValue: '22:00' },
            { value: 'time24', viewValue: '23:00' }
        ];
    }
    SearchComponent.prototype.ngOnInit = function () {
        if ((typeof this.dataset[0] === 'undefined')) {
            var time = new Date();
            var year = time.getFullYear();
            var month = time.getMonth() + 1;
            var pickday = time.getDate();
            var dropday = time.getDate() + 3;
            this.pDate = year + '-' + month + '-' + pickday;
            this.dDate = year + '-' + month + '-' + dropday;
            this.pTime = '00:00';
            this.dTime = '00:00';
            // console.log(this.dDate);
        }
        else {
            // console.log(typeof this.dataset[4]);
            this.pLocation = this.dataset[0];
            this.dLocation = this.dataset[1];
            this.pDate = this.dataset[2];
            this.pTime = this.dataset[3];
            this.dDate = this.dataset[4];
            this.dTime = this.dataset[5];
        }
    };
    SearchComponent.prototype.fireEvent = function () {
        this.searchCondi = [this.pLocation, this.dLocation, this.pDate, this.pTime, this.dDate, this.dTime];
        this.searchCar.emit(this.searchCondi);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], SearchComponent.prototype, "dataset", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"])
    ], SearchComponent.prototype, "searchCar", void 0);
    SearchComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-search',
            template: __webpack_require__(/*! ./search.component.html */ "./src/app/search/search.component.html"),
            styles: [__webpack_require__(/*! ./search.component.css */ "./src/app/search/search.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], SearchComponent);
    return SearchComponent;
}());



/***/ }),

/***/ "./src/app/services/account.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/account.service.ts ***!
  \*********************************************/
/*! exports provided: AccountDetail, AccountPayload, PassWord, AccountService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountDetail", function() { return AccountDetail; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountPayload", function() { return AccountPayload; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PassWord", function() { return PassWord; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountService", function() { return AccountService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var rxjs_Rx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/Rx */ "./node_modules/rxjs/_esm5/Rx.js");




var AccountDetail = /** @class */ (function () {
    function AccountDetail(_id, email, name, phone, address1, address2, city, state, zip) {
        this._id = _id;
        this.email = email;
        this.name = name;
        this.phone = phone;
        this.address1 = address1;
        this.address2 = address2;
        this.city = city;
        this.state = state;
        this.zip = zip;
    }
    return AccountDetail;
}());

var AccountPayload = /** @class */ (function () {
    function AccountPayload(email, name, phone, address1, address2, city, state, zip) {
        this.email = email;
        this.name = name;
        this.phone = phone;
        this.address1 = address1;
        this.address2 = address2;
        this.city = city;
        this.state = state;
        this.zip = zip;
    }
    return AccountPayload;
}());

var PassWord = /** @class */ (function () {
    function PassWord(currentpassword, newpassword) {
    }
    return PassWord;
}());

var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var AccountService = /** @class */ (function () {
    function AccountService(http) {
        this.http = http;
    }
    AccountService.prototype.getAccountByEmail = function (email) {
        return this.http.get("/api/account/" + email);
    };
    AccountService.prototype.updateAccountByEmail = function (payload, email) {
        return this.http.post("/api/account/" + email, payload);
    };
    AccountService.prototype.createAccount = function (payload) {
        return this.http.post("/api/account", payload);
    };
    AccountService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], AccountService);
    return AccountService;
}());



/***/ }),

/***/ "./src/app/services/admin-service.service.ts":
/*!***************************************************!*\
  !*** ./src/app/services/admin-service.service.ts ***!
  \***************************************************/
/*! exports provided: AdminServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminServiceService", function() { return AdminServiceService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");




var AdminServiceService = /** @class */ (function () {
    function AdminServiceService(auth, router) {
        this.auth = auth;
        this.router = router;
    }
    AdminServiceService.prototype.canActivate = function () {
        if (this.auth.Ifadmin()) {
            this.router.navigateByUrl('/home');
            return false;
        }
        return true;
    };
    AdminServiceService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], AdminServiceService);
    return AdminServiceService;
}());



/***/ }),

/***/ "./src/app/services/auth-guard.service.ts":
/*!************************************************!*\
  !*** ./src/app/services/auth-guard.service.ts ***!
  \************************************************/
/*! exports provided: AuthGuardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuardService", function() { return AuthGuardService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var _authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./authentication.service */ "./src/app/services/authentication.service.ts");




var AuthGuardService = /** @class */ (function () {
    function AuthGuardService(auth, router) {
        this.auth = auth;
        this.router = router;
    }
    AuthGuardService.prototype.canActivate = function () {
        if (!this.auth.isLoggedIn()) {
            this.router.navigateByUrl('/');
            return false;
        }
        return true;
    };
    AuthGuardService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], AuthGuardService);
    return AuthGuardService;
}());



/***/ }),

/***/ "./src/app/services/authentication.service.ts":
/*!****************************************************!*\
  !*** ./src/app/services/authentication.service.ts ***!
  \****************************************************/
/*! exports provided: AuthenticationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthenticationService", function() { return AuthenticationService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var rxjs_operators_map__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators/map */ "./node_modules/rxjs/_esm5/operators/map.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");





var AuthenticationService = /** @class */ (function () {
    function AuthenticationService(http, router) {
        this.http = http;
        this.router = router;
    }
    AuthenticationService.prototype.saveToken = function (token) {
        localStorage.setItem('mean-token', token);
        this.token = token;
    };
    AuthenticationService.prototype.getToken = function () {
        if (!this.token) {
            this.token = localStorage.getItem('mean-token');
        }
        return this.token;
    };
    AuthenticationService.prototype.getUserDetails = function () {
        var token = this.getToken();
        var payload;
        if (token) {
            payload = token.split('.')[1];
            payload = window.atob(payload);
            return JSON.parse(payload);
        }
        else {
            return null;
        }
    };
    AuthenticationService.prototype.isLoggedIn = function () {
        var user = this.getUserDetails();
        if (user) {
            return user.exp > Date.now() / 1000;
        }
        else {
            return false;
        }
    };
    AuthenticationService.prototype.request = function (method, type, user) {
        var _this = this;
        var base;
        if (method === 'post') {
            base = this.http.post("/api/" + type, user);
        }
        else {
            base = this.http.get("/api/" + type, { headers: { Authorization: "Bearer " + this.getToken() } });
        }
        var request = base.pipe(Object(rxjs_operators_map__WEBPACK_IMPORTED_MODULE_3__["map"])(function (data) {
            if (data.token) {
                _this.saveToken(data.token);
            }
            return data;
        }));
        return request;
    };
    AuthenticationService.prototype.register = function (user) {
        return this.request('post', 'register', user);
    };
    AuthenticationService.prototype.login = function (user) {
        return this.request('post', 'login', user);
    };
    AuthenticationService.prototype.profile = function () {
        return this.request('get', 'profile');
    };
    AuthenticationService.prototype.logout = function () {
        this.token = '';
        window.localStorage.removeItem('mean-token');
        this.router.navigateByUrl('/');
    };
    AuthenticationService.prototype.Ifadmin = function () {
        var token = this.getToken();
        var payload;
        if (token) {
            payload = token.split('.')[1];
            payload = window.atob(payload);
            var ans = JSON.parse(payload);
            console.log(ans);
            if (ans.level == "admin")
                return true;
        }
        return false;
    };
    AuthenticationService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], AuthenticationService);
    return AuthenticationService;
}());



/***/ }),

/***/ "./src/app/services/bookings.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/bookings.service.ts ***!
  \**********************************************/
/*! exports provided: BookingsService, Booking */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BookingsService", function() { return BookingsService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Booking", function() { return Booking; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/esm5/http.js");



var BookingsService = /** @class */ (function () {
    function BookingsService(http) {
        this.http = http;
    }
    BookingsService.prototype.getBookingsByEmail = function (email) {
        return this.http.get("/api/booking/" + email);
    };
    BookingsService.prototype.createBooking = function (booking) {
        return this.http.post("/api/booking", booking);
    };
    BookingsService.prototype.setBooking = function (booking) {
        this.booking = booking;
    };
    BookingsService.prototype.getBooking = function () {
        return this.booking;
    };
    BookingsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], BookingsService);
    return BookingsService;
}());

var Booking = /** @class */ (function () {
    function Booking(pickupdate, dropoffdate, pickuploc, dropoffloc, price, carid, email, driverinfo) {
        this.pickupdate = pickupdate;
        this.dropoffdate = dropoffdate;
        this.pickuploc = pickuploc;
        this.dropoffloc = dropoffloc;
        this.price = price;
        this.carid = carid;
        this.email = email;
        this.driverinfo = driverinfo;
    }
    return Booking;
}());



/***/ }),

/***/ "./src/app/services/data-bus.service.ts":
/*!**********************************************!*\
  !*** ./src/app/services/data-bus.service.ts ***!
  \**********************************************/
/*! exports provided: DataBusService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataBusService", function() { return DataBusService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var rxjs_Subject__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/Subject */ "./node_modules/rxjs/_esm5/Subject.js");



var DataBusService = /** @class */ (function () {
    function DataBusService() {
        this.carValueUpdate = new rxjs_Subject__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this.carSearchCondiUpdate = new rxjs_Subject__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
    }
    DataBusService.prototype.setCarInfo = function (car) {
        this.carInfo = car;
        this.carValueUpdate.next(this.carInfo);
    };
    DataBusService.prototype.setSearchCondi = function (data) {
        this.searchCondi = data;
        this.carSearchCondiUpdate.next(this.searchCondi);
    };
    DataBusService.prototype.clearCarMessage = function () {
        // this.carInfo = null;
        this.carValueUpdate.next();
    };
    DataBusService.prototype.getSearchCondi = function () {
        return this.searchCondi;
    };
    DataBusService.prototype.getCarInfo = function () {
        return this.carInfo;
    };
    DataBusService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], DataBusService);
    return DataBusService;
}());



/***/ }),

/***/ "./src/app/services/favoritelist.service.ts":
/*!**************************************************!*\
  !*** ./src/app/services/favoritelist.service.ts ***!
  \**************************************************/
/*! exports provided: FavoritelistService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FavoritelistService", function() { return FavoritelistService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/esm5/http.js");



var FavoritelistService = /** @class */ (function () {
    function FavoritelistService(http) {
        this.http = http;
    }
    FavoritelistService.prototype.getFavoritesByEmail = function (email) {
        return this.http.get("/api/favoritelist/" + email);
    };
    FavoritelistService.prototype.createFavorite = function (favorite) {
        return this.http.post("/api/favoritelist", favorite);
    };
    FavoritelistService.prototype.deleteFavorite = function (favorite) {
        return this.http.delete("/api/favoritelist/" + favorite.email + "&" + favorite.carid);
    };
    FavoritelistService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], FavoritelistService);
    return FavoritelistService;
}());



/***/ }),

/***/ "./src/app/services/product.service.ts":
/*!*********************************************!*\
  !*** ./src/app/services/product.service.ts ***!
  \*********************************************/
/*! exports provided: ProductService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductService", function() { return ProductService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var rxjs_Rx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/Rx */ "./node_modules/rxjs/_esm5/Rx.js");




var ProductService = /** @class */ (function () {
    // private dataObservable$ = new ReplaySubject(1);
    function ProductService(http) {
        this.http = http;
    }
    ProductService.prototype.getProductlist = function () {
        this.http.post("/api/carlists", {}).subscribe(function (data) {
            console.log(data);
        }, function (err) {
            console.log("Error occured.");
        });
        return null;
    };
    ProductService.prototype.getAllProduct = function () {
        console.log("sent request 1");
        return this.http.get('api/carlists');
    };
    ProductService.prototype.postCar = function (carInfor) {
        console.log('postCar begin - in productservice');
        this.http.post('/api/carlists', carInfor).subscribe(function (res) {
            console.log("get response after postcar");
            console.log(res);
        }, function (err) {
            console.log("Error occured when post car");
        });
        console.log('postCar finish - in productservice');
    };
    //search car by car id conditions
    ProductService.prototype.searchCarId = function (id) {
        return this.http.get("/api/car/" + id);
    };
    //search by several conditions
    // searchCarProduct():Observable<Car[]>{
    //   console.log("search!!!")
    //
    //   return this.http.get<Car[]>('/api/carlists/search');
    // }
    ProductService.prototype.searchCarProduct = function (pickPlace) {
        return this.http.get("/api/carlists/search/" + pickPlace);
    };
    ProductService.prototype.searchCarwithFilter = function (newOptions) {
        return this.http.get("/api/carlists/filter/" + newOptions.pickLocation + "&" + newOptions.priceMax + "&" + newOptions.priceMin + "&" + newOptions.carType + "&" + newOptions.passengerNumMax);
    };
    ProductService.prototype.createCar = function (car) {
        return this.http.post("/api/car", car);
    };
    ProductService.prototype.deleteCarById = function (id) {
        return this.http.delete("/api/car/" + id);
    };
    ProductService.prototype.putCar = function (car) {
        console.log('enter productservice putcar and car infor is:\n');
        console.log(car);
        return this.http.put("/api/car", car);
    };
    ProductService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], ProductService);
    return ProductService;
}());



/***/ }),

/***/ "./src/app/welcome/welcome.component.css":
/*!***********************************************!*\
  !*** ./src/app/welcome/welcome.component.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".bg{\n  background-image: url('welcome-car3.jpg');\n\n  /* Full height */\n  height: 100%;\n\n  /* Center and scale the image nicely */\n  background-position: center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n\n.search{\n  margin-left: 35%;\n  margin-right: 35%;\n  padding-top: 10%;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvd2VsY29tZS93ZWxjb21lLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx5Q0FBc0Q7O0VBRXRELGdCQUFnQjtFQUNoQixZQUFZOztFQUVaLHNDQUFzQztFQUN0QywyQkFBMkI7RUFDM0IsNEJBQTRCO0VBQzVCLHNCQUFzQjtBQUN4Qjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixpQkFBaUI7RUFDakIsZ0JBQWdCO0FBQ2xCIiwiZmlsZSI6InNyYy9hcHAvd2VsY29tZS93ZWxjb21lLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYmd7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4uLy4uL2Fzc2V0cy93ZWxjb21lLWNhcjMuanBnXCIpO1xuXG4gIC8qIEZ1bGwgaGVpZ2h0ICovXG4gIGhlaWdodDogMTAwJTtcblxuICAvKiBDZW50ZXIgYW5kIHNjYWxlIHRoZSBpbWFnZSBuaWNlbHkgKi9cbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuXG4uc2VhcmNoe1xuICBtYXJnaW4tbGVmdDogMzUlO1xuICBtYXJnaW4tcmlnaHQ6IDM1JTtcbiAgcGFkZGluZy10b3A6IDEwJTtcbn1cbiJdfQ== */"

/***/ }),

/***/ "./src/app/welcome/welcome.component.html":
/*!************************************************!*\
  !*** ./src/app/welcome/welcome.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\n   <!-- Slider Area Start -->\n   <section class=\"gauto-slider-area fix\">\n    <div class=\"gauto-slide owl-carousel\">\n       <div class=\"gauto-main-slide slide-item-1\">\n          <div class=\"gauto-main-caption\">\n             <div class=\"gauto-caption-cell\">\n                <div class=\"container\">\n                   <div class=\"row\">\n                      <div class=\"col-md-12\">\n                         <div class=\"slider-text\">\n                          <p>Great rates & Personalized Service    </p>\n                        <h2>Rent a Car <span> in Karpathos</span></h2>\n                     <!-- <a href=\"#\" class=\"gauto-btn\">Reserve Now!</a>-->\n                         </div>\n                      </div>\n                   </div>\n                </div>\n             </div>\n          </div>\n       </div>\n       <div class=\"gauto-main-slide slide-item-2\">\n          <div class=\"gauto-main-caption\">\n             <div class=\"gauto-caption-cell\">\n                <div class=\"container\">\n                   <div class=\"row\">\n                      <div class=\"col-md-12\">\n                         <div class=\"slider-text\">\n                            <p>Best Prices in Karpathos</p>\n                            <h2>Reserved Now & Get <span>best service</span></h2>\n                            <!-- <a href=\"#\" class=\"gauto-btn\">Reserve Now!</a>-->\n                         </div>\n                      </div>\n                   </div>\n                </div>\n             </div>\n          </div>\n       </div>\n    </div>\n </section>\n <!-- Slider Area End -->\n\n\n <!-- Find Area Start -->\n <section class=\"gauto-find-area\">\n    <div class=\"container\">\n       <div class=\"row\">\n          <div class=\"col-md-12\">\n             <div class=\"find-box\">\n                <div class=\"row\">\n                   <div class=\"col-md-4\">\n                      <div class=\"find-text\">\n                         <h3>Reserve Now</h3>\n                      </div>\n                   </div>\n                   <div class=\"col-md-8\">\n                      <div class=\"find-form\">\n                         <form>\n                            <div class=\"row\">\n                               <div class=\"col-md-4\">\n                                  <p>\n                                     <input type=\"text\" placeholder=\"From Address\" />\n                                  </p>\n                               </div>\n                               <div class=\"col-md-4\">\n                                  <p>\n                                     <input type=\"text\" placeholder=\"To Address\" />\n                                  </p>\n                               </div>\n                               <div class=\"col-md-4\">\n                                  <p>\n                                     <select>\n                                        <option data-display=\"Select\">AC Car</option>\n                                        <option>Non-AC Car</option>\n                                     </select>\n                                  </p>\n                               </div>\n                            </div>\n                            <div class=\"row\">\n                               <div class=\"col-md-4\">\n                                  <p>\n                                     <input id=\"reservation_date\" name=\"reservation_date\" placeholder=\"Journey Date\" data-select=\"datepicker\" type=\"text\">\n                                  </p>\n                               </div>\n                               <div class=\"col-md-4\">\n                                  <p class=\"input-group clockpicker\" data-placement=\"bottom\" data-align=\"top\" data-autoclose=\"true\">\n                                     <input type=\"text\" class=\"form-control\" placeholder=\"Journey Time\" />\n                                  </p>\n                               </div>\n                               <div class=\"col-md-4\">\n                                  <p>\n                                     <button type=\"submit\" class=\"gauto-theme-btn\">Find Car</button>\n                                  </p>\n                               </div>\n                            </div>\n                         </form>\n                      </div>\n                   </div>\n                </div>\n             </div>\n          </div>\n       </div>\n    </div>\n </section>\n <!-- Find Area End -->\n\n\n <!-- About Area Start -->\n <section class=\"gauto-about-area section_70\">\n    <div class=\"container\">\n       <div class=\"row\">\n          <div class=\"col-lg-6\">\n             <div class=\"about-left\">\n                <h4>&nbsp;</h4>\n                <h2>Welcome to Autoland</h2>\n                <p>Welcome to our new AutoLand Karpathos Rent A Car Website. Autoland is a quality service car rental in the Greek Island of Karpathos founded by Giannis Chirakis.\n                  We are located in Pigadia, Karpathos Island. Our cars are brand new and we offer car rental benefits as well as competitive car rental prices.</p>\n                <div class=\"about-list\">\n                   <ul>\n                      <li><i class=\"fa fa-check\"></i>We are a trusted name</li>\n                      <li><i class=\"fa fa-check\"></i>we deal in have all brands</li>\n                      <li><i class=\"fa fa-check\"></i>have a larger stock of vehicles</li>\n                      <li><i class=\"fa fa-check\"></i>we are at worldwide locations</li>\n                   </ul>\n                </div>\n           <!--    <div class=\"about-signature\">\n                   <div class=\"signature-left\">\n                      <img src=\"assets/img/signature.png\" alt=\"signature\" />\n                   </div>\n                   <div class=\"signature-right\">\n                      <h3>Robertho Garcia</h3>\n                      <p>President</p>\n                   </div>\n                </div>-->\n             </div>\n          </div>\n          <div class=\"col-lg-6\">\n             <div class=\"about-right\">\n                <img src=\"assets/img/rent-a-car-atv-moto-autoland-karpathos-island.jpg\" alt=\"Autoland rent a car moto atv - Karpathos Island\" />\n             </div>\n          </div>\n       </div>\n    </div>\n </section>\n <!-- About Area End -->\n\n\n <!-- Service Area Start\n <section class=\"gauto-service-area section_70\">\n    <div class=\"container\">\n       <div class=\"row\">\n          <div class=\"col-md-12\">\n             <div class=\"site-heading\">\n                <h4>see our</h4>\n                <h2>Latest Services</h2>\n             </div>\n          </div>\n       </div>\n       <div class=\"row\">\n          <div class=\"col-md-12\">\n             <div class=\"service-slider owl-carousel\">\n                <div class=\"single-service\">\n                   <span class=\"service-number\">01 </span>\n                   <div class=\"service-icon\">\n                      <img src=\"assets/img/city-transport.png\" alt=\"city trasport\" />\n                   </div>\n                   <div class=\"service-text\">\n                      <a href=\"#\">\n                         <h3>City transfer</h3>\n                      </a>\n                      <p>Risus commodo maecenas accumsan lacus vel facilisis. Dorem ipsum dolor consectetur adipiscing elit.</p>\n                   </div>\n                </div>\n                <div class=\"single-service\">\n                   <span class=\"service-number\">02 </span>\n                   <div class=\"service-icon\">\n                      <img src=\"assets/img/airport-transport.png\" alt=\"airport trasport\" />\n                   </div>\n                   <div class=\"service-text\">\n                      <a href=\"#\">\n                         <h3>Airport transfer</h3>\n                      </a>\n                      <p>Risus commodo maecenas accumsan lacus vel facilisis. Dorem ipsum dolor consectetur adipiscing elit.</p>\n                   </div>\n                </div>\n                <div class=\"single-service\">\n                   <span class=\"service-number\">03 </span>\n                   <div class=\"service-icon\">\n                      <img src=\"assets/img/hospital-transport.png\" alt=\"hospital trasport\" />\n                   </div>\n                   <div class=\"service-text\">\n                      <a href=\"#\">\n                         <h3>Hospital transfer</h3>\n                      </a>\n                      <p>Risus commodo maecenas accumsan lacus vel facilisis. Dorem ipsum dolor consectetur adipiscing elit.</p>\n                   </div>\n                </div>\n                <div class=\"single-service\">\n                   <span class=\"service-number\">04 </span>\n                   <div class=\"service-icon\">\n                      <img src=\"assets/img/wedding-ceremony.png\" alt=\"wedding trasport\" />\n                   </div>\n                   <div class=\"service-text\">\n                      <a href=\"#\">\n                         <h3>wedding ceremony</h3>\n                      </a>\n                      <p>Risus commodo maecenas accumsan lacus vel facilisis. Dorem ipsum dolor consectetur adipiscing elit.</p>\n                   </div>\n                </div>\n                <div class=\"single-service\">\n                   <span class=\"service-number\">05 </span>\n                   <div class=\"service-icon\">\n                      <img src=\"assets/img/hotel-transport.png\" alt=\"wedding trasport\" />\n                   </div>\n                   <div class=\"service-text\">\n                      <a href=\"#\">\n                         <h3>Whole City Tour</h3>\n                      </a>\n                      <p>Risus commodo maecenas accumsan lacus vel facilisis. Dorem ipsum dolor consectetur adipiscing elit.</p>\n                   </div>\n                </div>\n                <div class=\"single-service\">\n                   <span class=\"service-number\">06 </span>\n                   <div class=\"service-icon\">\n                      <img src=\"assets/img/luggege-transport.png\" alt=\"wedding trasport\" />\n                   </div>\n                   <div class=\"service-text\">\n                      <a href=\"#\">\n                         <h3>Baggage transport</h3>\n                      </a>\n                      <p>Risus commodo maecenas accumsan lacus vel facilisis. Dorem ipsum dolor consectetur adipiscing elit.</p>\n                   </div>\n                </div>\n             </div>\n          </div>\n       </div>\n    </div>\n </section>-->\n <!-- Service Area End -->\n\n\n <!-- Promo Area Start\n <section class=\"gauto-promo-area\">\n    <div class=\"container\">\n       <div class=\"row\">\n          <div class=\"col-md-6\">\n             <div class=\"promo-box-left\">\n                <img src=\"assets/img/toyota-offer-2.png\" alt=\"promo car\" />\n             </div>\n          </div>\n          <div class=\"col-md-6\">\n             <div class=\"promo-box-right\">\n                <h3>Do You Want To Earn With Us? So Don't be Late.</h3>\n                <a href=\"#\" class=\"gauto-btn\">Become a drive</a>\n             </div>\n          </div>\n       </div>\n    </div>\n </section>-->\n <!-- Promo Area End -->\n\n\n <!-- Offers Area Start -->\n <section class=\"gauto-offers-area section_70\">\n    <div class=\"container\">\n       <div class=\"row\">\n          <div class=\"col-md-12\">\n             <div class=\"site-heading\">\n\n                <h2>Our Fleet</h2>\n             </div>\n          </div>\n       </div>\n       <div class=\"row\">\n          <div class=\"col-md-12\">\n             <div class=\"offer-tabs\">\n                <ul class=\"nav nav-tabs\" id=\"offerTab\" role=\"tablist\">\n                   <li class=\"nav-item\">\n                      <a class=\"nav-link active\" id=\"all-tab\" data-toggle=\"tab\" href=\"#all\" role=\"tab\" aria-controls=\"all\" aria-selected=\"true\">Moto</a>\n                   </li>\n                   <li class=\"nav-item\">\n                      <a class=\"nav-link\" id=\"nissan-tab\" data-toggle=\"tab\" href=\"#nissan\" role=\"tab\" aria-controls=\"nissan\" aria-selected=\"false\">Class A</a>\n                   </li>\n                   <li class=\"nav-item\">\n                      <a class=\"nav-link\" id=\"Toyota-tab\" data-toggle=\"tab\" href=\"#Toyota\" role=\"tab\" aria-controls=\"Toyota\" aria-selected=\"false\">Class B</a>\n                   </li>\n                   <li class=\"nav-item\">\n                      <a class=\"nav-link\" id=\"Audi-tab\" data-toggle=\"tab\" href=\"#Audi\" role=\"tab\" aria-controls=\"Audi\" aria-selected=\"false\">Class C</a>\n                   </li>\n                   <li class=\"nav-item\">\n                      <a class=\"nav-link\" id=\"mercedes-tab\" data-toggle=\"tab\" href=\"#mercedes\" role=\"tab\" aria-controls=\"mercedes\" aria-selected=\"false\">Class D</a>\n                   </li>\n                </ul>\n                <div class=\"tab-content\" id=\"offerTabContent\">\n                   <!-- All Tab Start -->\n                   <div class=\"tab-pane fade show active\" id=\"all\" role=\"tabpanel\" aria-labelledby=\"all-tab\">\n                      <div class=\"row\">\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/vehicleImages/moto/SC-AGILITY-125.jpg\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Agility Plus 125cc</h3>\n                                  </a>\n                                  <h4>€28.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Yamaha</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>Passengers 2</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/vehicleImages/moto/SC-LIKE-125.jpg\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Like 125cc White</h3>\n                                  </a>\n                                  <h4>€28.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Yamaha</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>Passengers 2</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/vehicleImages/moto/SC-AGILITY-200.jpg\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Agility Plus 200cc</h3>\n                                  </a>\n                                  <h4>€32.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Yamaha</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>Passengers 2</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                      </div>\n                     <!--  <div class=\"row\">\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/bmw-offer.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>BMW X3</h3>\n                                  </a>\n                                  <h4>$50.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/audi-offer.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Audi Q3</h3>\n                                  </a>\n                                  <h4>$75.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/toyota-offer-2.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Toyota Camry</h3>\n                                  </a>\n                                  <h4>$55.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                      </div>-->\n                   </div>\n                   <!-- All Tab End -->\n\n                   <!-- Nissan Tab Start -->\n                   <div class=\"tab-pane fade\" id=\"nissan\" role=\"tabpanel\" aria-labelledby=\"nissan-tab\">\n                      <div class=\"row\">\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/bmw-offer.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>BMW X3</h3>\n                                  </a>\n                                  <h4>$50.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/audi-offer.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Audi Q3</h3>\n                                  </a>\n                                  <h4>$75.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/toyota-offer-2.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Toyota Camry</h3>\n                                  </a>\n                                  <h4>$55.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                      </div>\n                   </div>\n                   <!-- Nissan Tab End -->\n\n                   <!-- Toyota Tab Start -->\n                   <div class=\"tab-pane fade\" id=\"Toyota\" role=\"tabpanel\" aria-labelledby=\"Toyota-tab\">\n                      <div class=\"row\">\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/nissan-offer.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Nissan 370Z</h3>\n                                  </a>\n                                  <h4>$75.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/offer-toyota.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Toyota Alphard</h3>\n                                  </a>\n                                  <h4>$50.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/audi-offer.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Audi Q3</h3>\n                                  </a>\n                                  <h4>$45.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                      </div>\n                   </div>\n                   <!-- Toyota Tab Start -->\n\n                   <!-- Audi Tab Start -->\n                   <div class=\"tab-pane fade\" id=\"Audi\" role=\"tabpanel\" aria-labelledby=\"Audi-tab\">\n                      <div class=\"row\">\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/audi-offer.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Audi Q3</h3>\n                                  </a>\n                                  <h4>$45.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/nissan-offer.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Nissan 370Z</h3>\n                                  </a>\n                                  <h4>$75.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/toyota-offer-2.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Toyota Alphard</h3>\n                                  </a>\n                                  <h4>$50.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                      </div>\n                   </div>\n                   <!-- Audi Tab End -->\n\n                   <!-- Marcedes Tab Start -->\n                   <div class=\"tab-pane fade\" id=\"mercedes\" role=\"tabpanel\" aria-labelledby=\"mercedes-tab\">\n                      <div class=\"row\">\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/marcedes-offer.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>marcedes S-class</h3>\n                                  </a>\n                                  <h4>$50.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/audi-offer.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Audi Q3</h3>\n                                  </a>\n                                  <h4>$45.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                         <div class=\"col-lg-4\">\n                            <div class=\"single-offers\">\n                               <div class=\"offer-image\">\n                                  <a href=\"#\">\n                                  <img src=\"assets/img/nissan-offer.png\" alt=\"offer 1\" />\n                                  </a>\n                               </div>\n                               <div class=\"offer-text\">\n                                  <a href=\"#\">\n                                     <h3>Nissan 370Z</h3>\n                                  </a>\n                                  <h4>$75.00<span>/ Day</span></h4>\n                                  <ul>\n                                     <li><i class=\"fa fa-car\"></i>Model:2017</li>\n                                     <li><i class=\"fa fa-cogs\"></i>Automatic</li>\n                                     <li><i class=\"fa fa-dashboard\"></i>20kmpl</li>\n                                  </ul>\n                                  <div class=\"offer-action\">\n                                     <a href=\"#\" class=\"offer-btn-1\">Rent Now</a>\n                                     <a href=\"#\" class=\"offer-btn-2\">Details</a>\n                                  </div>\n                               </div>\n                            </div>\n                         </div>\n                      </div>\n                   </div>\n                   <!-- Marcedes Tab End -->\n\n                </div>\n             </div>\n          </div>\n       </div>\n    </div>\n </section>\n <!-- Offers Area End -->\n\n\n <!-- Testimonial Area Start\n <section class=\"gauto-testimonial-area section_70\">\n    <div class=\"container\">\n       <div class=\"row\">\n          <div class=\"col-md-12\">\n             <div class=\"site-heading\">\n                <h4>Some words</h4>\n                <h2>testimonial</h2>\n             </div>\n          </div>\n       </div>\n       <div class=\"row\">\n          <div class=\"col-md-12\">\n             <div class=\"testimonial-slider owl-carousel\">\n                <div class=\"single-testimonial\">\n                   <div class=\"testimonial-text\">\n                      <p>\"Dorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat adipisicing elit.\"</p>\n                      <div class=\"testimonial-meta\">\n                         <div class=\"client-image\">\n                            <img src=\"assets/img/testimonial.jpg\" alt=\"testimonial\" />\n                         </div>\n                         <div class=\"client-info\">\n                            <h3>Marco Ghaly</h3>\n                            <p>Customer</p>\n                         </div>\n                      </div>\n                   </div>\n                </div>\n                <div class=\"single-testimonial\">\n                   <div class=\"testimonial-text\">\n                      <p>\"Forem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat adipisicing elit.\"</p>\n                      <div class=\"testimonial-meta\">\n                         <div class=\"client-image\">\n                            <img src=\"assets/img/testimonial-2.jpg\" alt=\"testimonial\" />\n                         </div>\n                         <div class=\"client-info\">\n                            <h3>Sherief Arafa</h3>\n                            <p>Customer</p>\n                         </div>\n                      </div>\n                   </div>\n                </div>\n                <div class=\"single-testimonial\">\n                   <div class=\"testimonial-text\">\n                      <p>\"Dorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat adipisicing elit.\"</p>\n                      <div class=\"testimonial-meta\">\n                         <div class=\"client-image\">\n                            <img src=\"assets/img/testimonial.jpg\" alt=\"testimonial\" />\n                         </div>\n                         <div class=\"client-info\">\n                            <h3>Marco Ghaly</h3>\n                            <p>Customer</p>\n                         </div>\n                      </div>\n                   </div>\n                </div>\n                <div class=\"single-testimonial\">\n                   <div class=\"testimonial-text\">\n                      <p>\"Dorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat adipisicing elit.\"</p>\n                      <div class=\"testimonial-meta\">\n                         <div class=\"client-image\">\n                            <img src=\"assets/img/testimonial.jpg\" alt=\"testimonial\" />\n                         </div>\n                         <div class=\"client-info\">\n                            <h3>Marco Ghaly</h3>\n                            <p>Customer</p>\n                         </div>\n                      </div>\n                   </div>\n                </div>\n             </div>\n          </div>\n       </div>\n    </div>\n </section> -->\n <!-- Testimonial Area End -->\n\n\n <!-- Driver Area Start\n <section class=\"gauto-driver-area section_70\">\n    <div class=\"container\">\n       <div class=\"row\">\n          <div class=\"col-md-12\">\n             <div class=\"site-heading\">\n                <h4>experts</h4>\n                <h2>our Members</h2>\n             </div>\n          </div>\n       </div>\n       <div class=\"row\">\n          <div class=\"col-lg-3 col-sm-6\">\n             <div class=\"single-driver\">\n                <div class=\"driver-image\">\n                   <img src=\"assets/img/driver-1.jpg\" alt=\"driver 1\" />\n                   <div class=\"hover\">\n                      <ul class=\"social-icon\">\n                         <li><a href=\"#\"><i class=\"fa fa-facebook\"></i></a></li>\n                         <li><a href=\"#\"><i class=\"fa fa-twitter\"></i></a></li>\n                         <li><a href=\"#\"><i class=\"fa fa-linkedin\"></i></a></li>\n                         <li><a href=\"#\"><i class=\"fa fa-instagram\"></i></a></li>\n                      </ul>\n                   </div>\n                </div>\n                <div class=\"driver-text\">\n                   <div class=\"driver-name\">\n                      <a href=\"#\">\n                         <h3>Marco Ghaly</h3>\n                      </a>\n                      <p>4 years experience</p>\n                   </div>\n                </div>\n             </div>\n          </div>\n          <div class=\"col-lg-3 col-sm-6\">\n             <div class=\"single-driver\">\n                <div class=\"driver-image\">\n                   <img src=\"assets/img/driver-2.jpg\" alt=\"driver 1\" />\n                   <div class=\"hover\">\n                      <ul class=\"social-icon\">\n                         <li><a href=\"#\"><i class=\"fa fa-facebook\"></i></a></li>\n                         <li><a href=\"#\"><i class=\"fa fa-twitter\"></i></a></li>\n                         <li><a href=\"#\"><i class=\"fa fa-linkedin\"></i></a></li>\n                         <li><a href=\"#\"><i class=\"fa fa-instagram\"></i></a></li>\n                      </ul>\n                   </div>\n                </div>\n                <div class=\"driver-text\">\n                   <div class=\"driver-name\">\n                      <a href=\"#\">\n                         <h3>Sheref joe</h3>\n                      </a>\n                      <p>7 years experience</p>\n                   </div>\n                </div>\n             </div>\n          </div>\n          <div class=\"col-lg-3 col-sm-6\">\n             <div class=\"single-driver\">\n                <div class=\"driver-image\">\n                   <img src=\"assets/img/driver-4.jpg\" alt=\"driver 1\" />\n                   <div class=\"hover\">\n                      <ul class=\"social-icon\">\n                         <li><a href=\"#\"><i class=\"fa fa-facebook\"></i></a></li>\n                         <li><a href=\"#\"><i class=\"fa fa-twitter\"></i></a></li>\n                         <li><a href=\"#\"><i class=\"fa fa-linkedin\"></i></a></li>\n                         <li><a href=\"#\"><i class=\"fa fa-instagram\"></i></a></li>\n                      </ul>\n                   </div>\n                </div>\n                <div class=\"driver-text\">\n                   <div class=\"driver-name\">\n                      <a href=\"#\">\n                         <h3>Arafa lep</h3>\n                      </a>\n                      <p>3 years experience</p>\n                   </div>\n                </div>\n             </div>\n          </div>\n          <div class=\"col-lg-3 col-sm-6\">\n             <div class=\"single-driver\">\n                <div class=\"driver-image\">\n                   <img src=\"assets/img/driver-3.jpg\" alt=\"driver 1\" />\n                   <div class=\"hover\">\n                      <ul class=\"social-icon\">\n                         <li><a href=\"#\"><i class=\"fa fa-facebook\"></i></a></li>\n                         <li><a href=\"#\"><i class=\"fa fa-twitter\"></i></a></li>\n                         <li><a href=\"#\"><i class=\"fa fa-linkedin\"></i></a></li>\n                         <li><a href=\"#\"><i class=\"fa fa-instagram\"></i></a></li>\n                      </ul>\n                   </div>\n                </div>\n                <div class=\"driver-text\">\n                   <div class=\"driver-name\">\n                      <a href=\"#\">\n                         <h3>Endly Kent</h3>\n                      </a>\n                      <p>4 years experience</p>\n                   </div>\n                </div>\n             </div>\n          </div>\n       </div>\n       <div class=\"row\">\n          <div class=\"col-md-12\">\n             <div class=\"load-more\">\n                <a href=\"#\" class=\"gauto-btn\">More Members</a>\n             </div>\n          </div>\n       </div>\n    </div>\n </section>-->\n <!-- Driver Area End -->\n\n\n <!-- Call Area Start\n <section class=\"gauto-call-area\">\n    <div class=\"container\">\n       <div class=\"row\">\n          <div class=\"col-md-12\">\n             <div class=\"call-box\">\n                <div class=\"call-box-inner\">\n                   <h2>With Over <span>150+</span> Partners Locations</h2>\n                   <p>Labore dolore magna aliqua ipsum veniam quis nostrud exercitation voluptate velit cillum dolore feu fugiat nulla excepteur sint occaecat sed ipsum cupidatat proident culpa exercitation ullamco laboris aliquik.</p>\n                   <div class=\"call-number\">\n                      <div class=\"call-icon\">\n                         <i class=\"fa fa-phone\"></i>\n                      </div>\n                      <div class=\"call-text\">\n                         <p>need any help?</p>\n                         <h4><a href=\"#\">(431) 529 2093</a></h4>\n                      </div>\n                   </div>\n                </div>\n             </div>\n          </div>\n       </div>\n    </div>\n </section>-->\n <!-- Call Area End -->\n\n\n <!-- Blog Area Start -->\n <section class=\"gauto-blog-area section_70\">\n    <div class=\"container\">\n       <div class=\"row\">\n          <div class=\"col-md-12\">\n             <div class=\"site-heading\">\n                <h4>Karpathos Island</h4>\n                <h2>our Island</h2>\n             </div>\n          </div>\n       </div>\n       <div class=\"row\">\n          <div class=\"col-lg-4\">\n             <div class=\"single-blog\">\n                <div class=\"blog-image\">\n                   <a href=\"#\">\n                   <img src=\"assets/img/karpathosisland/karpathos-Island-rent-a-car-home-3.jpg\" alt=\"blog 1\" />\n                   </a>\n                </div>\n                <div class=\"blog-text\">\n                   <h3><a href=\"#\">Best Karpathos Beaches.</a></h3>\n                   <div class=\"blog-meta-home\">\n                      <div class=\"blog-meta-left\">\n                         <p>July 13, 09:43 am</p>\n                      </div>\n                      <div class=\"blog-meta-right\">\n                         <p><i class=\"fa fa-eye\"></i> 322</p>\n                         <p><i class=\"fa fa-commenting\"></i> 67</p>\n                      </div>\n                   </div>\n                </div>\n             </div>\n          </div>\n          <div class=\"col-lg-4\">\n             <div class=\"single-blog\">\n                <div class=\"blog-image\">\n                   <a href=\"#\">\n                   <img src=\"assets/img/karpathosisland/karpathos-Island-rent-a-car-home-2.jpg\" alt=\"blog 1\" />\n                   </a>\n                </div>\n                <div class=\"blog-text\">\n                   <h3><a href=\"#\">Best Karpathos Tours.</a></h3>\n                   <div class=\"blog-meta-home\">\n                      <div class=\"blog-meta-left\">\n                         <p>July 13, 09:43 am</p>\n                      </div>\n                      <div class=\"blog-meta-right\">\n                         <p><i class=\"fa fa-eye\"></i> 322</p>\n                         <p><i class=\"fa fa-commenting\"></i> 67</p>\n                      </div>\n                   </div>\n                </div>\n             </div>\n          </div>\n          <div class=\"col-lg-4\">\n             <div class=\"single-blog\">\n                <div class=\"blog-image\">\n                   <a href=\"#\">\n                   <img src=\"assets/img/karpathosisland/karpathos-Island-rent-a-car-home-1.jpg\" alt=\"blog 1\" />\n                   </a>\n                </div>\n                <div class=\"blog-text\">\n                   <h3><a href=\"#\">Must Visit Places</a></h3>\n                   <div class=\"blog-meta-home\">\n                      <div class=\"blog-meta-left\">\n                         <p>July 13, 09:43 am</p>\n                      </div>\n                      <div class=\"blog-meta-right\">\n                         <p><i class=\"fa fa-eye\"></i> 322</p>\n                         <p><i class=\"fa fa-commenting\"></i> 67</p>\n                      </div>\n                   </div>\n                </div>\n             </div>\n          </div>\n       </div>\n    </div>\n </section>\n <!-- Blog Area End -->\n\n<!-- <div class=\"bg\">\n  <div class=\"search\">\n    <app-search-welcome></app-search-welcome>\n  </div>\n</div>\n<div class=\"gap\"></div>\n<div class=\"container\">\n  <div class=\"text-center row\">\n    <div class=\"col-md-8 col-md-offset-2\">\n      <div class=\"row row-wrap\" data-gutter=\"60\">\n        <div class=\"col-md-4\">\n          <div class=\"thumb\">\n            <header class=\"thumb-header\">\n              <i\n                class=\"fa fa-dollar box-icon-gray box-icon-center round box-icon-border box-icon-big animate-icon-top-to-bottom\"\n              ></i>\n            </header>\n            <div class=\"thumb-caption\">\n              <h5 class=\"thumb-title\">\n                <a class=\"text-darken\" href=\"#\">Best Price Guarantee</a>\n              </h5>\n              <p class=\"thumb-desc\">\n                Facilisis sollicitudin dolor dignissim pulvinar ultrices nullam\n                vel ultricies phasellus\n              </p>\n            </div>\n          </div>\n        </div>\n        <div class=\"col-md-4\">\n          <div class=\"thumb\">\n            <header class=\"thumb-header\">\n              <i\n                class=\"fa fa-lock box-icon-gray box-icon-center round box-icon-border box-icon-big animate-icon-top-to-bottom\"\n              ></i>\n            </header>\n            <div class=\"thumb-caption\">\n              <h5 class=\"thumb-title\">\n                <a class=\"text-darken\" href=\"#\">Trust & Safety</a>\n              </h5>\n              <p class=\"thumb-desc\">\n                Risus porttitor dignissim nibh purus ornare imperdiet nullam\n                convallis mattis\n              </p>\n            </div>\n          </div>\n        </div>\n        <div class=\"col-md-4\">\n          <div class=\"thumb\">\n            <header class=\"thumb-header\">\n              <i\n                class=\"fa fa-send box-icon-gray box-icon-center round box-icon-border box-icon-big animate-icon-top-to-bottom\"\n              ></i>\n            </header>\n            <div class=\"thumb-caption\">\n              <h5 class=\"thumb-title\">\n                <a class=\"text-darken\" href=\"#\">Best Destinations</a>\n              </h5>\n              <p class=\"thumb-desc\">\n                Sollicitudin enim ad mauris lacus lectus a iaculis lorem\n                pellentesque\n              </p>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div class=\"gap gap-small\"></div>\n</div>\n<div class=\"bg-holder\">\n  <div class=\"bg-mask\"></div>\n  <div class=\"bg-blur\" style=\"background-image:url(img/1024x672.png);\"></div>\n  <div class=\"bg-content\">\n    <div class=\"container\">\n      <div class=\"gap gap-big text-center text-white\">\n        <h2 class=\"text-uc mb20\">Last Minute Deal</h2>\n        <ul class=\"icon-list list-inline-block mb0 last-minute-rating\">\n          <li><i class=\"fa fa-star\"></i></li>\n          <li><i class=\"fa fa-star\"></i></li>\n          <li><i class=\"fa fa-star\"></i></li>\n          <li><i class=\"fa fa-star\"></i></li>\n          <li><i class=\"fa fa-star\"></i></li>\n        </ul>\n        <h5 class=\"last-minute-title\">The Peninsula - New York</h5>\n        <p class=\"last-minute-date\">Fri 14 Mar - Sun 16 Mar</p>\n        <p class=\"mb20\"><b>$120</b> / person</p>\n        <a class=\"btn btn-lg btn-white btn-ghost\" href=\"#\"\n          >Book Now <i class=\"fa fa-angle-right\"></i\n        ></a>\n      </div>\n    </div>\n  </div>\n</div>\n<div class=\"container\">\n  <div class=\"gap\"></div>\n  <h2 class=\"text-center\">Top Destinations</h2>\n  <div class=\"gap\">\n    <div class=\"row row-wrap\">\n      <div class=\"col-md-3\">\n        <div class=\"thumb\">\n          <header class=\"thumb-header\">\n            <a class=\"hover-img curved\" href=\"#\">\n              <img\n                src=\"img/800x600.png\"\n                alt=\"Image Alternative text\"\n                title=\"Upper Lake in New York Central Park\"\n              /><i\n                class=\"fa fa-plus box-icon-white box-icon-border hover-icon-top-right round\"\n              ></i>\n            </a>\n          </header>\n          <div class=\"thumb-caption\">\n            <h4 class=\"thumb-title\">USA</h4>\n            <p class=\"thumb-desc\">\n              Tellus cum ante sed mus vulputate scelerisque eu\n            </p>\n          </div>\n        </div>\n      </div>\n      <div class=\"col-md-3\">\n        <div class=\"thumb\">\n          <header class=\"thumb-header\">\n            <a class=\"hover-img curved\" href=\"#\">\n              <img\n                src=\"img/800x600.png\"\n                alt=\"Image Alternative text\"\n                title=\"lack of blue depresses me\"\n              /><i\n                class=\"fa fa-plus box-icon-white box-icon-border hover-icon-top-right round\"\n              ></i>\n            </a>\n          </header>\n          <div class=\"thumb-caption\">\n            <h4 class=\"thumb-title\">Greece</h4>\n            <p class=\"thumb-desc\">\n              Per fermentum etiam nisi platea dui posuere nibh\n            </p>\n          </div>\n        </div>\n      </div>\n      <div class=\"col-md-3\">\n        <div class=\"thumb\">\n          <header class=\"thumb-header\">\n            <a class=\"hover-img curved\" href=\"#\">\n              <img\n                src=\"img/800x600.png\"\n                alt=\"Image Alternative text\"\n                title=\"people on the beach\"\n              /><i\n                class=\"fa fa-plus box-icon-white box-icon-border hover-icon-top-right round\"\n              ></i>\n            </a>\n          </header>\n          <div class=\"thumb-caption\">\n            <h4 class=\"thumb-title\">Australia</h4>\n            <p class=\"thumb-desc\">\n              Netus eros sed nisl senectus natoque sapien maecenas\n            </p>\n          </div>\n        </div>\n      </div>\n      <div class=\"col-md-3\">\n        <div class=\"thumb\">\n          <header class=\"thumb-header\">\n            <a class=\"hover-img curved\" href=\"#\">\n              <img\n                src=\"img/400x300.png\"\n                alt=\"Image Alternative text\"\n                title=\"the journey home\"\n              /><i\n                class=\"fa fa-plus box-icon-white box-icon-border hover-icon-top-right round\"\n              ></i>\n            </a>\n          </header>\n          <div class=\"thumb-caption\">\n            <h4 class=\"thumb-title\">Africa</h4>\n            <p class=\"thumb-desc\">\n              Himenaeos proin in natoque porta sociis semper posuere\n            </p>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div> -->\n<app-footer></app-footer>\n"

/***/ }),

/***/ "./src/app/welcome/welcome.component.ts":
/*!**********************************************!*\
  !*** ./src/app/welcome/welcome.component.ts ***!
  \**********************************************/
/*! exports provided: WelcomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WelcomeComponent", function() { return WelcomeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");


var WelcomeComponent = /** @class */ (function () {
    function WelcomeComponent() {
    }
    WelcomeComponent.prototype.ngOnInit = function () {
    };
    WelcomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-welcome',
            template: __webpack_require__(/*! ./welcome.component.html */ "./src/app/welcome/welcome.component.html"),
            styles: [__webpack_require__(/*! ./welcome.component.css */ "./src/app/welcome/welcome.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], WelcomeComponent);
    return WelcomeComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
var environment = {
    production: false
};


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/esm5/platform-browser-dynamic.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! hammerjs */ "./node_modules/hammerjs/hammer.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! c:\Projects\Learning\client\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map